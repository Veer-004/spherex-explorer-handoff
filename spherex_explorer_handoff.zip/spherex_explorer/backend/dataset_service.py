"""
Real-data layer for SPHEREx Explorer.

Reads the dataset produced by dataset/build_dataset.py (real SPHEREx Level-2 data from IRSA):
  dataset/spherex/<field_id>/index.json, exposures.csv, stacks/*.fits, catalogs/*.csv

Everything served to the frontend comes from those files: stacked images per (visit, detector),
measured positions (centroids) and fluxes per exposure, and Gaia/CatWISE catalogs.
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
import sys
import threading
import traceback
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.wcs import WCS
import astropy.units as u

from backend.catalog import TARGET_INFO, DETECTOR_RANGES, SPECTRAL_CHANNELS, SPECTRAL_FEATURES
from backend.imaging import render_to_png_data_url

REPO_ROOT = Path(__file__).resolve().parent.parent
DATASET_DIR = Path(os.environ.get("SPHEREX_DATASET_DIR", REPO_ROOT / "dataset" / "spherex"))
BUILDER_DIR = REPO_ROOT / "dataset"
DISPLAY_SIZE = 256                    # frontend canvas works in 256x256 image coordinates
PIXEL_SCALE_ARCSEC = 6.15
DETECTORS = ["D1", "D2", "D3", "D4", "D5", "D6"]
MOTION_SIGNIFICANCE = 5.0             # sigma needed to call a measured proper motion real


class FieldNotFound(Exception):
    pass


# --------------------------------------------------------------------------- loading

def _mtime(p: Path) -> float:
    try:
        return p.stat().st_mtime
    except FileNotFoundError:
        return 0.0


@lru_cache(maxsize=64)
def _load_index(field_id: str, mtime: float) -> dict:
    return json.loads((DATASET_DIR / field_id / "index.json").read_text())


@lru_cache(maxsize=64)
def _load_exposures(field_id: str, mtime: float) -> List[dict]:
    path = DATASET_DIR / field_id / "exposures.csv"
    if not path.exists():
        return []
    rows = []
    with open(path, newline="") as fh:
        for r in csv.DictReader(fh):
            out: Dict[str, Any] = dict(r)
            for k in ("mjd", "wavelength_um", "bandwidth_um", "target_ra", "target_dec", "pixel_x", "pixel_y",
                      "flux_uJy", "flux_err_uJy", "centroid_ra", "centroid_dec", "centroid_offset_arcsec",
                      "peak_snr", "exptime_s", "neighbour_sep_arcsec", "neighbour_mag"):
                v = r.get(k, "")
                out[k] = float(v) if v not in ("", None, "nan") else None
            out["detector"] = int(r["detector"])
            for k in ("photometry_ok", "centroid_ok", "saturated", "blended"):
                out[k] = str(r.get(k, "")).strip().lower() == "true"
            rows.append(out)
    return rows


def field_ids() -> List[str]:
    if not DATASET_DIR.exists():
        return []
    return sorted(p.name for p in DATASET_DIR.iterdir() if (p / "index.json").exists())


def load_index(field_id: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9_.+-]+", field_id or "") or not (DATASET_DIR / field_id / "index.json").exists():
        raise FieldNotFound(field_id)
    return _load_index(field_id, _mtime(DATASET_DIR / field_id / "index.json"))


def load_exposures(field_id: str) -> List[dict]:
    return _load_exposures(field_id, _mtime(DATASET_DIR / field_id / "exposures.csv"))


@lru_cache(maxsize=256)
def _load_stack(path: str, mtime: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray, dict]:
    with fits.open(path) as h:
        img = h["IMAGE"].data.astype(np.float64)
        var = h["VARIANCE"].data.astype(np.float64)
        nexp = h["NEXP"].data.astype(np.int32)
        hdr = {k: h["IMAGE"].header[k] for k in h["IMAGE"].header if k not in ("COMMENT", "HISTORY", "")}
    return img, var, nexp, hdr


def load_stack(field_id: str, visit_id: str, detector: int):
    p = DATASET_DIR / field_id / "stacks" / f"{visit_id}_D{detector}.fits"
    if not p.exists():
        raise FieldNotFound(f"{field_id}/{visit_id}_D{detector}")
    return _load_stack(str(p), _mtime(p))


# --------------------------------------------------------------------------- geometry helpers

def fmt_ra(ra: float) -> str:
    return SkyCoord(ra * u.deg, 0 * u.deg).ra.to_string(unit=u.hour, sep=("h ", "m ", "s"), precision=2)


def fmt_dec(dec: float) -> str:
    return SkyCoord(0 * u.deg, dec * u.deg).dec.to_string(unit=u.degree, sep=("° ", "′ ", "″"), precision=1,
                                                          alwayssign=True)


def position_at(ast: dict, mjd: float) -> Tuple[float, float]:
    dt = (mjd - ast["ref_mjd"]) / 365.25
    dec = ast["dec"] + ast["pmdec_mas_yr"] * dt / 3.6e6
    ra = ast["ra"] + ast["pmra_mas_yr"] * dt / 3.6e6 / math.cos(math.radians(ast["dec"]))
    return ra % 360.0, dec


def crop_box(npix: int, fov_arcmin: float) -> Tuple[int, int]:
    n = int(round(fov_arcmin * 60.0 / PIXEL_SCALE_ARCSEC))
    n = max(15, min(npix, n))
    n -= (n % 2 == 0)                 # odd -> field centre stays a pixel centre
    lo = (npix - n) // 2
    return lo, n


def to_display(x: float, y: float, lo: int, n: int) -> Tuple[float, float]:
    """Stack pixel (0-based, y up) -> display pixel in the 256x256 north-up image (y down)."""
    s = DISPLAY_SIZE / n
    return (x - lo + 0.5) * s, (n - (y - lo) - 0.5) * s


def grid_wcs(index: dict) -> WCS:
    g = index["stack_grid"]
    npix = g["npix"]
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [index["field_center"]["ra"], index["field_center"]["dec"]]
    w.wcs.crpix = [(npix + 1) / 2.0, (npix + 1) / 2.0]
    s = g["pixel_scale_arcsec"] / 3600.0
    w.wcs.cdelt = [-s, s]
    return w


# --------------------------------------------------------------------------- targets / fields

def blend_summary(field_id: str) -> Optional[dict]:
    """How often a catalog star sits inside the target's aperture (from exposures.csv 'blended' column)."""
    exps = load_exposures(field_id)
    bl = [e for e in exps if e.get("blended")]
    if not exps or not bl:
        return None
    seps = [e["neighbour_sep_arcsec"] for e in bl if e["neighbour_sep_arcsec"] is not None]
    nid = max({e.get("neighbour_id", "") for e in bl}, key=lambda i: sum(1 for e in bl if e.get("neighbour_id") == i))
    mag = next((e["neighbour_mag"] for e in bl if e.get("neighbour_id") == nid), None)
    cat, _, sid = nid.partition(":")
    label = ("Gaia DR3 " if cat == "gaia_dr3" else "CatWISE2020 " if cat == "catwise2020" else "") + sid
    band = "G" if cat == "gaia_dr3" else "W1"
    return {"fraction": round(len(bl) / len(exps), 3), "n_blended": len(bl), "n_total": len(exps),
            "min_sep_arcsec": round(min(seps), 1) if seps else None, "max_sep_arcsec": round(max(seps), 1) if seps else None,
            "neighbour": label, "neighbour_mag": mag, "band": band,
            "message": (f"The target passes {min(seps):.1f}–{max(seps):.1f}″ from {label} ({band} = {mag}) in "
                        f"{len(bl)} of {len(exps)} exposures. SPHEREx pixels are 6.15″, so that star's light "
                        f"blends with the target there; those exposures are excluded from the motion fit.")
            if seps else "A catalog star blends with the target."}


def _visit_photometry(exps: List[dict]) -> Dict[str, Optional[float]]:
    """Per-visit brightness change (mag) relative to the field's median, using clean unsaturated photometry."""
    by_det: Dict[int, Dict[str, List[float]]] = {}
    for e in exps:
        if e["photometry_ok"] and not e.get("blended") and e["flux_uJy"] and e["flux_uJy"] > 0:
            by_det.setdefault(e["detector"], {}).setdefault(e["visit_id"], []).append(e["flux_uJy"])
    visit_dm: Dict[str, List[float]] = {}
    for det, visits in by_det.items():
        if len(visits) < 2:
            continue
        med = {v: float(np.median(f)) for v, f in visits.items()}
        ref = float(np.median(list(med.values())))
        for v, f in med.items():
            visit_dm.setdefault(v, []).append(-2.5 * math.log10(f / ref))
    return {v: float(np.median(d)) for v, d in visit_dm.items()}


def target_summary(field_id: str) -> dict:
    idx = load_index(field_id)
    info = TARGET_INFO.get(field_id, {})
    ast = idx["astrometry"]
    exps = load_exposures(field_id)
    dm = _visit_photometry(exps)
    visits = [v for v in idx["visits"] if any(s["visit_id"] == v["visit_id"] for s in idx["stacks"])]
    first_mjd = visits[0]["mjd_start"] if visits else idx["field_center"]["epoch_mjd"]
    ra0, dec0 = position_at(ast, first_mjd)
    epochs = []
    for v in visits:
        mid = 0.5 * (v["mjd_start"] + v["mjd_end"])
        ra, dec = position_at(ast, mid)
        epochs.append({
            "epoch_id": v["visit_id"], "obs_date": v["date_start"], "mjd": round(mid, 3),
            "delta_pos_arcsec": [round((ra - ra0) * math.cos(math.radians(dec0)) * 3600, 2),
                                 round((dec - dec0) * 3600, 2)],
            "flux_mjy": None if dm.get(v["visit_id"]) is None else round(dm[v["visit_id"]], 3),
            "quality_flag": 0,
            "n_images": v.get("n_images_available", 0),
        })
    pm_tot = math.hypot(ast["pmra_mas_yr"], ast["pmdec_mas_yr"]) / 1000.0
    center = idx["field_center"]
    kind = idx.get("kind", "field")
    dets = sorted({s["detector"] for s in idx["stacks"]})
    default_det = info.get("default_detector") or (f"D{dets[0]}" if dets else "D1")
    if dets and int(default_det[1:]) not in dets:
        default_det = f"D{dets[0]}"
    return {
        "id": field_id,
        "name": idx.get("name", field_id),
        "designations": info.get("designations", []),
        "classification": info.get("classification", "Custom sky field"),
        "description": info.get("description", "Field built on demand from SPHEREx data at IRSA."),
        "coordinates": {"ra_deg": round(center["ra"], 6), "dec_deg": round(center["dec"], 6),
                        "ra_sexagesimal": fmt_ra(center["ra"]), "dec_sexagesimal": fmt_dec(center["dec"]),
                        "epoch": f"MJD {center['epoch_mjd']:.0f}"},
        "distance_ly": info.get("distance_ly"),
        "proper_motion": {"pm_ra_mas_yr": round(ast["pmra_mas_yr"], 1), "pm_dec_mas_yr": round(ast["pmdec_mas_yr"], 1),
                          "total_pm_arcsec_yr": round(pm_tot, 3), "motion_type": ast.get("source", "")},
        "category": "moving" if kind == "moving" else ("variable" if kind == "variable" else "field"),
        "fov_arcmin": min(10.0, float(idx.get("stack_size_arcmin", 12.0))),
        "max_fov_arcmin": float(idx.get("stack_size_arcmin", 12.0)),
        "default_detector": default_det,
        "default_channel": 0,
        "available_detectors": [f"D{d}" for d in dets],
        "epochs": epochs,
        "spectral_signature": info.get("spectral_signature", "measured"),
        "astrometry_source": ast.get("source", ""),
        "images_available": idx.get("images_available", 0),
        "images_downloaded": idx.get("images_downloaded", 0),
        "built_utc": idx.get("built_utc"),
        "is_custom": field_id not in TARGET_INFO,
    }


def list_targets(include_custom: bool = True) -> List[dict]:
    out = []
    for fid in field_ids():
        try:
            s = target_summary(fid)
        except Exception:
            continue
        if include_custom or not s["is_custom"]:
            out.append(s)
    order = list(TARGET_INFO.keys())
    out.sort(key=lambda t: (order.index(t["id"]) if t["id"] in order else 99, t["id"]))
    return out


def find_field_near(ra: float, dec: float, max_arcmin: float = 4.0) -> Optional[str]:
    best, best_sep = None, max_arcmin
    for fid in field_ids():
        try:
            c = load_index(fid)["field_center"]
        except Exception:
            continue
        sep = SkyCoord(ra, dec, unit="deg").separation(SkyCoord(c["ra"], c["dec"], unit="deg")).arcmin
        if sep < best_sep:
            best, best_sep = fid, sep
    return best


# --------------------------------------------------------------------------- motion measurement

def measure_motion(field_id: str) -> Optional[dict]:
    """Fit a straight line to the per-exposure SPHEREx centroids (robust, 3-sigma clipped)."""
    idx = load_index(field_id)
    pts = [e for e in load_exposures(field_id)
           if e["centroid_ok"] and e["centroid_ra"] is not None and not e.get("blended")]
    if len(pts) < 6:
        return None
    t = np.array([e["mjd"] for e in pts])
    ra = np.array([e["centroid_ra"] for e in pts])
    dec = np.array([e["centroid_dec"] for e in pts])
    ra0, dec0, t0 = float(np.median(ra)), float(np.median(dec)), float(np.median(t))
    x = (ra - ra0) * math.cos(math.radians(dec0)) * 3600.0
    y = (dec - dec0) * 3600.0
    ty = (t - t0) / 365.25
    if ty.max() - ty.min() < 0.25:
        return None
    keep = np.ones(len(t), bool)
    for _ in range(5):
        A = np.vstack([np.ones(keep.sum()), ty[keep]]).T
        cx, *_ = np.linalg.lstsq(A, x[keep], rcond=None)
        cy, *_ = np.linalg.lstsq(A, y[keep], rcond=None)
        res = np.hypot(x - (cx[0] + cx[1] * ty), y - (cy[0] + cy[1] * ty))
        sig = 1.4826 * np.median(res[keep]) + 1e-6
        new_keep = res < 3.0 * sig + 0.5
        if new_keep.sum() < 6 or np.array_equal(new_keep, keep):
            break
        keep = new_keep
    n = int(keep.sum())
    A = np.vstack([np.ones(n), ty[keep]]).T
    cov = np.linalg.inv(A.T @ A)
    rx = x[keep] - (cx[0] + cx[1] * ty[keep])
    ry = y[keep] - (cy[0] + cy[1] * ty[keep])
    s2 = (np.sum(rx ** 2) + np.sum(ry ** 2)) / max(1, 2 * n - 4)
    err = float(math.sqrt(s2 * cov[1, 1]))
    pmx, pmy = float(cx[1]), float(cy[1])
    pm = math.hypot(pmx, pmy)
    ast = idx["astrometry"]
    cat_pm = math.hypot(ast["pmra_mas_yr"], ast["pmdec_mas_yr"]) / 1000.0
    return {
        "pm_ra_arcsec_yr": round(pmx, 3), "pm_dec_arcsec_yr": round(pmy, 3), "pm_total_arcsec_yr": round(pm, 3),
        "pm_error_arcsec_yr": round(err, 3), "significance_sigma": round(pm / err, 1) if err > 0 else None,
        "n_points": n, "n_rejected": int(len(t) - n), "rms_arcsec": round(float(math.sqrt(s2)), 2),
        "baseline_yr": round(float(ty.max() - ty.min()), 3),
        "catalog_pm_arcsec_yr": round(cat_pm, 3), "catalog_source": ast.get("source", ""),
        "ref": {"ra": ra0, "dec": dec0, "mjd": t0, "x0": float(cx[0]), "y0": float(cy[0])},
    }


def _track(field_id: str, lo: int, n: int) -> List[dict]:
    """Mean measured position per visit, in display pixels."""
    idx = load_index(field_id)
    w = grid_wcs(idx)
    out = []
    for v in idx["visits"]:
        pts = [e for e in load_exposures(field_id)
               if e["visit_id"] == v["visit_id"] and e["centroid_ok"] and not e.get("blended")]
        if not pts:
            continue
        ra = float(np.median([e["centroid_ra"] for e in pts]))
        dec = float(np.median([e["centroid_dec"] for e in pts]))
        px, py = (float(q) for q in w.all_world2pix([[ra, dec]], 0)[0])
        dx, dy = to_display(px, py, lo, n)
        out.append({"x": round(dx, 2), "y": round(dy, 2), "epoch": v["date_start"][:7], "visit_id": v["visit_id"],
                    "ra": round(ra, 7), "dec": round(dec, 7), "n": len(pts)})
    return out


def candidates_for(field_id: str, lo: int, n: int, ref_stack: Optional[dict]) -> List[dict]:
    idx = load_index(field_id)
    motion = measure_motion(field_id)
    dm = _visit_photometry(load_exposures(field_id))
    track = _track(field_id, lo, n)
    if ref_stack:
        tx, ty = ref_stack["target_pixel"]
        ra_t, dec_t = ref_stack["target_radec"]
    else:
        c = idx["field_center"]
        tx = ty = (idx["stack_grid"]["npix"] - 1) / 2.0
        ra_t, dec_t = c["ra"], c["dec"]
    dx, dy = to_display(tx, ty, lo, n)

    delta_mag = (max(dm.values()) - min(dm.values())) if len(dm) >= 2 else 0.0
    moving = bool(motion and motion["significance_sigma"] and motion["significance_sigma"] >= MOTION_SIGNIFICANCE
                  and motion["pm_total_arcsec_yr"] > 1.0)
    blend = blend_summary(field_id)
    if blend and blend["fraction"] >= 0.5 and not moving:
        ctype = "stationary"
        cls = (f"Blended: within {blend['min_sep_arcsec']}–{blend['max_sep_arcsec']}″ of {blend['neighbour']} "
               f"({blend['band']} = {blend['neighbour_mag']}), so SPHEREx cannot separate them yet")
    elif moving:
        ctype = "moving_object"
        cls = (f"Moving: {motion['pm_total_arcsec_yr']:.2f} ± {motion['pm_error_arcsec_yr']:.2f} ″/yr measured by SPHEREx "
               f"(catalog {motion['catalog_pm_arcsec_yr']:.2f} ″/yr)")
    elif delta_mag >= 0.2:
        ctype = "variable_source"
        cls = f"Variable: brightness changed by {delta_mag:.2f} mag between visits"
    else:
        ctype = "stationary"
        cls = "No significant motion or variability measured yet"
    disp = 0.0
    if len(track) >= 2:
        disp = SkyCoord(track[0]["ra"], track[0]["dec"], unit="deg").separation(
            SkyCoord(track[-1]["ra"], track[-1]["dec"], unit="deg")).arcsec
    snrs = [e["peak_snr"] for e in load_exposures(field_id) if e["peak_snr"]]
    sig = motion["significance_sigma"] if motion and motion["significance_sigma"] else 0.0
    return [{
        "candidate_id": f"{field_id.upper()}-TARGET",
        "type": ctype,
        "classification": cls,
        "ra_deg": round(ra_t, 6), "dec_deg": round(dec_t, 6),
        "ra_sexagesimal": fmt_ra(ra_t), "dec_sexagesimal": fmt_dec(dec_t),
        "pixel_x": round(dx, 2), "pixel_y": round(dy, 2),
        "angular_displacement_arcsec": round(float(disp), 2),
        "confidence_score": round(min(99.9, sig * 10.0), 1) if moving else round(min(99.0, delta_mag * 100), 1),
        "snr": round(float(np.median(snrs)), 1) if snrs else 0.0,
        "epochs_detected": len(track),
        "status": "Measured from SPHEREx centroids" if motion else "Not enough detections for a motion fit",
        "motion": {k: v for k, v in motion.items() if k != "ref"} if motion else None,
        "brightness_change_mag": round(delta_mag, 3),
        "blend": blend,
        "track": track,
    }]


# --------------------------------------------------------------------------- observations / difference

def _stack_meta(idx: dict, visit_id: str, det: int) -> Optional[dict]:
    for s in idx["stacks"]:
        if s["visit_id"] == visit_id and s["detector"] == det:
            return s
    return None


def _robust_range(arrays: List[np.ndarray]) -> Tuple[float, float]:
    vals = np.concatenate([a[np.isfinite(a)].ravel() for a in arrays]) if arrays else np.array([0.0])
    if vals.size == 0:
        return 0.0, 1.0
    lo, hi = float(np.percentile(vals, 1.0)), float(np.percentile(vals, 99.7))
    return lo, (hi if hi > lo else lo + 1.0)


def _display_array(img: np.ndarray, lo: int, n: int, fill: float) -> np.ndarray:
    sub = img[lo:lo + n, lo:lo + n]
    sub = np.where(np.isfinite(sub), sub, fill)[::-1]          # north up
    idx = (np.arange(DISPLAY_SIZE) * n / DISPLAY_SIZE).astype(int)
    return sub[np.ix_(idx, idx)]                               # nearest-neighbour upsample to 256x256


def get_observations(field_id: str, detector: str, fov_arcmin: float, stretch: str, colormap: str) -> dict:
    idx = load_index(field_id)
    det = int(str(detector).upper().lstrip("D") or 0)
    stacks = [s for s in idx["stacks"] if s["detector"] == det]
    if not stacks:
        dets = sorted({s["detector"] for s in idx["stacks"]})
        if not dets:
            raise FieldNotFound(f"{field_id} has no stacks")
        det = dets[0]
        stacks = [s for s in idx["stacks"] if s["detector"] == det]
    stacks.sort(key=lambda s: s["mjd_avg"])
    npix = idx["stack_grid"]["npix"]
    lo, n = crop_box(npix, fov_arcmin)
    fov_eff = round(n * PIXEL_SCALE_ARCSEC / 60.0, 2)
    imgs = []
    for s in stacks:
        img, var, nexp, hdr = load_stack(field_id, s["visit_id"], det)
        imgs.append((s, img, var, nexp, hdr))
    vmin, vmax = _robust_range([i[1][lo:lo + n, lo:lo + n] for i in imgs])   # same scaling for every visit
    center = idx["field_center"]
    observations = []
    for k, (s, img, var, nexp, hdr) in enumerate(imgs):
        sub = img[lo:lo + n, lo:lo + n]
        disp = _display_array(img, lo, n, vmin)
        url = render_to_png_data_url(disp, stretch=stretch, vmin=vmin, vmax=vmax, colormap=colormap)
        finite = sub[np.isfinite(sub)]
        rms = float(1.4826 * np.median(np.abs(finite - np.median(finite)))) if finite.size else 0.0
        wl_lo, wl_hi = s.get("wavelength_min_um"), s.get("wavelength_max_um")
        dr = DETECTOR_RANGES[f"D{det}"]
        fits_cards = [{"key": key, "val": str(hdr[key]), "comment": ""} for key in
                      ("CTYPE1", "CTYPE2", "CRVAL1", "CRVAL2", "CRPIX1", "CRPIX2", "CDELT1", "CDELT2", "BUNIT",
                       "TELESCOP", "DETECTOR", "VISIT", "MJD-AVG", "NEXP", "WAVEMIN", "WAVEMAX", "TARG_X", "TARG_Y")
                      if key in hdr]
        observations.append({
            "epoch_index": k,
            "epoch_id": s["visit_id"],
            "obs_date": s["date_avg"],
            "mjd": s["mjd_avg"],
            "image_url": url,
            "flux_mjy": None,
            "quality_flag": 0,
            "n_exposures": s["n_exposures"],
            "metadata": {
                "telescope": "SPHEREx",
                "instrument": "SPHEREx Level-2 spectral images (stacked)",
                "data_release": ", ".join(idx.get("collections_queried", [])),
                "channel": 0,
                "detector": f"D{det}",
                "wavelength_um": round(0.5 * ((wl_lo or dr["wavelength_min"]) + (wl_hi or dr["wavelength_max"])), 3),
                "wavelength_min_um": wl_lo, "wavelength_max_um": wl_hi,
                "fov_arcmin": fov_eff,
                "pixel_scale_arcsec": PIXEL_SCALE_ARCSEC,
                "dimensions": [n, n],
                "center_coordinates": {"ra": center["ra"], "dec": center["dec"]},
                "background_flux_mjy_sr": round(float(np.median(finite)), 4) if finite.size else 0.0,
                "peak_flux": round(float(finite.max()), 3) if finite.size else 0.0,
                "mean_flux": round(float(finite.mean()), 4) if finite.size else 0.0,
                "rms_noise": round(rms, 4),
                "n_exposures": s["n_exposures"],
                "quality_flags": {"zodiacal_subtracted": True, "cosmic_ray_masked": True,
                                  "saturation_detected": any(e["saturated"] for e in load_exposures(field_id)
                                                             if e["visit_id"] == s["visit_id"] and e["detector"] == det),
                                  "stray_light_fraction": 0.0},
                "fits_header": fits_cards,
            },
        })
    ref = stacks[0] if stacks else None
    return {
        "target_id": field_id,
        "target_name": idx.get("name", field_id),
        "ra_deg": center["ra"], "dec_deg": center["dec"],
        "fov_arcmin": fov_eff,
        "channel": 0,
        "detector": f"D{det}",
        "wavelength_um": observations[0]["metadata"]["wavelength_um"] if observations else 0.0,
        "available_detectors": [f"D{d}" for d in sorted({s['detector'] for s in idx['stacks']})],
        "total_epochs": len(observations),
        "observations": observations,
        "detected_candidates": candidates_for(field_id, lo, n, ref),
        "data_source": "NASA/IPAC IRSA - SPHEREx Level-2 spectral images",
    }


def get_difference(field_id: str, detector: str, epoch1: int, epoch2: int, fov_arcmin: float, stretch: str) -> dict:
    idx = load_index(field_id)
    det = int(str(detector).upper().lstrip("D") or 0)
    stacks = sorted([s for s in idx["stacks"] if s["detector"] == det], key=lambda s: s["mjd_avg"])
    if len(stacks) < 2:
        raise FieldNotFound(f"{field_id} D{det} needs two visits for a difference image")
    epoch1 = max(0, min(epoch1, len(stacks) - 1))
    epoch2 = max(0, min(epoch2, len(stacks) - 1))
    a = load_stack(field_id, stacks[epoch1]["visit_id"], det)[0]
    b = load_stack(field_id, stacks[epoch2]["visit_id"], det)[0]
    lo, n = crop_box(idx["stack_grid"]["npix"], fov_arcmin)
    diff = (b - a)[lo:lo + n, lo:lo + n]
    finite = diff[np.isfinite(diff)]
    rms = float(1.4826 * np.median(np.abs(finite - np.median(finite)))) if finite.size else 1e-6
    limit = max(5.0 * rms, float(np.percentile(np.abs(finite), 99.5)) if finite.size else 1.0, 1e-6)
    norm = np.clip(diff / (2 * limit) + 0.5, 0, 1)
    full = np.full_like(b, 0.5)
    full[lo:lo + n, lo:lo + n] = norm
    disp = _display_array(full, lo, n, 0.5)
    url = render_to_png_data_url(disp, stretch="linear", vmin=0.0, vmax=1.0, colormap="difference")
    return {
        "epoch1_index": epoch1, "epoch2_index": epoch2,
        "epoch1_id": stacks[epoch1]["visit_id"], "epoch2_id": stacks[epoch2]["visit_id"],
        "difference_image_url": url,
        "stats": {"rms_noise": round(rms, 4),
                  "max_positive_residual": round(float(finite.max()), 4) if finite.size else 0.0,
                  "min_negative_residual": round(float(finite.min()), 4) if finite.size else 0.0,
                  "snr_peak": round(float(finite.max()) / rms, 2) if finite.size and rms > 0 else 0.0},
    }


# --------------------------------------------------------------------------- spectrum

def get_spectrum(field_id: str) -> dict:
    idx = load_index(field_id)
    exps = load_exposures(field_id)
    pts = [e for e in exps if e["wavelength_um"] is not None]
    edges = []
    for ch in SPECTRAL_CHANNELS:
        half = ch["bandwidth_um"] / 2.0
        edges.append((ch["wavelength_um"] - half, ch["wavelength_um"] + half))
    channels = []
    for ch, (w0, w1) in zip(SPECTRAL_CHANNELS, edges):
        inbin = [e for e in pts if w0 <= e["wavelength_um"] < w1]
        measured = [e for e in inbin if e["photometry_ok"] and e["flux_uJy"] is not None and e["flux_err_uJy"]]
        clean = [e for e in measured if not e.get("blended")]
        good = clean or measured
        if good:
            f = np.array([e["flux_uJy"] for e in good]) / 1000.0
            er = np.array([e["flux_err_uJy"] for e in good]) / 1000.0
            wts = 1.0 / np.maximum(er, 1e-6) ** 2
            flux = float(np.sum(wts * f) / np.sum(wts))
            ferr = float(1.0 / math.sqrt(np.sum(wts)))
            status, valid = ("VALID" if clean else "BLENDED"), True
        else:
            flux = ferr = None
            valid = False
            status = "SATURATED" if any(e["saturated"] for e in inbin) else ("FLAGGED" if inbin else "NO_DATA")
        channels.append({
            "channel": ch["channel"], "detector": ch["detector"], "wavelength_um": ch["wavelength_um"],
            "bandwidth_um": ch["bandwidth_um"], "resolving_power": ch["resolving_power"],
            "flux_mjy": None if flux is None else round(flux, 5),
            "flux_err_mjy": None if ferr is None else round(ferr, 5),
            "snr": None if flux is None or not ferr else round(flux / ferr, 1),
            "is_valid": valid, "status_flag": status, "n_measurements": len(good),
        })
    valid = [c["flux_mjy"] for c in channels if c["is_valid"]]
    return {
        "target_id": field_id,
        "target_name": idx.get("name", field_id),
        "spectral_signature": "measured",
        "total_channels": len(channels),
        "valid_channels_count": len(valid),
        "peak_flux_mjy": round(max(valid), 5) if valid else 0.0,
        "min_flux_mjy": round(min(valid), 5) if valid else 0.0,
        "mean_flux_mjy": round(float(np.mean(valid)), 5) if valid else 0.0,
        "channels": channels,
        "points": [{"wavelength_um": e["wavelength_um"], "flux_mjy": round(e["flux_uJy"] / 1000.0, 5),
                    "flux_err_mjy": round(e["flux_err_uJy"] / 1000.0, 5), "detector": f"D{e['detector']}",
                    "visit_id": e["visit_id"], "blended": bool(e.get("blended"))}
                   for e in pts if e["photometry_ok"] and e["flux_uJy"] is not None],
        "n_saturated": sum(1 for e in exps if e["saturated"]),
        "n_blended_channels": sum(1 for c in channels if c["status_flag"] == "BLENDED"),
        "blend_warning": (blend_summary(field_id) or {}).get("message"),
        "n_exposures": len(exps),
        "note": "Aperture fluxes (not aperture-corrected) measured on each SPHEREx exposure at the target position.",
        "reference_features": SPECTRAL_FEATURES,
    }


# --------------------------------------------------------------------------- catalogs

def get_catalog(field_id: str, source: str, fov_arcmin: float) -> dict:
    idx = load_index(field_id)
    name = {"gaia": "gaia_dr3", "gaia_dr3": "gaia_dr3", "catwise": "catwise2020", "catwise2020": "catwise2020"}.get(source)
    if not name:
        raise FieldNotFound(f"unknown catalog {source}")
    path = DATASET_DIR / field_id / "catalogs" / f"{name}.csv"
    if not path.exists():
        return {"source": name, "sources": [], "available": False}
    w = grid_wcs(idx)
    lo, n = crop_box(idx["stack_grid"]["npix"], fov_arcmin)
    epoch_mjd = idx["field_center"]["epoch_mjd"]
    ref_mjd = 57388.5 if name == "gaia_dr3" else 57170.0
    pm_scale = 1.0 if name == "gaia_dr3" else 1000.0            # CatWISE pm is arcsec/yr
    rows = []
    with open(path, newline="") as fh:
        for r in csv.DictReader(fh):
            try:
                ra, dec = float(r["ra"]), float(r["dec"])
            except (TypeError, ValueError):
                continue
            pmra = float(r["pmra"]) * pm_scale if r.get("pmra") not in ("", None) else 0.0
            pmdec = float(r["pmdec"]) * pm_scale if r.get("pmdec") not in ("", None) else 0.0
            ra_e, dec_e = position_at({"ra": ra, "dec": dec, "pmra_mas_yr": pmra, "pmdec_mas_yr": pmdec,
                                       "ref_mjd": ref_mjd}, epoch_mjd)
            px, py = (float(q) for q in w.all_world2pix([[ra_e, dec_e]], 0)[0])
            if not (lo - 0.5 <= px <= lo + n - 0.5 and lo - 0.5 <= py <= lo + n - 0.5):
                continue
            dx, dy = to_display(px, py, lo, n)
            mag = r.get("phot_g_mean_mag") or r.get("w1mpro") or ""
            rows.append({"ra": round(ra_e, 6), "dec": round(dec_e, 6), "x": round(dx, 1), "y": round(dy, 1),
                         "pm_total_mas_yr": round(math.hypot(pmra, pmdec), 1),
                         "mag": round(float(mag), 2) if mag not in ("", None) else None,
                         "id": r.get("source_id") or r.get("source_name", "")})
    rows.sort(key=lambda s: (s["mag"] is None, s["mag"]))
    return {"source": name, "available": True, "epoch_mjd": epoch_mjd, "sources": rows[:600]}


# --------------------------------------------------------------------------- discoveries (persisted)

DISCOVERIES_FILE = DATASET_DIR / "discoveries.json"
_disc_lock = threading.Lock()


def _read_user_discoveries() -> List[dict]:
    try:
        return json.loads(DISCOVERIES_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def list_discoveries() -> List[dict]:
    items = []
    for t in list_targets(include_custom=True):
        try:
            c = candidates_for(t["id"], 0, 1, None)[0]
        except Exception:
            continue
        m = c.get("motion") or {}
        items.append({
            "id": f"SPX-MEAS-{t['id']}",
            "name": t["name"],
            "target_field": t["name"],
            "ra_deg": t["coordinates"]["ra_deg"], "dec_deg": t["coordinates"]["dec_deg"],
            "ra_sexagesimal": t["coordinates"]["ra_sexagesimal"], "dec_sexagesimal": t["coordinates"]["dec_sexagesimal"],
            "category": c["type"] if c["type"] != "stationary" else "unclassified",
            "classification": c["classification"],
            "angular_displacement_arcsec": c["angular_displacement_arcsec"],
            "proper_motion_arcsec_yr": m.get("pm_total_arcsec_yr", 0.0),
            "brightness_mag_var": c["brightness_change_mag"],
            "confidence_score": c["confidence_score"],
            "epochs_detected": c["epochs_detected"],
            "status": "Automatic SPHEREx measurement",
            "date_flagged": (t.get("built_utc") or "")[:10],
            "notes": (f"{m.get('n_points', 0)} centroids over {m.get('baseline_yr', 0)} yr; "
                      f"catalog {m.get('catalog_source', '')} gives {m.get('catalog_pm_arcsec_yr', 0)} ″/yr.")
                     if m else "Not enough SPHEREx detections for a motion fit.",
        })
    return _read_user_discoveries() + items


def save_discovery(record: dict) -> dict:
    with _disc_lock:
        items = _read_user_discoveries()
        record = {**record, "id": f"SPX-USER-{len(items) + 1:04d}",
                  "date_flagged": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                  "status": record.get("status") or "Flagged by user"}
        items.insert(0, record)
        DATASET_DIR.mkdir(parents=True, exist_ok=True)
        DISCOVERIES_FILE.write_text(json.dumps(items, indent=2))
    return record


# --------------------------------------------------------------------------- on-demand field builds

_jobs: Dict[str, dict] = {}
_jobs_lock = threading.Lock()


def custom_field_id(ra: float, dec: float) -> str:
    return f"field_{ra:08.4f}_{'p' if dec >= 0 else 'm'}{abs(dec):07.4f}".replace(".", "d")


def build_status(field_id: str) -> dict:
    with _jobs_lock:
        job = dict(_jobs.get(field_id, {}))
    if not job:
        job = {"field_id": field_id, "state": "done" if field_id in field_ids() else "unknown"}
    return job


def start_field_build(ra: float, dec: float, name: Optional[str] = None, max_per_group: int = 3) -> dict:
    fid = custom_field_id(ra, dec)
    with _jobs_lock:
        if fid in _jobs and _jobs[fid]["state"] in ("queued", "running"):
            return dict(_jobs[fid])
        _jobs[fid] = {"field_id": fid, "state": "queued", "message": "Queued",
                      "started_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}

    def run():
        with _jobs_lock:
            _jobs[fid].update(state="running", message="Querying IRSA and downloading SPHEREx cutouts")
        try:
            if str(BUILDER_DIR) not in sys.path:
                sys.path.insert(0, str(BUILDER_DIR))
            import build_dataset  # type: ignore
            t = {"id": fid, "name": name or f"Field {fmt_ra(ra)} {fmt_dec(dec)}", "kind": "field",
                 "ra_j2000": ra, "dec_j2000": dec, "pmra_mas_yr": 0.0, "pmdec_mas_yr": 0.0, "resolver": "none"}
            res = build_dataset.build_target(t, DATASET_DIR, 12.0, max_per_group, 4, False)
            state = "done" if res.get("status") == "ok" else "error"
            msg = "Field ready" if state == "done" else "No SPHEREx images cover this position yet"
            with _jobs_lock:
                _jobs[fid].update(state=state, message=msg)
        except Exception as exc:
            traceback.print_exc()
            with _jobs_lock:
                _jobs[fid].update(state="error", message=str(exc))

    threading.Thread(target=run, daemon=True).start()
    return build_status(fid)


def dataset_health() -> dict:
    ids = field_ids()
    return {"dataset_dir": str(DATASET_DIR), "fields": len(ids),
            "benchmark_targets_ready": [i for i in ids if i in TARGET_INFO]}
