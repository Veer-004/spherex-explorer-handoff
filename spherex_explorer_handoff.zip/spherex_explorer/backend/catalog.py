"""
Static reference information for SPHEREx Explorer: detector layout, nominal spectral channels,
infrared reference features, and descriptive facts about the challenge targets.

Measured quantities (positions, motions, images, fluxes) are NOT stored here; they come from the
real SPHEREx dataset via backend/dataset_service.py.
"""

from typing import Dict, Any

# 6 detectors x 17 nominal channels = 102 channels, 0.75-5.00 um (approximate band edges)
DETECTOR_RANGES = {
    "D1": {"wavelength_min": 0.75, "wavelength_max": 1.11, "channels": list(range(1, 18)), "pixel_scale": 6.15, "resolving_power": 39},
    "D2": {"wavelength_min": 1.11, "wavelength_max": 1.64, "channels": list(range(18, 35)), "pixel_scale": 6.15, "resolving_power": 41},
    "D3": {"wavelength_min": 1.64, "wavelength_max": 2.42, "channels": list(range(35, 52)), "pixel_scale": 6.15, "resolving_power": 41},
    "D4": {"wavelength_min": 2.42, "wavelength_max": 3.82, "channels": list(range(52, 69)), "pixel_scale": 6.15, "resolving_power": 35},
    "D5": {"wavelength_min": 3.82, "wavelength_max": 4.42, "channels": list(range(69, 86)), "pixel_scale": 6.15, "resolving_power": 112},
    "D6": {"wavelength_min": 4.42, "wavelength_max": 5.00, "channels": list(range(86, 103)), "pixel_scale": 6.15, "resolving_power": 128},
}


def get_detector_for_channel(channel: int) -> str:
    for det, info in DETECTOR_RANGES.items():
        if channel in info["channels"]:
            return det
    raise ValueError(f"Channel must be between 1 and 102, got {channel}")


def get_channel_wavelength(channel: int) -> float:
    det = get_detector_for_channel(channel)
    info = DETECTOR_RANGES[det]
    i = info["channels"].index(channel)
    step = (info["wavelength_max"] - info["wavelength_min"]) / len(info["channels"])
    return round(info["wavelength_min"] + (i + 0.5) * step, 4)


SPECTRAL_CHANNELS = [
    {
        "channel": ch,
        "detector": get_detector_for_channel(ch),
        "wavelength_um": get_channel_wavelength(ch),
        "resolving_power": DETECTOR_RANGES[get_detector_for_channel(ch)]["resolving_power"],
        "bandwidth_um": round((DETECTOR_RANGES[get_detector_for_channel(ch)]["wavelength_max"]
                               - DETECTOR_RANGES[get_detector_for_channel(ch)]["wavelength_min"]) / 17.0, 4),
    }
    for ch in range(1, 103)
]

SPECTRAL_FEATURES = [
    {"name": "H2O Ice (broad libration)", "wavelength_um": 3.05, "type": "absorption", "significance": "Water ice in cold dust and circumstellar discs"},
    {"name": "CO2 Ice", "wavelength_um": 4.27, "type": "absorption", "significance": "Carbon dioxide ice in interstellar grain mantles"},
    {"name": "CO Ice", "wavelength_um": 4.67, "type": "absorption", "significance": "Volatile carbon monoxide ice"},
    {"name": "CH3OH (Methanol) Ice", "wavelength_um": 3.53, "type": "absorption", "significance": "Complex organic molecule in ices"},
    {"name": "CH4 (Methane)", "wavelength_um": 1.66, "type": "absorption", "significance": "Methane band in T and Y brown dwarfs"},
    {"name": "CH4 (Methane ν3)", "wavelength_um": 3.32, "type": "absorption", "significance": "Strong fundamental methane absorption"},
    {"name": "PAH (Aromatic C-H)", "wavelength_um": 3.29, "type": "emission", "significance": "Polycyclic aromatic hydrocarbons in star-forming dust"},
    {"name": "Paschen α (H I)", "wavelength_um": 1.875, "type": "emission", "significance": "Ionized hydrogen (accretion, star formation)"},
    {"name": "Brackett α (H I)", "wavelength_um": 4.052, "type": "emission", "significance": "Ionized hydrogen recombination line"},
    {"name": "CO Band Head (v=2-0)", "wavelength_um": 2.293, "type": "absorption", "significance": "Cool star photospheres (M stars, giants)"},
]

# Descriptive facts only. ids match dataset/targets.json and dataset/spherex/<id>/.
TARGET_INFO: Dict[str, Dict[str, Any]] = {
    "barnards_star": {
        "designations": ["GJ 699", "HIP 87937", "BD+04 3561a"],
        "classification": "M4V red dwarf",
        "description": "The star with the largest known proper motion (~10.4″/yr). About 6 light-years away. "
                       "Bright enough to saturate SPHEREx, but its recorded wings give precise positions.",
        "distance_ly": 5.96,
        "default_detector": "D1",
        "spectral_signature": "red_dwarf",
    },
    "wise_0855": {
        "designations": ["WISE J085510.83-071442.5", "W0855"],
        "classification": "Y-type brown dwarf (~285 K)",
        "description": "The coldest known brown dwarf, about 7.4 light-years away, moving ~8.1″/yr. "
                       "Extremely faint below ~4 µm, so look for it in detectors D5 and D6.",
        "distance_ly": 7.4,
        "default_detector": "D6",
        "spectral_signature": "cold_brown_dwarf",
    },
    "epsilon_indi_b": {
        "designations": ["Eps Ind Ba/Bb", "Eps Indi B"],
        "classification": "T1 + T6 binary brown dwarf",
        "description": "A pair of brown dwarfs orbiting the star Epsilon Indi A, about 11.9 light-years away, "
                       "moving ~4.7″/yr. Methane absorption shapes its infrared spectrum.",
        "distance_ly": 11.9,
        "default_detector": "D3",
        "spectral_signature": "t_dwarf",
    },
    "rw_aurigae": {
        "designations": ["RW Aur"],
        "classification": "Classical T Tauri star (young binary)",
        "description": "A young star still surrounded by a dusty disk. Known for deep, irregular dimming events "
                       "caused by dust crossing our line of sight.",
        "distance_ly": 510.0,
        "default_detector": "D4",
        "spectral_signature": "young_star",
    },
    "r_draconis": {
        "designations": ["R Dra"],
        "classification": "Mira variable (pulsating red giant)",
        "description": "A pulsating red giant with a ~246-day period. Its infrared brightness rises and falls "
                       "strongly over each cycle.",
        "distance_ly": None,
        "default_detector": "D6",
        "spectral_signature": "mira",
    },
}
