"""
Moving-object candidates from the trained ML model (ml/movers/).

For a dataset field: detect every source in the visit stacks, measure its position in each visit,
fit its motion, and score it with the LightGBM classifier trained on synthetic movers injected into
real SPHEREx stacks. The decision threshold was chosen so that ~1% of real non-moving Gaia stars are
flagged (see ml/movers/README.md for how this was measured).
"""

from __future__ import annotations

import json
import math
import os
import sys
import threading
from pathlib import Path
from typing import Dict, Optional

import numpy as np
from astropy.time import Time

from backend import dataset_service as ds

REPO = Path(__file__).resolve().parent.parent
ML_DIR = REPO / "ml" / "movers"
MODEL_DIR = ML_DIR / "output"

_lock = threading.Lock()
_model = None
_model_type: Optional[str] = None
_meta: Optional[dict] = None
_metrics: Optional[dict] = None
_cache: Dict[str, tuple] = {}


class ModelUnavailable(Exception):
    pass


def _num(v, digits: int):
    """Round, mapping missing/NaN/inf to None (JSON has no NaN)."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return round(v, digits) if math.isfinite(v) else None


def _movers_module():
    if str(ML_DIR) not in sys.path:
        sys.path.insert(0, str(ML_DIR))
    import movers  # type: ignore
    return movers


def _load_model():
    global _model, _model_type, _meta, _metrics
    with _lock:
        if _model is not None:
            return _model, _meta
        meta_path = MODEL_DIR / "model_meta.json"
        if not meta_path.exists():
            raise ModelUnavailable("Mover model not trained yet. Run ml/movers/build_training_set.py and ml/movers/train.py.")
        _meta = json.loads(meta_path.read_text())
        # SPHEREX_MOVER_MODEL (env) can point at another model file in ml/movers/output, e.g. stack_model.pkl
        model_file = os.environ.get("SPHEREX_MOVER_MODEL") or _meta.get("model_file", "model_lightgbm.txt")
        model_path = MODEL_DIR / Path(model_file).name
        if not model_path.exists():
            raise ModelUnavailable(f"Model file {model_file} not found.")

        if model_file.endswith(".pkl"):
            # self-contained bundle from train_stack.py / the LightGBM export: model + features + threshold
            import pickle
            with open(model_path, "rb") as fh:
                bundle = pickle.load(fh)
            _model = bundle["model"]
            _model_type = "sklearn" if hasattr(_model, "predict_proba") else "lightgbm"
            _meta = {**_meta, "features": bundle["features"], "threshold": bundle["threshold"],
                     "min_visits": bundle.get("min_visits", 3),
                     "target_false_alarm_rate": bundle.get("target_false_alarm_rate", 0.01),
                     "training_data": bundle.get("training_data"),
                     "best_model_name": "stack" if "Stacking" in str(bundle.get("model_type", "")) else "lightgbm",
                     "nested_cv": bundle.get("nested_cv")}
        elif model_file.endswith(".txt"):
            import lightgbm as lgb
            _model = lgb.Booster(model_file=str(model_path))
            _model_type = "lightgbm"
        elif model_file.endswith(".json"):
            import xgboost as xgb
            _model = xgb.XGBClassifier()
            _model.load_model(str(model_path))
            _model_type = "xgboost"
        elif model_file.endswith(".joblib"):
            import joblib
            _model = joblib.load(str(model_path))
            _model_type = "sklearn"
        else:
            raise ModelUnavailable(f"Unsupported model format: {model_file}")

        metrics_path = MODEL_DIR / "metrics.json"
        _metrics = json.loads(metrics_path.read_text()) if metrics_path.exists() else {}
        return _model, _meta


def model_info() -> dict:
    try:
        _, meta = _load_model()
    except ModelUnavailable as exc:
        return {"available": False, "message": str(exc)}
    m = (_metrics or {}).get("models", {})
    best_name = meta.get("best_model_name", "lightgbm")
    best_m = m.get(best_name, m.get("lightgbm", {}))
    nested = meta.get("nested_cv")
    if nested and best_name in nested:          # .pkl bundle carries its own (nested-CV) results
        s, rule = nested[best_name], nested.get("rule", {})
        return {
            "available": True,
            "model_name": best_name,
            "threshold": meta["threshold"],
            "min_visits": meta.get("min_visits", 3),
            "target_false_alarm_rate": meta.get("target_false_alarm_rate"),
            "training_data": meta.get("training_data"),
            "recall_injected_movers": s.get("recall_injected_movers"),
            "rule_recall_injected_movers": rule.get("recall_injected_movers"),
            "false_alarm_rate_real_stars": s.get("false_alarm_rate_real_static"),
            "n_real_stars_tested": s.get("real_static_total"),
            "motion_range_arcsec_yr": [1.0, 15.0],
        }
    return {
        "available": True,
        "model_name": best_name,
        "threshold": meta["threshold"],
        "min_visits": meta.get("min_visits", 3),
        "target_false_alarm_rate": meta.get("target_false_alarm_rate"),
        "training_data": meta.get("training_data"),
        "recall_injected_movers": best_m.get("recall_injected"),
        "rule_recall_injected_movers": m.get("rule", {}).get("recall_injected"),
        "false_alarm_rate_real_stars": best_m.get("false_alarm_rate_real_static_stars"),
        "n_real_stars_tested": (_metrics or {}).get("n_real_static_eval"),
        "motion_range_arcsec_yr": [1.0, 15.0],
    }


def _score_field(field_id: str) -> dict:
    M = _movers_module()
    model, meta = _load_model()
    f = M.load_field(field_id)
    if len(f.visits) < 2:
        return {"field": f, "rows": [], "gaia": np.zeros((0, 4))}
    vs = M.visit_snr_images(f)
    rows = M.measure(f, vs, M.detect(f, vs))
    feats = meta["features"]
    if rows:
        X = np.array([[r.get(c, np.nan) if r.get(c) is not None else np.nan for c in feats] for r in rows], dtype=float)
        if _model_type == "lightgbm":
            p = model.predict(X)
        elif _model_type in ("xgboost", "sklearn"):
            p = model.predict_proba(X)[:, 1]
        else:
            p = model.predict(X)
        for r, pi in zip(rows, p):
            ok = r.get("n_vis_det", 0) >= meta.get("min_visits", 3)
            r["p_mover"] = float(pi) if ok else 0.0
            r["scored"] = bool(ok)
    return {"field": f, "rows": rows, "gaia": M.gaia_sources_px(f)}


def get_candidates(field_id: str, fov_arcmin: float = 10.0, limit: int = 12) -> dict:
    idx = ds.load_index(field_id)                       # raises FieldNotFound for unknown ids
    mt = ds._mtime(ds.DATASET_DIR / field_id / "index.json")
    key = field_id
    with _lock:
        hit = _cache.get(key)
    if not hit or hit[0] != mt:
        res = _score_field(field_id)
        with _lock:
            _cache[key] = (mt, res)
    else:
        res = hit[1]
    _, meta = _load_model()
    f, rows, gaia = res["field"], res["rows"], res["gaia"]
    npix = idx["stack_grid"]["npix"]
    lo, n = ds.crop_box(npix, fov_arcmin)
    w = ds.grid_wcs(idx)
    thr = float(meta["threshold"])

    out = []
    for i, r in enumerate(sorted(rows, key=lambda r: -r.get("p_mover", 0.0))):
        x, y = r["x"], r["y"]
        in_view = lo - 0.5 <= x <= lo + n - 0.5 and lo - 0.5 <= y <= lo + n - 0.5
        ra, dec = (float(v) for v in w.all_pix2world([[x, y]], 0)[0])
        g_pm = g_mag = None
        if len(gaia):
            dd = np.hypot(gaia[:, 0] - x, gaia[:, 1] - y)
            j = int(np.argmin(dd))
            if dd[j] <= 1.5:
                g_pm = None if not np.isfinite(gaia[j, 2]) else round(float(gaia[j, 2]), 3)
                g_mag = None if not np.isfinite(gaia[j, 3]) else round(float(gaia[j, 3]), 2)
        dx, dy = ds.to_display(x, y, lo, n)
        track = []
        for t_yr, vx, vy in r.get("vis_track", []):
            tx, ty = ds.to_display(vx, vy, lo, n)
            track.append({"x": round(tx, 2), "y": round(ty, 2),
                          "epoch": Time(f.t0 + t_yr * 365.25, format="mjd").isot[:7]})
        out.append({
            "candidate_id": f"ML-{field_id[:12].upper()}-{i + 1:03d}",
            "p_mover": round(r.get("p_mover", 0.0), 4),
            "flagged": bool(r.get("p_mover", 0.0) >= thr),
            "scored": r.get("scored", False),
            "in_view": bool(in_view),
            "ra_deg": round(ra, 6), "dec_deg": round(dec, 6),
            "ra_sexagesimal": ds.fmt_ra(ra), "dec_sexagesimal": ds.fmt_dec(dec),
            "pixel_x": round(dx, 2), "pixel_y": round(dy, 2),
            "pm_fit_arcsec_yr": _num(r.get("pm_fit_arcsec_yr"), 2),
            "pm_err_arcsec_yr": _num(r.get("pm_err_arcsec_yr"), 2),
            "pm_sig": _num(r.get("pm_sig"), 2),
            "snr_deep": _num(r.get("snr_deep"), 1),
            "n_visits_detected": int(r.get("n_vis_det", 0)),
            "gaia_pm_arcsec_yr": g_pm, "gaia_g": g_mag,
            "track": track,
        })
    flagged = [c for c in out if c["flagged"] and c["in_view"]]
    top_rest = [c for c in out if not c["flagged"] and c["in_view"] and c["scored"]][:max(0, limit - len(flagged))]
    return {
        "target_id": field_id,
        "model": model_info(),
        "n_sources": len(rows),
        "n_scored": sum(1 for r in rows if r.get("scored")),
        "n_flagged": sum(1 for c in out if c["flagged"]),
        "expected_false_alarms": round(sum(1 for r in rows if r.get("scored")) * (meta.get("target_false_alarm_rate") or 0.01), 1),
        "candidates": flagged + top_rest,
    }
