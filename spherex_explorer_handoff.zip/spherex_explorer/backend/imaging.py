"""Render 2-D flux arrays to PNG data URLs with astronomical stretches and colormaps."""

import base64
import io
from typing import Optional

import numpy as np
from PIL import Image


def render_to_png_data_url(data: np.ndarray, stretch: str = "asinh", vmin: Optional[float] = None,
                           vmax: Optional[float] = None, colormap: str = "astronomical") -> str:
    arr = np.nan_to_num(np.asarray(data, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0)
    if vmin is None:
        vmin = float(np.percentile(arr, 1.0))
    if vmax is None:
        vmax = float(np.percentile(arr, 99.5))
    if vmax <= vmin:
        vmax = vmin + 1.0
    norm = np.clip((arr - vmin) / (vmax - vmin), 0.0, 1.0)

    if stretch == "asinh":
        beta = 0.1
        norm = np.arcsinh(norm / beta) / np.arcsinh(1.0 / beta)
    elif stretch == "log":
        norm = np.log10(1.0 + 9.0 * norm)
    elif stretch == "sqrt":
        norm = np.sqrt(norm)
    norm = np.clip(norm, 0.0, 1.0)
    byte_vals = (norm * 255.0).astype(np.uint8)

    h, w = byte_vals.shape
    rgb = np.zeros((h, w, 3), dtype=np.uint8)
    if colormap == "astronomical":
        t = norm
        rgb[:, :, 0] = np.clip(np.where(t < 0.5, t * 140, 70 + (t - 0.5) * 370), 0, 255).astype(np.uint8)
        rgb[:, :, 1] = np.clip(np.where(t < 0.5, t * 220, 110 + (t - 0.5) * 290), 0, 255).astype(np.uint8)
        rgb[:, :, 2] = np.clip(np.where(t < 0.5, t * 300, 150 + (t - 0.5) * 210), 0, 255).astype(np.uint8)
    elif colormap == "inverted":
        inv = 255 - byte_vals
        rgb[:, :, 0] = rgb[:, :, 1] = rgb[:, :, 2] = inv
    elif colormap == "difference":
        # Red = flux decrease (object left), cyan = flux increase (object arrived)
        pos = np.clip((norm - 0.5) * 2.0, 0.0, 1.0)
        neg = np.clip((0.5 - norm) * 2.0, 0.0, 1.0)
        rgb[:, :, 0] = (neg * 240 + pos * 50).astype(np.uint8)
        rgb[:, :, 1] = (pos * 200 + neg * 50).astype(np.uint8)
        rgb[:, :, 2] = (pos * 250 + neg * 50).astype(np.uint8)
    else:
        rgb[:, :, 0] = rgb[:, :, 1] = rgb[:, :, 2] = byte_vals

    buf = io.BytesIO()
    Image.fromarray(rgb).save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
