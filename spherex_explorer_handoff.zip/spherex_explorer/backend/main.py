"""
SPHEREx Explorer - REST API.

Serves real NASA SPHEREx data prepared by dataset/build_dataset.py (IRSA SPHEREx Level-2 spectral images):
stacked images per survey visit and detector, difference images, measured motion of the target,
per-exposure spectra, Gaia DR3 / CatWISE2020 overlays, and on-demand builds for new sky positions.
"""

import csv
import io
from typing import Optional

import astropy
from fastapi import FastAPI, File, HTTPException, Query, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend import dataset_service as ds
from backend import movers_service
from backend.astrometry import parse_astronomical_coordinates
from backend.catalog import DETECTOR_RANGES, SPECTRAL_CHANNELS
from backend.nasa_ingest import parse_uploaded_fits, query_gaia_crossmatch, query_nasa_irsa_cutout

MAX_UPLOAD_BYTES = 200 * 1024 * 1024

app = FastAPI(title="SPHEREx Explorer API",
              description="Real SPHEREx observations from NASA/IPAC IRSA, organized for time-domain exploration.",
              version="2.0.0")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

STRETCHES = {"asinh", "log", "linear", "sqrt"}
COLORMAPS = {"astronomical", "inverted", "grayscale"}


class CoordinateSearchRequest(BaseModel):
    query: Optional[str] = None
    ra: Optional[str] = None
    dec: Optional[str] = None
    fov_arcmin: float = Field(10.0, ge=1.0, le=12.0)
    channel: int = 0


class SaveCandidateRequest(BaseModel):
    name: str = Field(..., max_length=200)
    target_field: str = Field(..., max_length=200)
    ra_deg: float = Field(..., ge=0, lt=360)
    dec_deg: float = Field(..., ge=-90, le=90)
    ra_sexagesimal: str = Field("", max_length=40)
    dec_sexagesimal: str = Field("", max_length=40)
    category: str = Field(..., max_length=40)
    classification: str = Field(..., max_length=300)
    angular_displacement_arcsec: float = 0.0
    proper_motion_arcsec_yr: float = 0.0
    brightness_mag_var: float = 0.0
    confidence_score: float = 0.0
    epochs_detected: int = 0
    notes: Optional[str] = Field("", max_length=2000)


class BuildFieldRequest(BaseModel):
    ra: float = Field(..., ge=0, lt=360)
    dec: float = Field(..., ge=-90, le=90)
    name: Optional[str] = Field(None, max_length=120)


def _resolve_field(target_id: Optional[str], ra: Optional[float], dec: Optional[float]) -> str:
    if target_id:
        try:
            ds.load_index(target_id)
            return target_id
        except ds.FieldNotFound:
            raise HTTPException(404, detail={"message": f"'{target_id}' is not in the local SPHEREx dataset.",
                                             "can_build": False})
    if ra is None or dec is None:
        raise HTTPException(400, detail="Provide target_id or ra and dec.")
    fid = ds.find_field_near(ra, dec)
    if not fid:
        raise HTTPException(404, detail={"message": "This sky position is not in the local SPHEREx dataset yet.",
                                         "can_build": True, "field_id": ds.custom_field_id(ra, dec),
                                         "build": ds.build_status(ds.custom_field_id(ra, dec))})
    return fid


@app.get("/api/health")
def health_check():
    return {"status": "healthy", "service": "SPHEREx Explorer API",
            "data_source": "NASA/IPAC Infrared Science Archive (IRSA) - SPHEREx Level-2 spectral images",
            "astropy_version": astropy.__version__, **ds.dataset_health()}


@app.get("/api/targets")
def get_targets(include_custom: bool = Query(True)):
    return ds.list_targets(include_custom=include_custom)


@app.get("/api/targets/{target_id}")
def get_target(target_id: str):
    try:
        return ds.target_summary(target_id)
    except ds.FieldNotFound:
        raise HTTPException(404, detail=f"Target '{target_id}' is not in the dataset.")


def _norm(s: str) -> str:
    return "".join(ch for ch in s.lower() if ch.isalnum())


@app.post("/api/search")
def search_coordinates(payload: CoordinateSearchRequest):
    """Resolve a target name or RA/Dec (decimal or sexagesimal) to a dataset field."""
    targets = ds.list_targets()
    if payload.query and not payload.ra:
        q = _norm(payload.query)
        if len(q) >= 3:
            for t in targets:
                names = [t["name"], t["id"]] + t.get("designations", [])
                if any(_norm(n) == q or (len(q) >= 4 and _norm(n).startswith(q)) for n in names):
                    c = t["coordinates"]
                    return {"matched_target": t, "is_preconfigured": not t["is_custom"], "ra_deg": c["ra_deg"],
                            "dec_deg": c["dec_deg"], "ra_sexagesimal": c["ra_sexagesimal"],
                            "dec_sexagesimal": c["dec_sexagesimal"], "fov_arcmin": t["fov_arcmin"],
                            "default_channel": 0, "in_dataset": True, "field_id": t["id"]}

    ra_in, dec_in = payload.ra, payload.dec
    if not ra_in and payload.query:
        parts = payload.query.split(",")
        if len(parts) == 2:
            ra_in, dec_in = parts[0].strip(), parts[1].strip()
        else:
            toks = payload.query.split()
            if len(toks) >= 2 and len(toks) % 2 == 0:
                ra_in, dec_in = " ".join(toks[:len(toks) // 2]), " ".join(toks[len(toks) // 2:])
    if not ra_in or not dec_in:
        raise HTTPException(400, detail="Enter a target name, or RA and Dec (e.g. '133.786, -7.244' or "
                                        "'08h55m10.8s, -07d14m42s').")
    try:
        ra_deg, dec_deg, ra_sex, dec_sex = parse_astronomical_coordinates(ra_in, dec_in)
    except Exception as exc:
        raise HTTPException(400, detail=str(exc))
    if not (-90 <= dec_deg <= 90):
        raise HTTPException(400, detail="Declination must be between -90 and +90 degrees.")
    fid = ds.find_field_near(ra_deg, dec_deg)
    match = ds.target_summary(fid) if fid else None
    return {"matched_target": match, "is_preconfigured": bool(match and not match["is_custom"]),
            "ra_deg": ra_deg, "dec_deg": dec_deg, "ra_sexagesimal": ra_sex, "dec_sexagesimal": dec_sex,
            "fov_arcmin": payload.fov_arcmin, "default_channel": 0, "in_dataset": bool(fid),
            "field_id": fid or ds.custom_field_id(ra_deg, dec_deg)}


@app.get("/api/observations")
def get_observations(target_id: Optional[str] = Query(None), ra: Optional[float] = Query(None, ge=0, lt=360),
                     dec: Optional[float] = Query(None, ge=-90, le=90),
                     fov_arcmin: float = Query(10.0, ge=1.5, le=12.0),
                     detector: Optional[str] = Query(None, pattern=r"^[Dd][1-6]$"),
                     channel: int = Query(0, ge=0, le=102),
                     stretch: str = Query("asinh"), colormap: str = Query("astronomical")):
    """One stacked SPHEREx image per survey visit for the chosen detector, on a common sky grid."""
    fid = _resolve_field(target_id, ra, dec)
    det = detector or ds.target_summary(fid)["default_detector"]
    try:
        return ds.get_observations(fid, det, fov_arcmin, stretch if stretch in STRETCHES else "asinh",
                                   colormap if colormap in COLORMAPS else "astronomical")
    except ds.FieldNotFound as exc:
        raise HTTPException(404, detail=str(exc))


@app.get("/api/difference")
def get_difference(target_id: Optional[str] = Query(None), ra: Optional[float] = Query(None, ge=0, lt=360),
                   dec: Optional[float] = Query(None, ge=-90, le=90),
                   fov_arcmin: float = Query(10.0, ge=1.5, le=12.0),
                   detector: Optional[str] = Query(None, pattern=r"^[Dd][1-6]$"),
                   channel: int = Query(0, ge=0, le=102),
                   epoch1: int = Query(0, ge=0), epoch2: int = Query(1, ge=0), stretch: str = Query("linear")):
    """Difference of two visit stacks (later minus earlier): movers show as a red/cyan pair."""
    fid = _resolve_field(target_id, ra, dec)
    det = detector or ds.target_summary(fid)["default_detector"]
    try:
        return ds.get_difference(fid, det, epoch1, epoch2, fov_arcmin, stretch)
    except ds.FieldNotFound as exc:
        raise HTTPException(404, detail=str(exc))


@app.get("/api/spectrum")
def get_spectrum(target_id: Optional[str] = Query(None), ra: Optional[float] = Query(None, ge=0, lt=360),
                 dec: Optional[float] = Query(None, ge=-90, le=90)):
    """Spectrum measured from every SPHEREx exposure (each samples a different wavelength at the target)."""
    return ds.get_spectrum(_resolve_field(target_id, ra, dec))


@app.get("/api/motion")
def get_motion(target_id: Optional[str] = Query(None), ra: Optional[float] = Query(None, ge=0, lt=360),
               dec: Optional[float] = Query(None, ge=-90, le=90)):
    """Proper motion fitted to the target's measured SPHEREx positions, compared with the catalog value."""
    fid = _resolve_field(target_id, ra, dec)
    m = ds.measure_motion(fid)
    pts = [{k: e[k] for k in ("visit_id", "detector", "mjd", "centroid_ra", "centroid_dec", "centroid_offset_arcsec",
                              "peak_snr")} for e in ds.load_exposures(fid) if e["centroid_ok"]]
    return {"target_id": fid, "fit": {k: v for k, v in m.items() if k != "ref"} if m else None, "points": pts}


@app.get("/api/movers")
def get_movers(target_id: Optional[str] = Query(None), ra: Optional[float] = Query(None, ge=0, lt=360),
               dec: Optional[float] = Query(None, ge=-90, le=90),
               fov_arcmin: float = Query(10.0, ge=1.5, le=12.0), limit: int = Query(12, ge=1, le=100)):
    """ML moving-object candidates for every source in the field (LightGBM trained on injections into real stacks)."""
    fid = _resolve_field(target_id, ra, dec)
    try:
        return movers_service.get_candidates(fid, fov_arcmin, limit)
    except movers_service.ModelUnavailable as exc:
        raise HTTPException(503, detail=str(exc))
    except ds.FieldNotFound as exc:
        raise HTTPException(404, detail=str(exc))


@app.get("/api/catalog")
def get_catalog(target_id: Optional[str] = Query(None), ra: Optional[float] = Query(None, ge=0, lt=360),
                dec: Optional[float] = Query(None, ge=-90, le=90), source: str = Query("gaia"),
                fov_arcmin: float = Query(10.0, ge=1.5, le=12.0)):
    """Gaia DR3 or CatWISE2020 sources in the field, propagated to the SPHEREx epoch, in display pixels."""
    fid = _resolve_field(target_id, ra, dec)
    try:
        return ds.get_catalog(fid, source, fov_arcmin)
    except ds.FieldNotFound as exc:
        raise HTTPException(400, detail=str(exc))


@app.post("/api/fields")
def build_field(payload: BuildFieldRequest):
    """Start building a new field from IRSA (runs in the background; poll GET /api/fields/{field_id})."""
    existing = ds.find_field_near(payload.ra, payload.dec)
    if existing:
        return {"field_id": existing, "state": "done", "message": "Already in the dataset"}
    return ds.start_field_build(payload.ra, payload.dec, payload.name)


@app.get("/api/fields/{field_id}")
def field_status(field_id: str):
    return ds.build_status(field_id)


@app.get("/api/discoveries")
def get_discoveries(category: Optional[str] = Query(None), sort_by: str = Query("confidence_score")):
    items = ds.list_discoveries()
    if category and category != "all":
        items = [c for c in items if c.get("category") == category]
    key = {"proper_motion": "proper_motion_arcsec_yr", "brightness_var": "brightness_mag_var"}.get(sort_by,
                                                                                                    "confidence_score")
    items.sort(key=lambda x: x.get(key) or 0, reverse=True)
    return items


@app.post("/api/discoveries")
def save_discovery(candidate: SaveCandidateRequest):
    record = ds.save_discovery(candidate.model_dump())
    return {"message": "Candidate saved", "candidate": record}


@app.get("/api/discoveries/export")
def export_discoveries_csv():
    cols = ["id", "name", "target_field", "ra_deg", "dec_deg", "ra_sexagesimal", "dec_sexagesimal", "category",
            "classification", "angular_displacement_arcsec", "proper_motion_arcsec_yr", "brightness_mag_var",
            "confidence_score", "epochs_detected", "status", "date_flagged", "notes"]
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(cols)
    for c in ds.list_discoveries():
        w.writerow([c.get(k, "") for k in cols])
    return Response(out.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=spherex_discoveries.csv"})


@app.get("/api/detectors")
def get_detector_info():
    return DETECTOR_RANGES


@app.get("/api/channels")
def get_all_channels():
    return SPECTRAL_CHANNELS


@app.post("/api/import/fits")
async def upload_fits_file(file: UploadFile = File(...)):
    """Parse an uploaded FITS file (.fits/.fit): image, WCS, header cards and a rendered preview."""
    contents = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(contents) == 0:
        raise HTTPException(status_code=400, detail="Empty file uploaded.")
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="FITS file is larger than 200 MB.")
    result = parse_uploaded_fits(contents, filename=file.filename or "uploaded.fits")
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result.get("message", "Error parsing FITS file"))
    return result


class IrsaQueryRequest(BaseModel):
    ra: float = Field(..., ge=0, lt=360)
    dec: float = Field(..., ge=-90, le=90)
    mission: str = Field("spherex", max_length=20)
    fov_arcmin: float = Field(10.0, ge=1.0, le=30.0)


@app.post("/api/import/irsa")
def query_nasa_irsa(req: IrsaQueryRequest):
    """Live IRSA SIA query: which SPHEREx Level-2 images cover this position (per detector, dates, cutout URL)."""
    res = query_nasa_irsa_cutout(req.ra, req.dec, req.mission, req.fov_arcmin)
    if res.get("status") == "error":
        raise HTTPException(status_code=502, detail=res.get("message"))
    return res


@app.get("/api/crossmatch/gaia")
def get_gaia_crossmatch(ra: float = Query(..., ge=0, lt=360), dec: float = Query(..., ge=-90, le=90),
                        radius_arcmin: float = Query(6.0, gt=0, le=15.0)):
    """Real Gaia DR3 sources near a position (local dataset catalog if available, else live IRSA query)."""
    try:
        return query_gaia_crossmatch(ra, dec, radius_arcmin)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gaia query failed: {exc}")
