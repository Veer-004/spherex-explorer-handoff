"""
Data import helpers for SPHEREx Explorer:

1. Parse user-supplied FITS files (.fits/.fit) and render a preview.
2. Live query of NASA/IPAC IRSA for SPHEREx Level-2 images covering a position (SIA).
3. Gaia DR3 sources around a position: from the local dataset's saved catalog when the field is
   already downloaded, otherwise a live query of IRSA's gaia_dr3_source table.

Everything returned here is real data; on network failure the functions report an error instead
of substituting placeholder values.
"""

import csv
import io
import math
from collections import Counter
from typing import Any, Dict, List

import numpy as np
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.time import Time
from astropy.wcs import WCS
import astropy.units as u

from backend.astrometry import pixel_to_world
from backend.imaging import render_to_png_data_url

IRSA_SIA_URL = "https://irsa.ipac.caltech.edu/SIA"
SPHEREX_COLLECTIONS = ["spherex_dr1", "spherex_qr3"]
DETECTOR_BANDS = {1: "0.75-1.11 um", 2: "1.11-1.64 um", 3: "1.64-2.42 um",
                  4: "2.42-3.82 um", 5: "3.82-4.42 um", 6: "4.42-5.00 um"}


def parse_uploaded_fits(file_bytes: bytes, filename: str = "uploaded.fits") -> Dict[str, Any]:
    """Read the first 2-D image in an uploaded FITS file, its WCS and header, and render a preview."""
    try:
        with fits.open(io.BytesIO(file_bytes), ignore_missing_end=True) as hdul:
            target_hdu = None
            for hdu in hdul:
                if hdu.data is not None and getattr(hdu.data, "ndim", 0) >= 2:
                    target_hdu = hdu
                    break
            if target_hdu is None:
                raise ValueError("No 2D image array found in uploaded FITS file.")

            data = np.squeeze(target_hdu.data)
            while data.ndim > 2:               # data cube: show the first plane
                data = data[0]
            data = data.astype(np.float32)
            finite = data[np.isfinite(data)]
            fill = float(np.median(finite)) if finite.size else 0.0
            data = np.where(np.isfinite(data), data, fill)
            header = target_hdu.header

            try:
                wcs = WCS(header)
                has_wcs = bool(wcs.is_celestial)
            except Exception:
                wcs, has_wcs = None, False

            h, w = data.shape
            if has_wcs:
                ra_center, dec_center = pixel_to_world(wcs.celestial, (w - 1) / 2.0, (h - 1) / 2.0)
                try:
                    c1 = wcs.celestial.pixel_to_world(0, (h - 1) / 2.0)
                    c2 = wcs.celestial.pixel_to_world(w - 1, (h - 1) / 2.0)
                    fov_arcmin = float(c1.separation(c2).arcminute)
                except Exception:
                    fov_arcmin = 0.0
            else:
                ra_center = dec_center = 0.0
                fov_arcmin = 0.0

            cards = []
            for k in list(header.keys())[:60]:
                if k and k.strip() and k not in ("COMMENT", "HISTORY"):
                    cards.append({"key": k, "value": str(header[k]), "comment": header.comments[k] or ""})

            return {
                "status": "success",
                "filename": filename,
                "dimensions": [w, h],
                "has_wcs": has_wcs,
                "center_coordinates": {"ra_deg": round(ra_center, 5), "dec_deg": round(dec_center, 5)},
                "fov_arcmin": round(fov_arcmin, 2),
                "peak_flux": round(float(np.max(data)), 3),
                "mean_flux": round(float(np.mean(data)), 4),
                "rms_noise": round(float(np.std(data)), 4),
                "telescope": str(header.get("TELESCOP", "Unknown")),
                "instrument": str(header.get("INSTRUME", "Unknown")),
                "filter": str(header.get("FILTER", header.get("BANDPASS", "Unknown"))),
                "bunit": str(header.get("BUNIT", "")),
                "image_url": render_to_png_data_url(data[::-1] if has_wcs else data, stretch="asinh",
                                                    colormap="astronomical"),
                "header_cards": cards,
                "raw_preview_stats": {"min": float(np.min(data)), "max": float(np.max(data)),
                                      "p99": float(np.percentile(data, 99.0))},
            }
    except Exception as e:
        return {"status": "error", "message": f"Failed to parse FITS data: {e}"}


def _gaia_row(r: Dict[str, Any]) -> Dict[str, Any]:
    def f(k):
        v = r.get(k)
        try:
            v = float(v)
            return None if math.isnan(v) else v
        except (TypeError, ValueError):
            return None
    pmra, pmdec, plx, g = f("pmra"), f("pmdec"), f("parallax"), f("phot_g_mean_mag")
    total = math.hypot(pmra, pmdec) if pmra is not None and pmdec is not None else None
    return {
        "source_id": f"Gaia DR3 {r.get('source_id')}",
        "ra_deg": round(f("ra"), 6), "dec_deg": round(f("dec"), 6),
        "g_mag": round(g, 2) if g is not None else None,
        "pm_ra_mas_yr": round(pmra, 2) if pmra is not None else None,
        "pm_dec_mas_yr": round(pmdec, 2) if pmdec is not None else None,
        "total_pm_mas_yr": round(total, 2) if total is not None else None,
        "parallax_mas": round(plx, 3) if plx is not None else None,
        "dist_pc": round(1000.0 / plx, 1) if plx and plx > 0 else None,
    }


def query_gaia_crossmatch(ra: float, dec: float, radius_arcmin: float = 6.0, limit: int = 300) -> List[Dict[str, Any]]:
    """Real Gaia DR3 sources (ref. epoch J2016.0) within radius_arcmin, brightest first."""
    from backend import dataset_service as ds

    radius_arcmin = max(0.1, min(radius_arcmin, 15.0))
    center = SkyCoord(ra * u.deg, dec * u.deg)
    rows: List[Dict[str, Any]] = []

    fid = ds.find_field_near(ra, dec)
    path = ds.DATASET_DIR / fid / "catalogs" / "gaia_dr3.csv" if fid else None
    if path and path.exists():
        with open(path, newline="") as fh:
            for r in csv.DictReader(fh):
                try:
                    sep = center.separation(SkyCoord(float(r["ra"]) * u.deg, float(r["dec"]) * u.deg)).arcmin
                except (TypeError, ValueError):
                    continue
                if sep <= radius_arcmin:
                    rows.append(r)
    else:
        from astroquery.ipac.irsa import Irsa
        q = ("SELECT source_id, ra, dec, pmra, pmdec, parallax, phot_g_mean_mag FROM gaia_dr3_source "
             f"WHERE CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra}, {dec}, {radius_arcmin / 60.0}))=1")
        tab = Irsa.query_tap(q).to_table()
        rows = [{k: tab[k][i] for k in tab.colnames} for i in range(len(tab))]

    out = [_gaia_row(r) for r in rows]
    out.sort(key=lambda s: (s["g_mag"] is None, s["g_mag"]))
    return out[:limit]


def query_nasa_irsa_cutout(ra: float, dec: float, mission: str = "spherex", fov_arcmin: float = 10.0) -> Dict[str, Any]:
    """Ask IRSA which SPHEREx Level-2 images cover (ra, dec): counts per detector, dates, example cutout URL."""
    from backend import dataset_service as ds

    if mission.lower() != "spherex":
        return {"status": "error", "message": "Only SPHEREx is supported for live queries."}
    try:
        from astroquery.ipac.irsa import Irsa
        res = Irsa.query_sia(pos=(SkyCoord(ra, dec, unit="deg"), 2 * u.arcsec), collection=SPHEREX_COLLECTIONS)
    except Exception as e:
        return {"status": "error", "message": f"IRSA query failed: {e}"}

    science = [r for r in res if str(r["dataproduct_subtype"]).strip() == "science"]
    dets = Counter(int(str(r["energy_bandpassname"]).strip().split("D")[-1]) for r in science)
    colls = Counter(str(r["obs_collection"]).strip() for r in science)
    times = sorted(float(r["t_min"]) for r in science)
    example = str(science[0]["access_url"]).strip() if science else None
    size_deg = fov_arcmin / 60.0
    field = ds.find_field_near(ra, dec)
    return {
        "status": "connected" if science else "no_data",
        "archive": "NASA / IPAC Infrared Science Archive (IRSA)",
        "mission": "SPHEREX",
        "n_images": len(science),
        "collections": dict(colls),
        "date_range": [Time(times[0], format="mjd").isot[:10], Time(times[-1], format="mjd").isot[:10]] if times else None,
        "query_parameters": {"ra": ra, "dec": dec, "fov_arcmin": fov_arcmin, "coordinate_frame": "ICRS"},
        "protocols": {
            "sia2_endpoint": f"{IRSA_SIA_URL}?COLLECTION=spherex_dr1&POS=CIRCLE+{ra:.6f}+{dec:.6f}+0.0006",
            "ibe_cutout_service": f"{example}?center={ra:.6f},{dec:.6f}d&size={size_deg:.4f}" if example else "",
            "tap_table_access": "https://irsa.ipac.caltech.edu/TAP",
        },
        "available_bands": [
            {"band": f"SPHEREx D{d}", "wavelength": DETECTOR_BANDS[d], "format": f"{n} Level-2 spectral images (FITS)"}
            for d, n in sorted(dets.items())
        ],
        "in_dataset": bool(field),
        "field_id": field or ds.custom_field_id(ra, dec),
        "instructions": ("This field is already in the local dataset." if field else
                         "Open this position in Sky Explorer and choose 'Download from IRSA' to stack these images, "
                         "or upload a downloaded FITS file in the 'Upload FITS' tab.")
        if science else "IRSA has no SPHEREx images covering this position yet.",
    }
