"""
Train and evaluate moving-object classifiers on ml/movers/output/training_set.csv.

Supports 3 primary tree-based models optimized with Optuna:
  - XGBoost (gradient-boosted decision trees)
  - Random Forest (bagged ensemble of trees)
  - LightGBM (leaf-wise gradient boosting)
Plus standard baselines:
  - logistic regression
  - rule (proper motion >= 1"/yr, ranked by significance)

Evaluation is leave-fields-out (GroupKFold by field). Every score comes from a model
that never saw that field. Operating point is calibrated to <= 1% false alarms on real
Gaia DR3 non-moving stars.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import lightgbm as lgb
import xgboost as xgb
import optuna

optuna.logging.set_verbosity(optuna.logging.WARNING)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import movers as M  # noqa: E402

OUT = Path(__file__).resolve().parent / "output"
COLOR_FEATURES = {"c12", "c23", "c34", "c45", "c56", "frac_blue"}
FEATURES = [f for f in M.FEATURES if f not in COLOR_FEATURES]
SEED = 7
MIN_VISITS = 3            # motion is only claimed with >= 3 visits that detect the source
TARGET_FALSE_ALARM = 0.01  # operating point: 1% of real non-moving stars flagged


def valid_mask(df: pd.DataFrame) -> np.ndarray:
    return (df["n_vis_det"].fillna(0) >= MIN_VISITS).to_numpy()


def rule_score(df: pd.DataFrame) -> np.ndarray:
    sig = df["pm_sig"].fillna(0).to_numpy()
    pm = df["pm_fit_arcsec_yr"].fillna(0).to_numpy()
    return np.where((pm >= M.MOVER_THRESHOLD_ARCSEC_YR) & valid_mask(df), sig, 0.0)


def threshold_for_false_alarm(scores_static: np.ndarray, target: float) -> float:
    """Smallest threshold that flags at most `target` of these real non-moving stars."""
    s = np.sort(scores_static)
    k = int(np.floor(target * len(s)))
    return float(s[-k - 1]) + 1e-9 if len(s) > k else float(s.max()) + 1e-9


def make_logistic():
    return make_pipeline(
        SimpleImputer(strategy="median"),
        StandardScaler(),
        LogisticRegression(max_iter=2000, class_weight="balanced", C=0.5, random_state=SEED)
    )


def make_lgbm(params: dict | None = None):
    p = {
        "n_estimators": 300,
        "learning_rate": 0.03,
        "num_leaves": 22,
        "min_child_samples": 30,
        "subsample": 0.8,
        "subsample_freq": 1,
        "colsample_bytree": 0.85,
        "reg_lambda": 0.1,
        "class_weight": "balanced",
        "random_state": SEED,
        "verbose": -1,
        "n_jobs": -1,
    }
    if params:
        p.update(params)
    return lgb.LGBMClassifier(**p)


def make_xgboost(params: dict | None = None):
    p = {
        "n_estimators": 150,
        "learning_rate": 0.03,
        "max_depth": 5,
        "min_child_weight": 5,
        "subsample": 0.75,
        "colsample_bytree": 0.75,
        "reg_lambda": 0.3,
        "scale_pos_weight": 1.1,
        "eval_metric": "logloss",
        "random_state": SEED,
        "n_jobs": -1,
    }
    if params:
        p.update(params)
    return xgb.XGBClassifier(**p)


def make_random_forest(params: dict | None = None):
    p = {
        "n_estimators": 150,
        "max_depth": 14,
        "min_samples_split": 8,
        "min_samples_leaf": 4,
        "max_features": 0.55,
        "class_weight": "balanced",
        "random_state": SEED,
        "n_jobs": -1,
    }
    if params:
        p.update(params)
    return make_pipeline(
        SimpleImputer(strategy="median"),
        RandomForestClassifier(**p)
    )


def optimize_hyperparameters(X: pd.DataFrame, y: np.ndarray, groups: np.ndarray, n_trials: int = 20) -> dict:
    """Run Optuna studies on injected data using Leave-Fields-Out cross validation."""
    print(f"\n[Optuna] Optimizing hyperparameters across 5-fold Leave-Fields-Out CV ({n_trials} trials each)...")
    gkf = GroupKFold(n_splits=5)
    best_params = {}

    def cv_score(make_fn):
        oof = np.zeros(len(y))
        for tr, te in gkf.split(X, y, groups):
            m = make_fn()
            m.fit(X.iloc[tr], y[tr])
            oof[te] = m.predict_proba(X.iloc[te])[:, 1]
        return average_precision_score(y, oof)

    # 1. LightGBM
    def obj_lgb(trial):
        p = {
            "n_estimators": trial.suggest_int("n_estimators", 100, 450, step=50),
            "learning_rate": trial.suggest_float("learning_rate", 0.015, 0.12, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 12, 45),
            "min_child_samples": trial.suggest_int("min_child_samples", 15, 45),
            "subsample": trial.suggest_float("subsample", 0.65, 0.95),
            "subsample_freq": 1,
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.65, 0.95),
            "reg_lambda": trial.suggest_float("reg_lambda", 0.01, 5.0, log=True),
            "class_weight": "balanced",
            "random_state": SEED,
            "verbose": -1,
            "n_jobs": -1,
        }
        return cv_score(lambda: lgb.LGBMClassifier(**p))

    study_lgb = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
    study_lgb.optimize(obj_lgb, n_trials=n_trials)
    best_params["lightgbm"] = study_lgb.best_params
    print(f"  -> LightGBM best Average Precision: {study_lgb.best_value:.4f}")

    # 2. XGBoost
    def obj_xgb(trial):
        p = {
            "n_estimators": trial.suggest_int("n_estimators", 100, 450, step=50),
            "learning_rate": trial.suggest_float("learning_rate", 0.015, 0.12, log=True),
            "max_depth": trial.suggest_int("max_depth", 3, 8),
            "min_child_weight": trial.suggest_int("min_child_weight", 2, 8),
            "subsample": trial.suggest_float("subsample", 0.65, 0.95),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.60, 0.95),
            "reg_lambda": trial.suggest_float("reg_lambda", 0.05, 5.0, log=True),
            "scale_pos_weight": trial.suggest_float("scale_pos_weight", 0.85, 1.35),
            "eval_metric": "logloss",
            "random_state": SEED,
            "n_jobs": -1,
        }
        return cv_score(lambda: xgb.XGBClassifier(**p))

    study_xgb = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
    study_xgb.optimize(obj_xgb, n_trials=n_trials)
    best_params["xgboost"] = study_xgb.best_params
    print(f"  -> XGBoost best Average Precision: {study_xgb.best_value:.4f}")

    # 3. Random Forest
    def obj_rf(trial):
        p = {
            "n_estimators": trial.suggest_int("n_estimators", 100, 300, step=50),
            "max_depth": trial.suggest_int("max_depth", 8, 20),
            "min_samples_split": trial.suggest_int("min_samples_split", 2, 12),
            "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 6),
            "max_features": trial.suggest_float("max_features", 0.35, 0.75),
            "class_weight": "balanced",
            "random_state": SEED,
            "n_jobs": -1,
        }
        return cv_score(lambda: make_pipeline(SimpleImputer(strategy="median"), RandomForestClassifier(**p)))

    study_rf = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
    study_rf.optimize(obj_rf, n_trials=n_trials)
    best_params["random_forest"] = study_rf.best_params
    print(f"  -> Random Forest best Average Precision: {study_rf.best_value:.4f}")

    (OUT / "best_hyperparameters.json").write_text(json.dumps(best_params, indent=2))
    return best_params


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=20, help="Number of Optuna trials per model")
    parser.add_argument("--skip-optuna", action="store_true", help="Use stored or default hyperparameters")
    args = parser.parse_args()

    df = pd.read_csv(OUT / "training_set.csv")
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    train = df[(df["label"] >= 0) & (df["benchmark"] == 0)].reset_index(drop=True)
    X, y, groups = train[FEATURES], train["label"].to_numpy(), train["field"].to_numpy()
    n_fields = train["field"].nunique()
    gkf = GroupKFold(n_splits=min(5, n_fields))

    is_inj = (train["source"] == "injected").to_numpy()
    valid = valid_mask(train)
    real_static = ((train["source"] == "real") & (y == 0)).to_numpy()
    real_mover = ((train["source"] == "real") & (y == 1)).to_numpy()
    inj_mover = (is_inj & (y == 1))

    # Optuna Hyperparameter Optimization
    best_params = {}
    params_file = OUT / "best_hyperparameters.json"
    if not args.skip_optuna:
        best_params = optimize_hyperparameters(X.iloc[is_inj].reset_index(drop=True),
                                              y[is_inj], groups[is_inj], n_trials=args.trials)
    elif params_file.exists():
        best_params = json.loads(params_file.read_text())

    model_factories = {
        "xgboost": lambda: make_xgboost(best_params.get("xgboost")),
        "random_forest": lambda: make_random_forest(best_params.get("random_forest")),
        "lightgbm": lambda: make_lgbm(best_params.get("lightgbm")),
        "logistic": make_logistic,
    }

    model_names = ["xgboost", "random_forest", "lightgbm", "logistic", "rule"]
    oof = {k: np.zeros(len(train)) for k in model_names}
    oof["rule"] = rule_score(train)
    thr_row = {k: np.zeros(len(train)) for k in model_names}

    # Cross-fitting loop to choose per-field false-alarm threshold on held-out fields' real Gaia stars
    for tr, te in gkf.split(X, y, groups):
        fit_rows = tr[is_inj[tr]]
        for name in ["xgboost", "random_forest", "lightgbm", "logistic"]:
            m = model_factories[name]()
            m.fit(X.iloc[fit_rows], y[fit_rows])
            oof[name][tr] = np.where(valid[tr], m.predict_proba(X.iloc[tr])[:, 1], 0.0)
            oof[name][te] = np.where(valid[te], m.predict_proba(X.iloc[te])[:, 1], 0.0)
            thr_row[name][te] = threshold_for_false_alarm(oof[name][tr][real_static[tr]], TARGET_FALSE_ALARM)
        thr_row["rule"][te] = threshold_for_false_alarm(oof["rule"][tr][real_static[tr]], TARGET_FALSE_ALARM)

    # Clean out-of-fold inference on test folds
    for name in ["xgboost", "random_forest", "lightgbm", "logistic"]:
        for tr, te in gkf.split(X, y, groups):
            fit_rows = tr[is_inj[tr]]
            m = model_factories[name]().fit(X.iloc[fit_rows], y[fit_rows])
            oof[name][te] = np.where(valid[te], m.predict_proba(X.iloc[te])[:, 1], 0.0)

    thresholds = {k: float(np.median(v)) for k, v in thr_row.items()}
    metrics = {
        "n_train_rows_injected": int(is_inj.sum()),
        "n_fields": int(n_fields),
        "n_injected_movers": int((is_inj & (y == 1)).sum()),
        "n_injected_non_movers": int((is_inj & (y == 0)).sum()),
        "n_real_static_eval": int(real_static.sum()),
        "n_real_mover_eval": int(real_mover.sum()),
        "mover_threshold_arcsec_yr": M.MOVER_THRESHOLD_ARCSEC_YR,
        "min_visits": MIN_VISITS,
        "target_false_alarm_rate": TARGET_FALSE_ALARM,
        "features_used": FEATURES,
        "models": {},
    }

    yi = y[is_inj]
    for name in model_names:
        s = oof[name]
        flag = s >= thr_row[name]
        si, fi = s[is_inj], flag[is_inj]
        tp, fp = int((fi & (yi == 1)).sum()), int((fi & (yi == 0)).sum())
        tn, fn = int((~fi & (yi == 0)).sum()), int((~fi & (yi == 1)).sum())
        metrics["models"][name] = {
            "roc_auc_injected": round(float(roc_auc_score(yi, si)), 4),
            "average_precision_injected": round(float(average_precision_score(yi, si)), 4),
            "threshold_median_across_folds": round(thresholds[name], 4),
            "precision_injected": round(tp / max(1, tp + fp), 4),
            "recall_injected": round(tp / max(1, int(yi.sum())), 4),
            "confusion_matrix_injected": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
            "confusion_matrix_real_static": {
                "tn": int((~flag[real_static]).sum()) if real_static.any() else 0,
                "fp": int(flag[real_static].sum()) if real_static.any() else 0,
                "total": int(real_static.sum()),
            },
            "false_alarm_rate_real_static_stars": round(float(flag[real_static].mean()), 4) if real_static.any() else None,
            "n_false_alarms_real": int(flag[real_static].sum()),
            "recall_real_gaia_movers": round(float(flag[real_mover].mean()), 4) if real_mover.any() else None,
            "best_hyperparameters": best_params.get(name),
        }

    # Train final models on all injected data and persist them
    final_models = {}
    for name in ["xgboost", "random_forest", "lightgbm"]:
        m = model_factories[name]()
        m.fit(X[is_inj], y[is_inj])
        final_models[name] = m

    # Save artifacts
    final_models["lightgbm"].booster_.save_model(str(OUT / "model_lightgbm.txt"))
    final_models["xgboost"].save_model(str(OUT / "model_xgboost.json"))
    joblib.dump(final_models["random_forest"], OUT / "model_random_forest.joblib")

    # Select best model based on Average Precision on injected movers
    candidate_best = ["xgboost", "random_forest", "lightgbm"]
    best_name = max(candidate_best, key=lambda k: metrics["models"][k]["average_precision_injected"])
    best_model = final_models[best_name]
    print(f"\n[Selection] Best model: {best_name.upper()} (AP={metrics['models'][best_name]['average_precision_injected']:.4f}, Recall={metrics['models'][best_name]['recall_injected']:.4f})")

    def score_frame(frame: pd.DataFrame, model_name: str) -> np.ndarray:
        m = final_models[model_name]
        return np.where(valid_mask(frame), m.predict_proba(frame[FEATURES])[:, 1], 0.0)

    final_thr = threshold_for_false_alarm(score_frame(train[real_static], best_name), TARGET_FALSE_ALARM)
    rule_thr = threshold_for_false_alarm(oof["rule"][real_static], TARGET_FALSE_ALARM)
    metrics["deployed_model"] = best_name
    metrics["deployed_threshold_p"] = round(final_thr, 4)
    metrics["deployed_threshold_rule_sigma"] = round(rule_thr, 3)

    # Score benchmarks
    bench = df[df["benchmark"] == 1].copy()
    if len(bench):
        bench["p_mover"] = score_frame(bench, best_name)
        bench["rule_score"] = rule_score(bench)
        metrics["benchmarks"] = [
            {"field": r.field, "catalog_pm_arcsec_yr": round(float(r.true_pm_arcsec_yr), 2),
             "measured_pm_arcsec_yr": None if pd.isna(r.pm_fit_arcsec_yr) else round(float(r.pm_fit_arcsec_yr), 2),
             "pm_sig": None if pd.isna(r.pm_sig) else round(float(r.pm_sig), 1), "visits_detected": int(r.n_vis_det),
             "p_mover": round(float(r.p_mover), 3), "ml_flag": bool(r.p_mover >= final_thr),
             "rule_flag": bool(r.rule_score >= rule_thr), "model_used": best_name}
            for r in bench.itertuples()]

    # Save out-of-fold and real candidates predictions
    for name in model_names:
        train[f"p_oof_{name}"] = oof[name]
    train["p_oof_best"] = oof[best_name]
    train.to_csv(OUT / "oof_predictions.csv", index=False)

    real_unl = df[(df["source"] == "real") & (df["label"] < 0) & (df["benchmark"] == 0)].copy()
    if len(real_unl):
        real_unl["p_mover"] = score_frame(real_unl, best_name)
        real_unl["flagged"] = real_unl["p_mover"] >= final_thr

    is_real = (train["source"] == "real").to_numpy()
    real_lab = train[is_real].assign(p_mover=oof[best_name][is_real],
                                     flagged=oof[best_name][is_real] >= thr_row[best_name][is_real])
    cands = pd.concat([real_lab, real_unl], ignore_index=True).sort_values("p_mover", ascending=False)
    keep = ["field", "x", "y", "label", "gaia_pm_arcsec_yr", "gaia_g", "p_mover", "flagged", "pm_fit_arcsec_yr",
            "pm_err_arcsec_yr", "pm_sig", "snr_deep", "n_vis_det", "nn_dist_px"]
    cands[keep].to_csv(OUT / "candidates_real.csv", index=False)
    metrics["real_sources_flagged"] = {
        "unlabelled_flagged": int((real_unl["p_mover"] >= final_thr).sum()) if len(real_unl) else 0,
        "n_unlabelled": int(len(real_unl)),
    }

    # Completeness analysis
    inj = pd.read_csv(OUT / "injections.csv")
    flagged_ids = set(train.loc[is_inj & (oof[best_name] >= thr_row[best_name]), "inj_id"])
    rule_ids = set(train.loc[is_inj & (oof["rule"] >= thr_row["rule"]), "inj_id"])
    movers = inj[inj["label"] == 1].copy()
    movers["found_ml"] = movers["inj_id"].isin(flagged_ids)
    movers["found_rule"] = movers["inj_id"].isin(rule_ids)
    pm_bins = [1, 2, 4, 8, 15.01]
    snr_bins = [3, 5, 10, 20, 50, 300, 3000.01]
    comp = {}
    for col in ("found_ml", "found_rule"):
        tab = movers.groupby([pd.cut(movers["true_pm_arcsec_yr"], pm_bins), pd.cut(movers["snr_target"], snr_bins)],
                             observed=False)[col].mean().unstack()
        comp[col] = tab
    metrics["completeness_ml"] = {str(i): {str(c): (None if pd.isna(v) else round(float(v), 3)) for c, v in row.items()}
                                  for i, row in comp["found_ml"].iterrows()}
    metrics["completeness_rule"] = {str(i): {str(c): (None if pd.isna(v) else round(float(v), 3)) for c, v in row.items()}
                                    for i, row in comp["found_rule"].iterrows()}
    metrics["detection_rate_injected_by_snr"] = {
        str(k): round(float(v), 3) for k, v in inj.groupby(pd.cut(inj["snr_target"], snr_bins), observed=False)["detected"].mean().items()
    }

    # Model metadata file
    model_file_map = {
        "lightgbm": "model_lightgbm.txt",
        "xgboost": "model_xgboost.json",
        "random_forest": "model_random_forest.joblib",
    }
    meta_data = {
        "features": FEATURES,
        "best_model_name": best_name,
        "model_file": model_file_map[best_name],
        "threshold": round(final_thr, 6),
        "min_visits": MIN_VISITS,
        "target_false_alarm_rate": TARGET_FALSE_ALARM,
        "mover_threshold_arcsec_yr": M.MOVER_THRESHOLD_ARCSEC_YR,
        "trained_rows": int(is_inj.sum()),
        "training_data": "synthetic point sources injected into real SPHEREx visit stacks",
        "best_hyperparameters": best_params.get(best_name),
    }
    (OUT / "model_meta.json").write_text(json.dumps(meta_data, indent=2))
    (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2))

    # PLOTS
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # 1. Confusion Matrix Comparison (XGBoost, Random Forest, LightGBM)
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.0))
    display_names = {
        "xgboost": "XGBoost (Optuna)",
        "random_forest": "Random Forest (Optuna)",
        "lightgbm": "LightGBM (Optuna)",
    }
    for ax, name in zip(axes, ["xgboost", "random_forest", "lightgbm"]):
        cm_dict = metrics["models"][name]["confusion_matrix_injected"]
        cm = np.array([[cm_dict["tn"], cm_dict["fp"]],
                       [cm_dict["fn"], cm_dict["tp"]]])
        im = ax.imshow(cm, cmap="Blues", interpolation="nearest")
        ax.set_xticks([0, 1], ["Static (0)", "Mover (1)"], fontsize=8)
        ax.set_yticks([0, 1], ["Static (0)", "Mover (1)"], fontsize=8)
        ax.set_xlabel("Predicted Label", fontsize=9)
        ax.set_ylabel("True Label", fontsize=9)
        prec = metrics["models"][name]["precision_injected"]
        rec = metrics["models"][name]["recall_injected"]
        ap = metrics["models"][name]["average_precision_injected"]
        title_tag = " ★ WINNER" if name == best_name else ""
        ax.set_title(f"{display_names[name]}{title_tag}\nAP: {ap:.3f} | Prec: {prec:.1%} | Rec: {rec:.1%}", fontsize=9)
        thresh = cm.max() / 2.0
        labels = [["TN", "FP"], ["FN", "TP"]]
        for i in range(2):
            for j in range(2):
                pct = cm[i, j] / cm[i].sum()
                ax.text(j, i, f"{labels[i][j]}\n{cm[i, j]:,}\n({pct:.1%})",
                        ha="center", va="center", color="white" if cm[i, j] > thresh else "black", fontsize=8)
    fig.suptitle("Confusion Matrices on Injected Sources (Leave-Fields-Out CV, 1% Real False Alarm Rate)", fontsize=11, y=1.03)
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=130, bbox_inches="tight")
    plt.close(fig)

    # 2. ROC Curves (Movers found vs. Real False Alarms)
    fig, ax = plt.subplots(figsize=(6.0, 4.5))
    plot_styles = {
        "xgboost": ("#2563eb", "-", 2.0, "XGBoost (Optuna)"),
        "random_forest": ("#059669", "--", 1.8, "Random Forest (Optuna)"),
        "lightgbm": ("#7c3aed", "-.", 1.8, "LightGBM (Optuna)"),
        "logistic": ("#d97706", ":", 1.5, "Logistic Regression"),
        "rule": ("#dc2626", ":", 1.5, "Rule (Significance cut)"),
    }
    for name in ["xgboost", "random_forest", "lightgbm", "logistic", "rule"]:
        s = oof[name]
        cuts = np.unique(np.concatenate([s[real_static], [s.max() + 1]]))
        fa = np.array([(s[real_static] >= c).mean() for c in cuts])
        rec = np.array([(s[inj_mover] >= c).mean() for c in cuts])
        color, ls, lw, label = plot_styles[name]
        ax.plot(fa * 100, rec * 100, label=label, color=color, linestyle=ls, linewidth=lw)
    ax.axvline(TARGET_FALSE_ALARM * 100, ls=":", c="gray", label="Target 1% FA Operating Point")
    ax.set_xscale("symlog", linthresh=0.5)
    ax.set_xlim(0, 100); ax.set_ylim(0, 100)
    ax.set_xlabel("Real non-moving Gaia stars flagged (%)"); ax.set_ylabel("Injected movers found (%)")
    ax.set_title("Movers Found vs. False Alarms (Leave-Fields-Out)", fontsize=10)
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout(); fig.savefig(OUT / "roc.png", dpi=130); plt.close(fig)

    # 3. Model Comparison Bar Chart
    fig, ax = plt.subplots(figsize=(8.0, 4.0))
    models_to_compare = ["xgboost", "random_forest", "lightgbm", "logistic", "rule"]
    x_idx = np.arange(len(models_to_compare))
    bar_width = 0.22
    auc_vals = [metrics["models"][m]["roc_auc_injected"] for m in models_to_compare]
    ap_vals = [metrics["models"][m]["average_precision_injected"] for m in models_to_compare]
    rec_vals = [metrics["models"][m]["recall_injected"] for m in models_to_compare]

    ax.bar(x_idx - bar_width, auc_vals, width=bar_width, label="ROC-AUC", color="#3b82f6")
    ax.bar(x_idx, ap_vals, width=bar_width, label="Average Precision (PR-AUC)", color="#10b981")
    ax.bar(x_idx + bar_width, rec_vals, width=bar_width, label="Recall @ 1% FA", color="#f59e0b")
    ax.set_xticks(x_idx)
    ax.set_xticklabels(["XGBoost\n(Optuna)", "Random Forest\n(Optuna)", "LightGBM\n(Optuna)", "Logistic\nReg.", "Baseline\nRule"], fontsize=8)
    ax.set_ylabel("Score", fontsize=9)
    ax.set_ylim(0.0, 1.05)
    ax.set_title("Model Performance Comparison (Leave-Fields-Out CV)", fontsize=10)
    ax.legend(loc="lower right", fontsize=8)
    for i in x_idx:
        ax.text(i - bar_width, auc_vals[i] + 0.02, f"{auc_vals[i]:.2f}", ha="center", fontsize=7)
        ax.text(i, ap_vals[i] + 0.02, f"{ap_vals[i]:.2f}", ha="center", fontsize=7)
        ax.text(i + bar_width, rec_vals[i] + 0.02, f"{rec_vals[i]:.2f}", ha="center", fontsize=7)
    fig.tight_layout()
    fig.savefig(OUT / "model_comparison.png", dpi=130)
    plt.close(fig)

    # 4. Completeness heatmap
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8), sharey=True)
    for ax, col, title in zip(axes, ("found_ml", "found_rule"),
                             (f"{display_names[best_name]} (1% false alarms)", "Rule: >=1\"/yr + significance cut (1% false alarms)")):
        tab = comp[col].to_numpy(dtype=float)
        im = ax.imshow(tab, vmin=0, vmax=1, cmap="viridis", origin="lower", aspect="auto")
        ax.set_xticks(range(len(snr_bins) - 1), [f"{a:g}-{b:g}" for a, b in zip(snr_bins[:-1], [5, 10, 20, 50, 300, 3000])], fontsize=7)
        ax.set_yticks(range(len(pm_bins) - 1), [f"{a:g}-{b:g}" for a, b in zip(pm_bins[:-1], [1, 2, 4, 8, 15][1:])], fontsize=7)
        for (i, j), v in np.ndenumerate(tab):
            if np.isfinite(v):
                ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=7, color="w" if v < 0.6 else "k")
        ax.set_xlabel("Injected brightness (S/N per visit)"); ax.set_title(title, fontsize=9)
    axes[0].set_ylabel("Proper motion (\"/yr)")
    fig.colorbar(im, ax=axes, fraction=0.025, label="Fraction of injected movers found")
    fig.savefig(OUT / "completeness.png", dpi=130, bbox_inches="tight"); plt.close(fig)

    # 5. Feature Importance of best model
    fig, ax = plt.subplots(figsize=(6.0, 4.5))
    if best_name == "xgboost":
        importances = pd.Series(final_models["xgboost"].feature_importances_, index=FEATURES).sort_values(ascending=False)
    elif best_name == "lightgbm":
        importances = pd.Series(final_models["lightgbm"].booster_.feature_importance("gain"), index=FEATURES).sort_values(ascending=False)
    else:
        importances = pd.Series(final_models["random_forest"].named_steps["randomforestclassifier"].feature_importances_, index=FEATURES).sort_values(ascending=False)
    importances.head(15)[::-1].plot.barh(ax=ax, color="#2563eb")
    ax.set_xlabel("Feature Importance"); ax.set_title(f"Feature Importance ({display_names[best_name]})", fontsize=10)
    fig.tight_layout(); fig.savefig(OUT / "feature_importance.png", dpi=130); plt.close(fig)

    print("\n=== Model Evaluation Summary ===")
    for name in model_names:
        m = metrics["models"][name]
        print(f"{name:14} AP={m['average_precision_injected']:.4f} AUC={m['roc_auc_injected']:.4f} "
              f"Prec={m['precision_injected']:.4f} Rec={m['recall_injected']:.4f} | "
              f"Real FA: {m['n_false_alarms_real']}/{metrics['n_real_static_eval']} ({m['false_alarm_rate_real_static_stars']})")

    for b in metrics.get("benchmarks", []):
        print(f"Benchmark: {b['field']:16} Catalog: {b['catalog_pm_arcsec_yr']:5.2f}\"/yr Measured: {b['measured_pm_arcsec_yr']} p={b['p_mover']:.3f} Flagged={b['ml_flag']}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
