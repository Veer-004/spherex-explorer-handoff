"""
Build a labelled training set for a SPHEREx moving-object classifier by injecting synthetic stars
into REAL SPHEREx visit stacks.

For every field in dataset/spherex/:
  realization 0  - the untouched stacks. Every detected source is measured; real sources get a label
                   from Gaia DR3 (proper motion >= 1"/yr -> mover, < 0.5"/yr -> not a mover).
                   The field's benchmark mover (Barnard's Star, Epsilon Indi B, WISE 0855) is tagged
                   and kept out of training so it can be used as an independent real-world check.
  realizations 1..R - the same stacks plus ~25 injected point sources each, drawn with the stack's own
                   empirical PSF. Half are movers (1-15"/yr), half are near-static (0-0.5"/yr). Brightness,
                   spectral shape, variability and placement are drawn independently of the label, so a
                   model cannot learn "injected" or "red" as a shortcut for "mover". The full detection
                   and measurement pipeline runs on the injected stacks exactly as on real data.

Outputs (ml/movers/output/):
  training_set.csv  one row per measured source (features + label + provenance)
  injections.csv    one row per injected source (truth + whether it was detected) -> completeness
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import movers as M  # noqa: E402

OUT = Path(__file__).resolve().parent / "output"
# Measured on real non-moving stars in these stacks: bright stars keep ~0.05-0.07 px rms residual between
# visits and ~5-6% flux scatter, about twice what perfectly placed injections show.
JITTER_PX = 0.045
FLUX_SCATTER = 0.05

SEDS = {   # relative flux in D1..D6 (shape only; label-independent)
    "flat": lambda rng: np.ones(6),
    "blue": lambda rng: 10 ** (-0.4 * rng.uniform(0.2, 0.7) * np.arange(6)),
    "red": lambda rng: 10 ** (0.4 * rng.uniform(0.2, 0.7) * np.arange(6)),
    "cold_brown_dwarf": lambda rng: np.array([0.02, 0.04, 0.08, 0.2, 1.0, 1.3]) * rng.uniform(0.8, 1.2, 6),
    "lumpy": lambda rng: np.exp(rng.normal(0, 0.4, 6)),
}


def noise_flux_ujy(f: M.Field, det: int) -> float:
    """1-sigma flux noise of a PSF-sized aperture in one visit stack of this detector (median over visits)."""
    sig = np.median([f.sigma[k] for k in f.images if k[1] == det])
    s_psf = M.psf_sigma(next(p for k, p in f.psf.items() if k[1] == det))
    return float(sig * math.sqrt(4 * math.pi) * s_psf * M.PIX_UJY)


def real_seds(real_rows: list, dets: list) -> list:
    """Measured D1..D6 flux shapes of real sources in this field (used so injected colours look real)."""
    out = []
    for r in real_rows:
        fl = r.get("flux_ujy_by_det", {})
        v = np.array([fl.get(d, np.nan) for d in range(1, 7)], dtype=float)
        ok = np.array([d in dets for d in range(1, 7)])
        if r.get("snr_deep", 0) >= 15 and np.all(np.isfinite(v[ok])) and np.all(v[ok] > 0):
            v[~ok] = 0.0
            out.append(v)
    return out


def draw_injections(f: M.Field, rng: np.random.Generator, n: int, existing: np.ndarray, realization: int,
                    seds_real: list | None = None):
    lo, hi = M.EDGE + 1.5, f.npix - M.EDGE - 2.5          # same footprint as real detections
    dets = f.detectors
    noise = {d: noise_flux_ujy(f, d) for d in dets}
    out = []
    for i in range(n):
        for _ in range(50):                                   # placement: mostly avoid existing sources
            x, y = rng.uniform(lo, hi, 2)
            if rng.random() < 0.25 or not len(existing) or np.min(np.hypot(existing[:, 0] - x, existing[:, 1] - y)) > 3.0:
                break
        mover = rng.random() < 0.5
        pm = float(np.exp(rng.uniform(math.log(1.0), math.log(15.0)))) if mover else float(rng.uniform(0.0, 0.5))
        ang = rng.uniform(0, 2 * math.pi)
        if seds_real and rng.random() < 0.75:           # copy a real star's colours (plus small scatter)
            sed_name = "real_copy"
            sed = seds_real[rng.integers(len(seds_real))] * np.exp(rng.normal(0, 0.1, 6))
        else:                                            # templates add rarer shapes (e.g. cold brown dwarfs)
            sed_name = rng.choice(list(SEDS))
            sed = SEDS[sed_name](rng)
        sed = sed / sed[[d - 1 for d in dets]].max()           # brightest available detector = 1
        # S/N per visit stack, log-uniform 3-3000: some fall below the detection limit (completeness),
        # and the bright end covers very bright real objects (Barnard's Star, galaxy nuclei)
        snr = float(np.exp(rng.uniform(math.log(3.0), math.log(3000.0))))
        ref = max(dets, key=lambda d: sed[d - 1])
        base = snr * noise[ref]
        flux = {d: float(base * sed[d - 1]) for d in dets}
        var_amp = float(rng.uniform(0.1, 0.6)) if rng.random() < 0.3 else 0.0
        out.append(M.Injection(
            inj_id=f"{f.fid}:r{realization}:{i}", x0=float(x), y0=float(y),
            pm_x=pm * math.cos(ang) / M.PIX_ARCSEC, pm_y=pm * math.sin(ang) / M.PIX_ARCSEC,
            flux_ujy=flux, var_amp=var_amp, var_phase=float(rng.uniform(0, 2 * math.pi)),
            pm_arcsec_yr=pm, sed=str(sed_name),
            jitter={v: (float(rng.normal(0, JITTER_PX)), float(rng.normal(0, JITTER_PX))) for v in f.visits},
            flux_scatter={k: float(rng.normal(0, FLUX_SCATTER)) for k in f.images}))
        out[-1].snr_target = snr                               # type: ignore[attr-defined]
    return out


META = ["field", "realization", "source", "label", "true_pm_arcsec_yr", "snr_target", "sed", "var_amp",
        "gaia_pm_arcsec_yr", "gaia_g", "benchmark", "x", "y", "inj_id"]


def process_field(fid: str, realizations: int, n_inj: int, seed: int):
    t = time.time()
    f = M.load_field(fid)
    if len(f.visits) < 2:
        print(f"{fid}: fewer than 2 visits, skipped", flush=True)
        return [], []
    rng = np.random.default_rng(seed)
    gaia = M.gaia_sources_px(f)
    bench = M.benchmark_position_px(f)
    rows, truth = [], []

    # realization 0: real sources
    vs = M.visit_snr_images(f)
    dets = M.detect(f, vs)
    real = M.measure(f, vs, dets)
    existing = np.array([[d[0], d[1]] for d in dets]) if dets else np.zeros((0, 2))
    for r in real:
        g_pm = g_g = np.nan
        if len(gaia):
            dd = np.hypot(gaia[:, 0] - r["x"], gaia[:, 1] - r["y"])
            j = int(np.argmin(dd))
            if dd[j] <= 1.5:
                g_pm, g_g = gaia[j, 2], gaia[j, 3]
        is_bench = bool(bench and math.hypot(bench[0] - r["x"], bench[1] - r["y"]) <= 2.0)
        if is_bench:
            label = 1
        elif np.isfinite(g_pm):
            label = 1 if g_pm >= M.MOVER_THRESHOLD_ARCSEC_YR else (0 if g_pm < 0.5 else -1)
        else:
            label = -1                                            # unknown: kept for scoring, not training
        rows.append({**r, "field": fid, "realization": 0, "source": "real", "label": label,
                     "true_pm_arcsec_yr": bench[2] if is_bench else g_pm, "snr_target": np.nan, "sed": "",
                     "var_amp": np.nan, "gaia_pm_arcsec_yr": g_pm, "gaia_g": g_g, "benchmark": int(is_bench),
                     "inj_id": ""})

    # injected realizations
    seds = real_seds(real, f.detectors)
    for k in range(1, realizations + 1):
        inj = draw_injections(f, rng, n_inj, existing, k, seds)
        g = M.inject(f, inj)
        vs_k = M.visit_snr_images(g)
        dets_k = M.detect(g, vs_k)
        meas = M.measure(g, vs_k, dets_k)
        pos = np.array([[m["x"], m["y"]] for m in meas]) if meas else np.zeros((0, 2))
        used = set()
        for s in inj:
            hit = -1
            if len(pos):
                dd = np.hypot(pos[:, 0] - s.x0, pos[:, 1] - s.y0)
                for j in np.argsort(dd):
                    if dd[j] > 2.0:
                        break
                    if j not in used:
                        hit = int(j)
                        break
            # a detection that was already a real source (before injection) is ambiguous: drop it
            if hit >= 0 and len(existing) and np.min(np.hypot(existing[:, 0] - pos[hit, 0], existing[:, 1] - pos[hit, 1])) < 1.0 \
                    and getattr(s, "snr_target", 0) < 20:
                hit = -2
            label = int(s.pm_arcsec_yr >= M.MOVER_THRESHOLD_ARCSEC_YR)
            truth.append({"inj_id": s.inj_id, "field": fid, "realization": k, "label": label,
                          "true_pm_arcsec_yr": s.pm_arcsec_yr, "snr_target": s.snr_target, "sed": s.sed,
                          "var_amp": s.var_amp, "x0": s.x0, "y0": s.y0, "detected": int(hit >= 0)})
            if hit >= 0:
                used.add(hit)
                rows.append({**meas[hit], "field": fid, "realization": k, "source": "injected", "label": label,
                             "true_pm_arcsec_yr": s.pm_arcsec_yr, "snr_target": s.snr_target, "sed": s.sed,
                             "var_amp": s.var_amp, "gaia_pm_arcsec_yr": np.nan, "gaia_g": np.nan, "benchmark": 0,
                             "inj_id": s.inj_id})
    n_inj_det = sum(t_["detected"] for t_ in truth)
    print(f"{fid:26} visits={len(f.visits)} real={len(real):3} (labelled {sum(r['label'] >= 0 for r in rows if r['source'] == 'real'):3}) "
          f"injected={len(truth)} detected={n_inj_det} ({100 * n_inj_det / max(1, len(truth)):.0f}%)  {time.time() - t:.0f}s", flush=True)
    return rows, truth


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--realizations", type=int, default=12)
    ap.add_argument("--n-inj", type=int, default=25, help="injected sources per realization")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--fields", default="all")
    args = ap.parse_args()

    fields = sorted(p.name for p in M.DATASET.iterdir() if (p / "index.json").exists())
    if args.fields != "all":
        fields = [f for f in fields if f in args.fields.split(",")]
    OUT.mkdir(parents=True, exist_ok=True)
    all_rows, all_truth = [], []
    for i, fid in enumerate(fields):
        r, t = process_field(fid, args.realizations, args.n_inj, args.seed + 1000 * i)
        all_rows += r
        all_truth += t

    cols = META + M.FEATURES
    with open(OUT / "training_set.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in all_rows:
            w.writerow({c: r.get(c, "") for c in cols})
    with open(OUT / "injections.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(all_truth[0].keys()))
        w.writeheader()
        w.writerows(all_truth)
    lab = [r for r in all_rows if r["label"] >= 0 and not r["benchmark"]]
    print(f"\nrows: {len(all_rows)}  labelled for training: {len(lab)}  "
          f"(movers {sum(r['label'] == 1 for r in lab)}, non-movers {sum(r['label'] == 0 for r in lab)})  "
          f"benchmarks: {sum(r['benchmark'] for r in all_rows)}")
    print(f"wrote {OUT / 'training_set.csv'} and {OUT / 'injections.csv'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
