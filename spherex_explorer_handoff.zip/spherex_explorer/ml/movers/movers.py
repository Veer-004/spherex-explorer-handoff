"""
Source detection, per-visit measurement, feature extraction and synthetic-source injection
for SPHEREx visit stacks produced by dataset/build_dataset.py.

Everything operates on the real stacks: dataset/spherex/<field>/stacks/<visit>_D<n>.fits, which
share one TAN grid per field (6.15"/px, north up). Injected sources use an empirical PSF measured
from bright stars in the same stack, so they inherit the real image's PSF, noise and artifacts.
"""

from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from astropy.io import fits
from scipy.ndimage import gaussian_filter, maximum_filter, shift as nd_shift

REPO = Path(__file__).resolve().parents[2]
DATASET = REPO / "dataset" / "spherex"
PIX_ARCSEC = 6.15
PIX_UJY = (PIX_ARCSEC / 206264.806) ** 2 * 1e12   # 1 MJy/sr over one pixel, in micro-Jansky
MOVER_THRESHOLD_ARCSEC_YR = 1.0                   # class boundary used for labels
EDGE = 7                                          # ignore detections this close to the stack edge
DETECT_SNR = 5.0
PSF_HALF = 7                                      # PSF stamp is (2*PSF_HALF+1)^2
SEARCH_R = 4.5                                    # per-visit search radius around the deep position (px)


# --------------------------------------------------------------------------- data access

@dataclass
class Field:
    fid: str
    index: dict
    visits: List[str]
    mjd: Dict[str, float]                          # visit -> mean MJD of its stacks
    images: Dict[Tuple[str, int], np.ndarray]      # (visit, detector) -> image (MJy/sr)
    npix: int
    psf: Dict[Tuple[str, int], np.ndarray] = field(default_factory=dict)
    sigma: Dict[Tuple[str, int], float] = field(default_factory=dict)
    nexp: Dict[str, float] = field(default_factory=dict)          # visit -> exposures per stack

    def copy_images(self) -> "Field":
        f = Field(self.fid, self.index, list(self.visits), dict(self.mjd),
                  {k: v.copy() for k, v in self.images.items()}, self.npix, self.psf, self.sigma, self.nexp)
        return f

    @property
    def detectors(self) -> List[int]:
        return sorted({d for (_, d) in self.images})

    @property
    def t0(self) -> float:
        return float(np.mean([self.mjd[v] for v in self.visits]))


def fill_nans(img: np.ndarray) -> np.ndarray:
    """Saturated cores are NaN in some stacks: fill them with the neighbourhood maximum so stars stay stars."""
    out = img.copy()
    for _ in range(4):
        bad = ~np.isfinite(out)
        if not bad.any():
            break
        grown = maximum_filter(np.where(bad, -np.inf, out), size=3)
        out[bad] = grown[bad]
    out[~np.isfinite(out)] = 0.0
    return out


def robust_sigma(a: np.ndarray) -> float:
    """Noise of an image measured on background pixels only: sources (and their wings) are masked
    iteratively, so crowded fields do not inflate the estimate."""
    a = np.asarray(a, dtype=np.float64)
    fin = np.isfinite(a)
    if not fin.any():
        return 1.0
    mask = ~fin
    s = 1.0
    for _ in range(4):
        vals = a[~mask]
        if vals.size < 50:
            break
        med = np.median(vals)
        s = float(1.4826 * np.median(np.abs(vals - med))) or 1e-6
        if a.ndim == 2:
            mask = ~fin | (maximum_filter(np.where(fin, a - med, 0.0), size=5) > 3.0 * s)
        else:
            mask = ~fin | (np.abs(a - med) > 3.0 * s)
    return s


def load_field(fid: str) -> Field:
    d = DATASET / fid
    index = json.loads((d / "index.json").read_text())
    images, mjds, nexp = {}, {}, {}
    for s in index["stacks"]:
        with fits.open(d / s["file"]) as h:
            images[(s["visit_id"], int(s["detector"]))] = fill_nans(h["IMAGE"].data.astype(np.float64))
        mjds.setdefault(s["visit_id"], []).append(float(s["mjd_avg"]))
        nexp.setdefault(s["visit_id"], []).append(float(s["n_exposures"]))
    visits = sorted(mjds, key=lambda v: np.mean(mjds[v]))
    f = Field(fid, index, visits, {v: float(np.mean(m)) for v, m in mjds.items()}, images,
              int(index["stack_grid"]["npix"]), nexp={v: float(np.mean(n)) for v, n in nexp.items()})
    for k, img in f.images.items():
        f.sigma[k] = robust_sigma(img)
    for det in f.detectors:
        keys = [k for k in f.images if k[1] == det]
        pooled = empirical_psf([f.images[k] for k in keys], [f.sigma[k] for k in keys])
        for k in keys:
            # the PSF changes a little from visit to visit (different exposures and orientations); keep that
            # variation where a visit has enough stars, so injected stars leave the same subtraction residuals
            own = empirical_psf([f.images[k]], [f.sigma[k]], min_stars=6)
            p = pooled if own is None else 0.5 * own + 0.5 * pooled
            f.psf[k] = p / p.sum()
    return f


# --------------------------------------------------------------------------- PSF

def gaussian_psf(sig_px: float) -> np.ndarray:
    yy, xx = np.mgrid[-PSF_HALF:PSF_HALF + 1, -PSF_HALF:PSF_HALF + 1]
    p = np.exp(-(xx ** 2 + yy ** 2) / (2 * sig_px ** 2))
    return p / p.sum()


def empirical_psf(imgs: List[np.ndarray], sigmas: List[float], n_max: int = 60,
                  min_stars: Optional[int] = None) -> Optional[np.ndarray]:
    """Median of normalised, recentred stamps of bright, isolated, unsaturated stars (pooled over images)."""
    h = PSF_HALF
    syy, sxx = np.mgrid[-h:h + 1, -h:h + 1]
    stamps = []
    for img, sigma in zip(imgs, sigmas):
        peaks = (img == maximum_filter(img, size=7)) & (img > 15 * sigma)
        ys, xs = np.nonzero(peaks)
        if not len(ys):
            continue
        order = np.argsort(-img[ys, xs])
        top = img[ys[order[0]], xs[order[0]]]
        for k in order:
            y, x = ys[k], xs[k]
            if not (h + 1 <= y < img.shape[0] - h - 1 and h + 1 <= x < img.shape[1] - h - 1):
                continue
            if img[y, x] > 0.3 * top:                      # skip the brightest (saturation, bloom)
                continue
            st = img[y - h:y + h + 1, x - h:x + h + 1]
            others = (st == maximum_filter(st, size=3)) & (st > 0.2 * img[y, x]) & (np.hypot(sxx, syy) > 3.5)
            if others.any():                               # a separate star inside the stamp
                continue
            w = np.clip(st[h - 2:h + 3, h - 2:h + 3], 0, None)
            yy, xx = np.mgrid[-2:3, -2:3]
            cy, cx = (w * yy).sum() / w.sum(), (w * xx).sum() / w.sum()
            st = nd_shift(st, (-cy, -cx), order=1, mode="nearest")
            st = st - np.median(np.concatenate([st[0], st[-1], st[:, 0], st[:, -1]]))
            if st.sum() <= 0:
                continue
            stamps.append(st / st.sum())
    if min_stars is not None and len(stamps) < min_stars:
        return None
    if len(stamps) < 5:
        return gaussian_psf(1.6)
    stamps = stamps[:n_max]
    psf = np.clip(np.median(stamps, axis=0), 0, None)
    return psf / psf.sum()


def psf_sigma(psf: np.ndarray) -> float:
    yy, xx = np.mgrid[-PSF_HALF:PSF_HALF + 1, -PSF_HALF:PSF_HALF + 1]
    return float(np.sqrt((psf * (xx ** 2 + yy ** 2)).sum() / psf.sum() / 2))


# --------------------------------------------------------------------------- injection

@dataclass
class Injection:
    inj_id: str
    x0: float                    # stack pixel at field t0
    y0: float
    pm_x: float                  # px / yr (x increases to the west in these stacks)
    pm_y: float                  # px / yr (y increases to the north)
    flux_ujy: Dict[int, float]   # per detector, at the mean epoch
    var_amp: float               # fractional brightness change amplitude between visits
    var_phase: float
    pm_arcsec_yr: float = 0.0
    sed: str = ""
    # per-visit astrometric jitter (px) and per-(visit, detector) flux scatter, matched to what real
    # static stars show in these stacks, so injected sources are not unrealistically clean
    jitter: Dict[str, Tuple[float, float]] = field(default_factory=dict)
    flux_scatter: Dict[Tuple[str, int], float] = field(default_factory=dict)

    def position(self, mjd: float, t0: float, visit: Optional[str] = None) -> Tuple[float, float]:
        dt = (mjd - t0) / 365.25
        jx, jy = self.jitter.get(visit, (0.0, 0.0)) if visit else (0.0, 0.0)
        return self.x0 + self.pm_x * dt + jx, self.y0 + self.pm_y * dt + jy


def add_psf(img: np.ndarray, psf: np.ndarray, x: float, y: float, total: float) -> None:
    """Add `total` (MJy/sr summed over pixels) at sub-pixel (x, y) using the stack's own PSF."""
    ix, iy = int(round(x)), int(round(y))
    stamp = nd_shift(psf, (y - iy, x - ix), order=3, mode="constant", cval=0.0) * total
    h = PSF_HALF
    y0, y1, x0, x1 = iy - h, iy + h + 1, ix - h, ix + h + 1
    sy0, sx0 = max(0, -y0), max(0, -x0)
    sy1 = stamp.shape[0] - max(0, y1 - img.shape[0])
    sx1 = stamp.shape[1] - max(0, x1 - img.shape[1])
    if sy1 <= sy0 or sx1 <= sx0:
        return
    img[max(0, y0):min(img.shape[0], y1), max(0, x0):min(img.shape[1], x1)] += stamp[sy0:sy1, sx0:sx1]


def inject(f: Field, injections: List[Injection]) -> Field:
    g = f.copy_images()
    t0 = f.t0
    for k, img in g.images.items():
        v, det = k
        for s in injections:
            x, y = s.position(f.mjd[v], t0, v)
            vis_idx = f.visits.index(v)
            scale = (1.0 + s.var_amp * math.sin(s.var_phase + 2.1 * vis_idx)) * (1.0 + s.flux_scatter.get(k, 0.0))
            total = s.flux_ujy.get(det, 0.0) * max(scale, 0.05) / PIX_UJY
            if total > 0:
                add_psf(img, f.psf[k], x, y, total)
    return g


# --------------------------------------------------------------------------- detection & measurement

def visit_snr_images(f: Field) -> Dict[str, np.ndarray]:
    """Per visit: detectors combined in signal-to-noise units, then PSF-matched smoothing."""
    out = {}
    for v in f.visits:
        dets = [d for d in f.detectors if (v, d) in f.images]
        comb = sum(f.images[(v, d)] / f.sigma[(v, d)] for d in dets) / math.sqrt(len(dets))
        sm = gaussian_filter(comb, 1.5)
        out[v] = sm / robust_sigma(sm)
    return out


def detect(f: Field, vsnr: Dict[str, np.ndarray]) -> List[Tuple[float, float, float]]:
    deep = sum(vsnr.values()) / math.sqrt(len(vsnr))
    deep = deep / robust_sigma(deep)
    pk = (deep == maximum_filter(deep, size=5)) & (deep >= DETECT_SNR)
    pk[:EDGE] = pk[-EDGE:] = False
    pk[:, :EDGE] = pk[:, -EDGE:] = False
    ys, xs = np.nonzero(pk)
    dets = []
    for y, x in zip(ys, xs):
        w = np.clip(deep[y - 1:y + 2, x - 1:x + 2], 0, None)
        yy, xx = np.mgrid[-1:2, -1:2]
        dets.append((x + (w * xx).sum() / w.sum(), y + (w * yy).sum() / w.sum(), float(deep[y, x])))
    return dets


def _centroid(img: np.ndarray, x: float, y: float, r: int = 2, iters: int = 3) -> Tuple[float, float]:
    for _ in range(iters):
        ix, iy = int(round(x)), int(round(y))
        if not (r <= ix < img.shape[1] - r and r <= iy < img.shape[0] - r):
            break
        st = img[iy - r:iy + r + 1, ix - r:ix + r + 1]
        yy, xx = np.mgrid[-r:r + 1, -r:r + 1]
        # weight centred on the current estimate (not the pixel centre) so the result is not pulled to the grid
        w = np.clip(st - np.median(st), 0, None) * np.exp(-((xx - (x - ix)) ** 2 + (yy - (y - iy)) ** 2) / (2 * 1.5 ** 2))
        if w.sum() <= 0:
            break
        x, y = ix + (w * xx).sum() / w.sum(), iy + (w * yy).sum() / w.sum()
    return x, y


def _aperture(img: np.ndarray, x: float, y: float, r: float = 2.0) -> float:
    ix, iy = int(round(x)), int(round(y))
    R = 6
    if not (R <= ix < img.shape[1] - R and R <= iy < img.shape[0] - R):
        return float("nan")
    st = img[iy - R:iy + R + 1, ix - R:ix + R + 1]
    yy, xx = np.mgrid[-R:R + 1, -R:R + 1]
    rr = np.hypot(xx - (x - ix), yy - (y - iy))
    bkg = np.median(st[(rr >= 4) & (rr <= 6)])
    return float((st[rr <= r] - bkg).sum())


FEATURES = [
    "snr_deep", "n_vis", "n_vis_det", "baseline_yr",
    "pm_fit_arcsec_yr", "pm_err_arcsec_yr", "pm_sig", "chi2_red", "rms_resid_px",
    "shift_first_last_px", "max_visit_shift_px",
    "snr_vis_min", "snr_vis_med",
    "deep_size_ratio", "deep_elong",
    "dipole_pos", "dipole_neg", "dipole_sep_px",
    "var_mad_mag", "var_range_mag",
    "c12", "c23", "c34", "c45", "c56", "frac_blue",
    "nn_dist_px", "nn_snr_ratio", "edge_dist_px",
]


def measure(f: Field, vsnr: Dict[str, np.ndarray], dets: List[Tuple[float, float, float]]) -> List[dict]:
    """Per-visit positions, motion fit and the feature vector for every detection."""
    t0 = f.t0
    tyr = {v: (f.mjd[v] - t0) / 365.25 for v in f.visits}
    first, last = f.visits[0], f.visits[-1]
    diff = vsnr[last] - vsnr[first]
    diff = diff / robust_sigma(diff)
    deep = sum(vsnr.values()) / math.sqrt(len(vsnr))
    psf_sig = float(np.median([psf_sigma(p) for p in f.psf.values()]))
    pos = np.array([[d[0], d[1]] for d in dets]) if dets else np.zeros((0, 2))
    rows = []
    for i, (xd, yd, snr_d) in enumerate(dets):
        # crowding
        if len(pos) > 1:
            dd = np.hypot(pos[:, 0] - xd, pos[:, 1] - yd)
            dd[i] = np.inf
            j = int(np.argmin(dd))
            nn_dist, nn_ratio = float(dd[j]), float(dets[j][2] / snr_d)
        else:
            nn_dist, nn_ratio = 99.0, 0.0
        # per-visit positions
        vx, vy, vs, vt, vn = [], [], [], [], []
        for v in f.visits:
            img = vsnr[v]
            ix, iy = int(round(xd)), int(round(yd))
            r = int(math.ceil(SEARCH_R))
            win = img[iy - r:iy + r + 1, ix - r:ix + r + 1]
            yy, xx = np.mgrid[-r:r + 1, -r:r + 1]
            win = np.where(np.hypot(xx, yy) <= SEARCH_R, win, -np.inf)
            k = np.unravel_index(np.argmax(win), win.shape)
            peak = float(win[k])
            if peak < 3.0:
                continue
            cx, cy = _centroid(img, ix + xx[k], iy + yy[k], r=3, iters=6)
            vx.append(cx); vy.append(cy); vs.append(peak); vt.append(tyr[v]); vn.append(f.nexp.get(v, 1.0))
        vx, vy, vs, vt, vn = map(np.array, (vx, vy, vs, vt, vn))
        row = {"x": xd, "y": yd, "snr_deep": snr_d, "n_vis": len(f.visits), "n_vis_det": len(vt),
               "vis_track": [[float(t_), float(x_), float(y_)] for t_, x_, y_ in zip(vt, vx, vy)],
               "nn_dist_px": nn_dist, "nn_snr_ratio": nn_ratio,
               "edge_dist_px": float(min(xd, yd, f.npix - 1 - xd, f.npix - 1 - yd))}
        if len(vt) >= 2 and np.ptp(vt) > 0.1:
            # position error per visit (px): photon noise + a systematic part that averages down with
            # the number of exposures in the stack (pointing/resampling scatter of single exposures)
            sp = np.sqrt((0.8 * psf_sig / vs) ** 2 + (0.35 / np.sqrt(np.maximum(vn, 1.0))) ** 2)
            w = 1.0 / sp ** 2
            tm = (w * vt).sum() / w.sum()
            tt = vt - tm
            sxx = (w * tt ** 2).sum()
            px = (w * tt * vx).sum() / sxx
            py = (w * tt * vy).sum() / sxx
            mx, my = (w * vx).sum() / w.sum(), (w * vy).sum() / w.sum()
            rx, ry = vx - (mx + px * tt), vy - (my + py * tt)
            chi2 = float(((rx ** 2 + ry ** 2) * w).sum())
            dof = max(1, 2 * len(vt) - 4)
            pm_err = math.sqrt(1.0 / sxx) * max(1.0, math.sqrt(chi2 / dof))
            pm = math.hypot(px, py)
            shifts = np.hypot(vx[:, None] - vx[None, :], vy[:, None] - vy[None, :])
            row.update({
                "baseline_yr": float(np.ptp(vt)), "pm_fit_arcsec_yr": pm * PIX_ARCSEC,
                "pm_err_arcsec_yr": pm_err * PIX_ARCSEC, "pm_sig": pm / pm_err if pm_err > 0 else 0.0,
                "chi2_red": chi2 / dof, "rms_resid_px": float(np.sqrt(np.mean(rx ** 2 + ry ** 2))),
                "shift_first_last_px": float(math.hypot(vx[-1] - vx[0], vy[-1] - vy[0])),
                "max_visit_shift_px": float(shifts.max()),
                "snr_vis_min": float(vs.min()), "snr_vis_med": float(np.median(vs)),
                "pm_x_px_yr": px, "pm_y_px_yr": py,
            })
        # deep-image shape: motion smears a source along its track
        ix, iy = int(round(xd)), int(round(yd))
        st = deep[iy - 3:iy + 4, ix - 3:ix + 4]
        if st.shape == (7, 7):
            yy, xx = np.mgrid[-3:4, -3:4]
            wgt = np.clip(st - np.median(deep[iy - 6:iy + 7, ix - 6:ix + 7]), 0, None)
            if wgt.sum() > 0:
                mx_, my_ = (wgt * xx).sum() / wgt.sum(), (wgt * yy).sum() / wgt.sum()
                cxx = (wgt * (xx - mx_) ** 2).sum() / wgt.sum()
                cyy = (wgt * (yy - my_) ** 2).sum() / wgt.sum()
                cxy = (wgt * (xx - mx_) * (yy - my_)).sum() / wgt.sum()
                tr, det_ = cxx + cyy, cxx * cyy - cxy ** 2
                l1 = tr / 2 + math.sqrt(max(tr ** 2 / 4 - det_, 0))
                l2 = max(tr / 2 - math.sqrt(max(tr ** 2 / 4 - det_, 0)), 1e-6)
                row["deep_size_ratio"] = math.sqrt(tr / 2) / max(psf_sig, 0.3)
                row["deep_elong"] = math.sqrt(l1 / l2)
        # dipole in last-minus-first difference image
        r = 4
        win = diff[iy - r:iy + r + 1, ix - r:ix + r + 1]
        if win.shape == (2 * r + 1, 2 * r + 1):
            kp = np.unravel_index(np.argmax(win), win.shape)
            kn = np.unravel_index(np.argmin(win), win.shape)
            row.update({"dipole_pos": float(win[kp]), "dipole_neg": float(-win[kn]),
                        "dipole_sep_px": float(math.hypot(kp[0] - kn[0], kp[1] - kn[1]))})
        # brightness per detector (deep) and per visit (variability)
        flux_det = {}
        for d in f.detectors:
            vals = [_aperture(f.images[(v, d)], xd, yd) for v in f.visits if (v, d) in f.images]
            vals = [q for q in vals if np.isfinite(q)]
            flux_det[d] = float(np.median(vals)) * PIX_UJY if vals else float("nan")
        def color(a, b):
            fa, fb = flux_det.get(a, np.nan), flux_det.get(b, np.nan)
            return -2.5 * math.log10(fa / fb) if fa > 0 and fb > 0 else np.nan
        row.update({"c12": color(1, 2), "c23": color(2, 3), "c34": color(3, 4), "c45": color(4, 5),
                    "c56": color(5, 6)})
        blue = sum(max(flux_det.get(d, 0) or 0, 0) for d in (1, 2, 3))
        red = sum(max(flux_det.get(d, 0) or 0, 0) for d in (4, 5, 6))
        row["frac_blue"] = blue / (blue + red) if blue + red > 0 else np.nan
        dms = []
        for d in f.detectors:
            series = []
            for j, v in enumerate(f.visits):
                if (v, d) in f.images:
                    xv, yv = (vx[j], vy[j]) if len(vx) == len(f.visits) else (xd, yd)
                    series.append(_aperture(f.images[(v, d)], xv, yv))
            series = np.array([s for s in series if np.isfinite(s) and s > 0])
            if len(series) >= 2:
                dms.extend(-2.5 * np.log10(series / np.median(series)))
        if dms:
            dms = np.array(dms)
            row["var_mad_mag"] = float(1.4826 * np.median(np.abs(dms - np.median(dms))))
            row["var_range_mag"] = float(np.percentile(dms, 90) - np.percentile(dms, 10))
        row["flux_ujy_by_det"] = flux_det
        rows.append(row)
    return rows


# --------------------------------------------------------------------------- catalogs and labels

def grid_wcs(index: dict):
    from astropy.wcs import WCS
    g = index["stack_grid"]
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [index["field_center"]["ra"], index["field_center"]["dec"]]
    w.wcs.crpix = [(g["npix"] + 1) / 2.0, (g["npix"] + 1) / 2.0]
    s = g["pixel_scale_arcsec"] / 3600.0
    w.wcs.cdelt = [-s, s]
    return w


def gaia_sources_px(f: Field) -> np.ndarray:
    """Gaia DR3 sources propagated to the field's mean epoch, as rows (x, y, pm_arcsec_yr, G)."""
    path = DATASET / f.fid / "catalogs" / "gaia_dr3.csv"
    if not path.exists():
        return np.zeros((0, 4))
    w = grid_wcs(f.index)
    rows = []
    dt = (f.t0 - 57388.5) / 365.25
    with open(path, newline="") as fh:
        for r in csv.DictReader(fh):
            try:
                ra, dec = float(r["ra"]), float(r["dec"])
                pmra = float(r["pmra"]) if r["pmra"] not in ("", None) else np.nan
                pmdec = float(r["pmdec"]) if r["pmdec"] not in ("", None) else np.nan
                g = float(r["phot_g_mean_mag"]) if r.get("phot_g_mean_mag") not in ("", None) else np.nan
            except (TypeError, ValueError):
                continue
            if np.isfinite(pmra) and np.isfinite(pmdec):
                dec_e = dec + pmdec * dt / 3.6e6
                ra_e = ra + pmra * dt / 3.6e6 / math.cos(math.radians(dec))
            else:
                ra_e, dec_e = ra, dec
            x, y = w.all_world2pix([[ra_e, dec_e]], 0)[0]
            rows.append((x, y, math.hypot(pmra, pmdec) / 1000.0 if np.isfinite(pmra) else np.nan, g))
    return np.array(rows) if rows else np.zeros((0, 4))


def benchmark_position_px(f: Field) -> Optional[Tuple[float, float, float]]:
    """Where the field's benchmark target (if it is a known mover) sits at the field mean epoch."""
    if f.index.get("kind") != "moving":
        return None
    a = f.index["astrometry"]
    dt = (f.t0 - a["ref_mjd"]) / 365.25
    dec = a["dec"] + a["pmdec_mas_yr"] * dt / 3.6e6
    ra = a["ra"] + a["pmra_mas_yr"] * dt / 3.6e6 / math.cos(math.radians(a["dec"]))
    x, y = grid_wcs(f.index).all_world2pix([[ra, dec]], 0)[0]
    return float(x), float(y), math.hypot(a["pmra_mas_yr"], a["pmdec_mas_yr"]) / 1000.0
