"""
Stacking classifier (LightGBM + XGBoost -> logistic regression), tuned with Optuna, evaluated with
NESTED leave-fields-out cross-validation, and saved as a self-contained .pkl bundle.

Why nested: if Optuna picks hyperparameters on the same folds that are later used to report results,
the reported score is optimistic. Here, for every outer fold of held-out FIELDS, Optuna tunes only on
the remaining fields (inner GroupKFold), and the tuned stack is then scored once on the held-out fields.
The stack's own internal blending folds are also split by field.

Like train.py, models are trained on injected sources only; real Gaia non-moving stars are used only
to set the decision threshold (1% false alarms) and to measure false alarms.

Outputs (ml/movers/output/):
  stack_model.pkl           final tuned stack + features + threshold + settings (pickle)
  stack_metrics.json        nested-CV results, comparison with single LightGBM, benchmarks
  best_hyperparameters_stack.json
  cm_stack.png              confusion matrices (injected sources, real stars)

Usage:
  .venv/Scripts/python.exe ml/movers/train_stack.py --trials 20
"""

from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import lightgbm as lgb
import optuna
import sklearn
import xgboost as xgb
from sklearn.ensemble import StackingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

optuna.logging.set_verbosity(optuna.logging.WARNING)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import train as T  # noqa: E402  (shared features, thresholds, visit rule)

OUT = Path(__file__).resolve().parent / "output"
FEATURES = T.FEATURES
SEED = 7


def grouped_splits(groups: np.ndarray, n: int = 3):
    """Blending folds for the stack, split by field (no field in both train and validation)."""
    k = min(n, len(np.unique(groups)))
    return list(GroupKFold(n_splits=k).split(np.zeros(len(groups)), groups=groups))


def build_stack(p: dict, groups: np.ndarray) -> StackingClassifier:
    lgb_model = lgb.LGBMClassifier(
        n_estimators=p["lgb_n_estimators"], learning_rate=p["lgb_learning_rate"], num_leaves=p["lgb_num_leaves"],
        min_child_samples=p["lgb_min_child_samples"], subsample=p["lgb_subsample"], subsample_freq=1,
        colsample_bytree=p["lgb_colsample"], reg_lambda=p["lgb_reg_lambda"], class_weight="balanced",
        random_state=SEED, verbose=-1, n_jobs=4)
    xgb_model = xgb.XGBClassifier(
        n_estimators=p["xgb_n_estimators"], learning_rate=p["xgb_learning_rate"], max_depth=p["xgb_max_depth"],
        min_child_weight=p["xgb_min_child_weight"], subsample=p["xgb_subsample"], colsample_bytree=p["xgb_colsample"],
        reg_lambda=p["xgb_reg_lambda"], eval_metric="logloss", tree_method="hist", random_state=SEED, n_jobs=4)
    meta = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                         LogisticRegression(C=p["meta_C"], class_weight="balanced", max_iter=2000))
    return StackingClassifier(estimators=[("lightgbm", lgb_model), ("xgboost", xgb_model)], final_estimator=meta,
                              cv=grouped_splits(groups), stack_method="predict_proba",
                              passthrough=p["passthrough"], n_jobs=1)


def suggest(trial: optuna.Trial) -> dict:
    return {
        "lgb_n_estimators": trial.suggest_int("lgb_n_estimators", 80, 400, step=40),
        "lgb_learning_rate": trial.suggest_float("lgb_learning_rate", 0.02, 0.15, log=True),
        "lgb_num_leaves": trial.suggest_int("lgb_num_leaves", 8, 40),
        "lgb_min_child_samples": trial.suggest_int("lgb_min_child_samples", 10, 50),
        "lgb_subsample": trial.suggest_float("lgb_subsample", 0.6, 1.0),
        "lgb_colsample": trial.suggest_float("lgb_colsample", 0.6, 1.0),
        "lgb_reg_lambda": trial.suggest_float("lgb_reg_lambda", 0.01, 5.0, log=True),
        "xgb_n_estimators": trial.suggest_int("xgb_n_estimators", 80, 400, step=40),
        "xgb_learning_rate": trial.suggest_float("xgb_learning_rate", 0.02, 0.15, log=True),
        "xgb_max_depth": trial.suggest_int("xgb_max_depth", 3, 7),
        "xgb_min_child_weight": trial.suggest_int("xgb_min_child_weight", 1, 10),
        "xgb_subsample": trial.suggest_float("xgb_subsample", 0.6, 1.0),
        "xgb_colsample": trial.suggest_float("xgb_colsample", 0.6, 1.0),
        "xgb_reg_lambda": trial.suggest_float("xgb_reg_lambda", 0.05, 5.0, log=True),
        "meta_C": trial.suggest_float("meta_C", 0.05, 10.0, log=True),
        "passthrough": trial.suggest_categorical("passthrough", [False, True]),
    }


def tune(X: pd.DataFrame, y: np.ndarray, groups: np.ndarray, n_trials: int, seed: int) -> tuple[dict, float]:
    """Optuna search maximising average precision over GroupKFold(4) of the given (injected) rows."""
    inner = list(GroupKFold(n_splits=min(4, len(np.unique(groups)))).split(X, y, groups))

    def objective(trial):
        p = suggest(trial)
        oof = np.zeros(len(y))
        for tr, te in inner:
            clf = build_stack(p, groups[tr]).fit(X.iloc[tr], y[tr])
            oof[te] = clf.predict_proba(X.iloc[te])[:, 1]
        return average_precision_score(y, oof)

    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=seed))
    study.optimize(objective, n_trials=n_trials)
    return study.best_params, study.best_value


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trials", type=int, default=20, help="Optuna trials per tuning run")
    args = ap.parse_args()
    t_start = time.time()

    df = pd.read_csv(OUT / "training_set.csv")
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    data = df[(df["label"] >= 0) & (df["benchmark"] == 0)].reset_index(drop=True)
    X, y, groups = data[FEATURES], data["label"].to_numpy(), data["field"].to_numpy()
    is_inj = (data["source"] == "injected").to_numpy()
    real_static = ((data["source"] == "real") & (y == 0)).to_numpy()
    valid = T.valid_mask(data)
    inj_mover = is_inj & (y == 1)

    outer = list(GroupKFold(n_splits=5).split(X, y, groups))
    oof = {"stack": np.zeros(len(y)), "lightgbm": np.zeros(len(y)), "rule": T.rule_score(data)}
    thr = {k: np.zeros(len(y)) for k in oof}
    fold_params = []
    print(f"Nested CV: 5 outer folds by field, Optuna {args.trials} trials per fold (inner 4-fold by field)")
    for k, (tr, te) in enumerate(outer):
        t0 = time.time()
        fit = tr[is_inj[tr]]
        best, inner_ap = tune(X.iloc[fit].reset_index(drop=True), y[fit], groups[fit], args.trials, SEED + k)
        fold_params.append(best)
        models = {"stack": build_stack(best, groups[fit]).fit(X.iloc[fit], y[fit]),
                  "lightgbm": T.make_lgbm().fit(X.iloc[fit], y[fit])}     # single-model baseline, same folds
        for name, m in models.items():
            s_tr = np.where(valid[tr], m.predict_proba(X.iloc[tr])[:, 1], 0.0)
            oof[name][te] = np.where(valid[te], m.predict_proba(X.iloc[te])[:, 1], 0.0)
            thr[name][te] = T.threshold_for_false_alarm(s_tr[real_static[tr]], T.TARGET_FALSE_ALARM)
        thr["rule"][te] = T.threshold_for_false_alarm(oof["rule"][tr][real_static[tr]], T.TARGET_FALSE_ALARM)
        held = sorted(set(groups[te]))
        print(f"  fold {k + 1}: held-out {held}  inner AP {inner_ap:.4f}  ({time.time() - t0:.0f}s)", flush=True)

    results = {}
    for name in oof:
        s, flag = oof[name], oof[name] >= thr[name]
        yi, si, fi = y[is_inj], s[is_inj], flag[is_inj]
        tp, fp = int((fi & (yi == 1)).sum()), int((fi & (yi == 0)).sum())
        tn, fn = int((~fi & (yi == 0)).sum()), int((~fi & (yi == 1)).sum())
        results[name] = {
            "roc_auc_injected": round(float(roc_auc_score(yi, si)), 4),
            "average_precision_injected": round(float(average_precision_score(yi, si)), 4),
            "recall_injected_movers": round(float(flag[inj_mover].mean()), 4),
            "precision_injected": round(tp / max(1, tp + fp), 4),
            "confusion_matrix_injected": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
            "real_static_false_alarms": int(flag[real_static].sum()),
            "real_static_total": int(real_static.sum()),
            "false_alarm_rate_real_static": round(float(flag[real_static].mean()), 4),
        }

    # Final model: tune on ALL fields, fit on all injected rows, threshold on all real non-moving stars
    print("Final tuning on all fields...", flush=True)
    best_all, best_ap = tune(X[is_inj].reset_index(drop=True), y[is_inj], groups[is_inj], args.trials, SEED + 99)
    final = build_stack(best_all, groups[is_inj]).fit(X[is_inj], y[is_inj])

    def score(frame: pd.DataFrame) -> np.ndarray:
        return np.where(T.valid_mask(frame), final.predict_proba(frame[FEATURES])[:, 1], 0.0)

    final_thr = T.threshold_for_false_alarm(score(data[real_static]), T.TARGET_FALSE_ALARM)
    bench = df[df["benchmark"] == 1].copy()
    bench_rows = []
    for r, p in zip(bench.itertuples(), score(bench) if len(bench) else []):
        bench_rows.append({"field": r.field, "catalog_pm_arcsec_yr": round(float(r.true_pm_arcsec_yr), 2),
                           "measured_pm_arcsec_yr": None if pd.isna(r.pm_fit_arcsec_yr) else round(float(r.pm_fit_arcsec_yr), 2),
                           "p_mover": round(float(p), 3), "flagged": bool(p >= final_thr)})

    bundle = {
        "model": final,
        "model_type": "sklearn.ensemble.StackingClassifier(LightGBM + XGBoost -> LogisticRegression)",
        "features": FEATURES,
        "threshold": round(float(final_thr), 6),
        "min_visits": T.MIN_VISITS,
        "target_false_alarm_rate": T.TARGET_FALSE_ALARM,
        "mover_threshold_arcsec_yr": 1.0,
        "hyperparameters": best_all,
        "nested_cv": results,
        "training_data": "synthetic point sources injected into real SPHEREx visit stacks (injected rows only)",
        "versions": {"sklearn": sklearn.__version__, "lightgbm": lgb.__version__, "xgboost": xgb.__version__,
                     "python": sys.version.split()[0]},
        "usage": "p = bundle['model'].predict_proba(X[bundle['features']])[:, 1]; "
                 "flag = (p >= bundle['threshold']) & (X['n_vis_det'] >= bundle['min_visits'])",
    }
    with open(OUT / "stack_model.pkl", "wb") as fh:
        pickle.dump(bundle, fh)
    metrics = {"evaluation": "nested leave-fields-out CV (5 outer folds; Optuna inner 4-fold by field)",
               "optuna_trials_per_run": args.trials, "results": results, "deployed_threshold": bundle["threshold"],
               "final_hyperparameters": best_all, "final_inner_average_precision": round(best_ap, 4),
               "fold_hyperparameters": fold_params, "benchmarks": bench_rows,
               "runtime_minutes": round((time.time() - t_start) / 60, 1)}
    (OUT / "stack_metrics.json").write_text(json.dumps(metrics, indent=2))
    (OUT / "best_hyperparameters_stack.json").write_text(json.dumps(best_all, indent=2))

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 4))
    cmi = results["stack"]["confusion_matrix_injected"]
    mats = [np.array([[cmi["tn"], cmi["fp"]], [cmi["fn"], cmi["tp"]]]),
            np.array([[results["stack"]["real_static_total"] - results["stack"]["real_static_false_alarms"],
                       results["stack"]["real_static_false_alarms"]]])]
    titles = ["Injected sources (held-out fields)", "Real non-moving Gaia stars"]
    for ax, mat, title in zip(axes, mats, titles):
        ax.imshow(mat, cmap="Blues")
        for (i, j), v in np.ndenumerate(mat):
            ax.text(j, i, f"{v:,}", ha="center", va="center", fontsize=11,
                    color="white" if v > mat.max() / 2 else "black")
        ax.set_xticks([0, 1], ["predicted static", "predicted mover"])
        ax.set_yticks(range(mat.shape[0]), ["true static", "true mover"][:mat.shape[0]])
        ax.set_title(title, fontsize=10)
    fig.suptitle(f"Stack (LightGBM + XGBoost, Optuna), nested CV: recall {results['stack']['recall_injected_movers']:.1%} "
                 f"at {results['stack']['false_alarm_rate_real_static']:.2%} real false alarms", fontsize=10)
    fig.tight_layout()
    fig.savefig(OUT / "cm_stack.png", dpi=130)
    plt.close(fig)

    print("\nNested CV (each number from fields the model and its tuning never saw):")
    for name, r in results.items():
        print(f"  {name:9} movers found {r['recall_injected_movers']:.1%}  real false alarms "
              f"{r['real_static_false_alarms']}/{r['real_static_total']} ({r['false_alarm_rate_real_static']:.2%})  "
              f"AUC {r['roc_auc_injected']}  AP {r['average_precision_injected']}")
    for b in bench_rows:
        print("  benchmark", b)
    print(f"Saved {OUT / 'stack_model.pkl'} (threshold p >= {bundle['threshold']:.4f})  "
          f"[{metrics['runtime_minutes']} min]")
    return 0


if __name__ == "__main__":
    sys.exit(main())
