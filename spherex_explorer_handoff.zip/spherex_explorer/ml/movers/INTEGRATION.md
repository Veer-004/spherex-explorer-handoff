# Mover model: integration guide

## Files

| File | What it is |
|---|---|
| `stack_model.pkl` | Trained stacking classifier (LightGBM + XGBoost → logistic regression), tuned with Optuna, plus its features, threshold and settings |
| `simulate.py` | Simulator: creates model input rows by injecting sources into real SPHEREx fields, and scores them |
| `movers.py` | Detection, measurement and feature pipeline (needed by `simulate.py` and for scoring real fields) |
| `build_training_set.py` | Injection helpers (colors, noise level, jitter) used by `simulate.py` |

Put the three `.py` files in one folder (in this repo: `ml/movers/`) and `stack_model.pkl` in
`ml/movers/output/`. The simulator and pipeline read real SPHEREx data from `dataset/spherex/`
(built by `dataset/build_dataset.py`).

## Requirements

Python 3.10+ with `numpy scipy astropy pandas scikit-learn lightgbm xgboost`.
The pickle was saved with scikit-learn 1.6.1, LightGBM 4.7.0 and XGBoost 3.2.0 (Python 3.11).
Use the same or compatible versions; `bundle["versions"]` lists them. Only load pickles from a
trusted source.

## Using the model

```python
import pickle
import pandas as pd

with open("ml/movers/output/stack_model.pkl", "rb") as fh:
    b = pickle.load(fh)

# X: a DataFrame with the feature columns produced by movers.measure() (or simulate.py)
p = b["model"].predict_proba(X[b["features"]])[:, 1]
is_mover = (p >= b["threshold"]) & (X["n_vis_det"] >= b["min_visits"])
```

| Bundle key | Meaning |
|---|---|
| `model` | scikit-learn `StackingClassifier`; call `predict_proba` |
| `features` | 23 input columns, in order (NaN is allowed) |
| `threshold` | Score at which ~1% of real non-moving Gaia stars are flagged |
| `min_visits` | Only claim motion if the source is detected in at least this many visits (3) |
| `nested_cv` | Honest evaluation results (fields the model and its tuning never saw) |
| `hyperparameters` | Optuna-chosen settings |
| `versions` | Library versions used for training |

## Using the simulator

From the repository root:

```bash
python ml/movers/simulate.py --list-fields
python ml/movers/simulate.py --field survey_05 --n 20
python ml/movers/simulate.py --field wise_0855 --n 5 --pm 6 --snr 80 --angle 45 --sed cold_brown_dwarf
python ml/movers/simulate.py --n 200 --pm 3 --snr-range 5 500 --no-model --out sweep.csv
```

| Option | Meaning |
|---|---|
| `--field` | Real SPHEREx field to simulate in |
| `--n` | Number of sources |
| `--pm`, `--pm-range` | Proper motion in ″/yr (default: half movers 1–15″/yr, half near-static) |
| `--angle` | Direction of motion in degrees (0 = west, 90 = north) |
| `--snr`, `--snr-range` | Signal-to-noise per visit stack |
| `--sed` | Color type: `random`, `real_copy`, `flat`, `blue`, `red`, `cold_brown_dwarf`, `lumpy` |
| `--var-amp` | Brightness variation between visits (0 = constant) |
| `--model` | Model `.pkl` to score with (default `stack_model.pkl`) |
| `--no-model` | Only output input features |
| `--out` | CSV path (default `ml/movers/output/simulated.csv`) |

Output CSV columns: the true parameters (`true_pm_arcsec_yr`, `true_angle_deg`, `snr_target`, `sed`,
`var_amp`, `true_mover`), `detected`, all 29 measured features (the model uses 23), and `p_mover` /
`flagged` when scored.

## In the app

The backend scores fields at `GET /api/movers?target_id=...`. To serve this stack model instead of the
default LightGBM, set the environment variable `SPHEREX_MOVER_MODEL=stack_model.pkl` before starting the
backend.
