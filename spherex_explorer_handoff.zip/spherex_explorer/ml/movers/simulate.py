"""
SPHEREx mover simulator: generates model-input data by simulating sources in REAL SPHEREx fields.

You describe the sources (motion, brightness, colour type, variability), or let the simulator draw
random ones. It injects them into the real visit stacks of a field with that field's own PSF, noise,
jitter and crowding, runs the real detection + measurement pipeline (ml/movers/movers.py), and writes
exactly the feature rows the model consumes. If a model .pkl is given (default: the stacking model),
each row is also scored, so you can see what the model would say about that kind of source.

Examples (from the repository root):
  # 20 random sources (half movers) in a field, scored by the stack model
  .venv/Scripts/python.exe ml/movers/simulate.py --field survey_05 --n 20

  # one brown-dwarf-like mover: 6"/yr, signal-to-noise 80 per visit, moving north-east
  .venv/Scripts/python.exe ml/movers/simulate.py --field wise_0855 --n 1 --pm 6 --snr 80 --angle 45 --sed cold_brown_dwarf

  # detection-limit sweep: 200 movers at 3"/yr over a brightness range, features only
  .venv/Scripts/python.exe ml/movers/simulate.py --n 200 --pm 3 --snr-range 5 500 --no-model --out sweep.csv

  # list the fields you can simulate in
  .venv/Scripts/python.exe ml/movers/simulate.py --list-fields

Output: CSV (default ml/movers/output/simulated.csv) with the true parameters, whether the pipeline
detected the source, the 23 model features, and (if scored) p_mover and flagged.
"""

from __future__ import annotations

import argparse
import math
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import movers as M  # noqa: E402
import build_training_set as B  # noqa: E402

DEFAULT_MODEL = HERE / "output" / "stack_model.pkl"
FALLBACK_MODEL = HERE / "output" / "mover_model.pkl"
SED_CHOICES = ["random", "real_copy"] + list(B.SEDS)


def available_fields() -> list[str]:
    return sorted(p.name for p in M.DATASET.iterdir() if (p / "index.json").exists())


def draw(rng: np.random.Generator, lo_hi: tuple[float, float] | None, fixed: float | None, log: bool) -> float:
    if fixed is not None:
        return float(fixed)
    lo, hi = lo_hi
    return float(np.exp(rng.uniform(math.log(lo), math.log(hi)))) if log else float(rng.uniform(lo, hi))


def make_sources(f: M.Field, args, rng: np.random.Generator, existing: np.ndarray, seds_real: list) -> list:
    dets = f.detectors
    noise = {d: B.noise_flux_ujy(f, d) for d in dets}
    lo, hi = M.EDGE + 1.5, f.npix - M.EDGE - 2.5
    out = []
    for i in range(args.n):
        # placement: keep sources apart from real stars and from each other so truth matching is unambiguous
        placed = np.vstack([existing] + [np.array([[s.x0, s.y0]]) for s in out]) if (len(existing) or out) else np.zeros((0, 2))
        for _ in range(200):
            x, y = rng.uniform(lo, hi, 2)
            if not len(placed) or np.min(np.hypot(placed[:, 0] - x, placed[:, 1] - y)) > args.min_sep:
                break
        if args.pm is not None:
            pm = float(args.pm)
        elif args.pm_range:
            pm = draw(rng, tuple(args.pm_range), None, log=args.pm_range[0] > 0)
        else:                                            # default: half movers 1-15"/yr, half near-static
            pm = draw(rng, (1.0, 15.0), None, log=True) if rng.random() < 0.5 else float(rng.uniform(0, 0.5))
        ang = math.radians(args.angle) if args.angle is not None else rng.uniform(0, 2 * math.pi)
        snr = draw(rng, tuple(args.snr_range), args.snr, log=True)

        sed_name = args.sed
        if sed_name == "random":
            sed_name = "real_copy" if (seds_real and rng.random() < 0.75) else str(rng.choice(list(B.SEDS)))
        if sed_name == "real_copy" and seds_real:
            sed = seds_real[rng.integers(len(seds_real))] * np.exp(rng.normal(0, 0.1, 6))
        else:
            sed_name = "flat" if sed_name == "real_copy" else sed_name
            sed = B.SEDS[sed_name](rng)
        sed = sed / sed[[d - 1 for d in dets]].max()
        ref = max(dets, key=lambda d: sed[d - 1])
        flux = {d: float(snr * noise[ref] * sed[d - 1]) for d in dets}
        var_amp = float(args.var_amp) if args.var_amp is not None else (float(rng.uniform(0.1, 0.6)) if rng.random() < 0.3 else 0.0)

        s = M.Injection(
            inj_id=f"SIM-{f.fid}-{i:04d}", x0=float(x), y0=float(y),
            pm_x=pm * math.cos(ang) / M.PIX_ARCSEC, pm_y=pm * math.sin(ang) / M.PIX_ARCSEC,
            flux_ujy=flux, var_amp=var_amp, var_phase=float(rng.uniform(0, 2 * math.pi)),
            pm_arcsec_yr=pm, sed=sed_name,
            jitter={v: (float(rng.normal(0, B.JITTER_PX)), float(rng.normal(0, B.JITTER_PX))) for v in f.visits},
            flux_scatter={k: float(rng.normal(0, B.FLUX_SCATTER)) for k in f.images})
        s.snr_target = snr                             # type: ignore[attr-defined]
        s.angle_deg = math.degrees(ang) % 360          # type: ignore[attr-defined]
        out.append(s)
    return out


def load_model(path: Path):
    with open(path, "rb") as fh:
        b = pickle.load(fh)
    model = b["model"]
    if hasattr(model, "predict_proba"):
        predict = lambda X: model.predict_proba(X)[:, 1]
    else:                                              # lightgbm.Booster
        predict = lambda X: model.predict(X)
    return b, predict


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--field", default="survey_05", help="dataset field to simulate in (see --list-fields)")
    ap.add_argument("--n", type=int, default=20, help="number of sources to simulate")
    ap.add_argument("--pm", type=float, help='fixed proper motion in "/yr (overrides the default mix)')
    ap.add_argument("--pm-range", type=float, nargs=2, metavar=("MIN", "MAX"), help='proper motion range in "/yr')
    ap.add_argument("--angle", type=float, help="direction of motion in degrees (0 = west/+x, 90 = north)")
    ap.add_argument("--snr", type=float, help="fixed signal-to-noise per visit stack")
    ap.add_argument("--snr-range", type=float, nargs=2, default=[5.0, 1000.0], metavar=("MIN", "MAX"))
    ap.add_argument("--sed", default="random", choices=SED_CHOICES, help="colour type across detectors D1-D6")
    ap.add_argument("--var-amp", type=float, help="fractional brightness variation between visits (0 = constant)")
    ap.add_argument("--min-sep", type=float, default=4.0, help="minimum separation from other sources (px)")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--model", default=None, help="model .pkl (default: stack_model.pkl, else mover_model.pkl)")
    ap.add_argument("--no-model", action="store_true", help="only generate the input features")
    ap.add_argument("--out", default=str(HERE / "output" / "simulated.csv"))
    ap.add_argument("--list-fields", action="store_true")
    args = ap.parse_args()

    fields = available_fields()
    if args.list_fields:
        for fid in fields:
            print(fid)
        return 0
    if args.field not in fields:
        print(f"Unknown field '{args.field}'. Choose one of: {', '.join(fields)}", file=sys.stderr)
        return 2
    if args.n < 1:
        print("--n must be at least 1", file=sys.stderr)
        return 2

    rng = np.random.default_rng(args.seed)
    f = M.load_field(args.field)
    if len(f.visits) < 2:
        print(f"{args.field} has fewer than 2 visits; motion cannot be simulated there.", file=sys.stderr)
        return 2
    vs0 = M.visit_snr_images(f)
    real = M.measure(f, vs0, M.detect(f, vs0))
    existing = np.array([[r["x"], r["y"]] for r in real]) if real else np.zeros((0, 2))
    sources = make_sources(f, args, rng, existing, B.real_seds(real, f.detectors))

    g = M.inject(f, sources)
    vs = M.visit_snr_images(g)
    meas = M.measure(g, vs, M.detect(g, vs))
    pos = np.array([[m["x"], m["y"]] for m in meas]) if meas else np.zeros((0, 2))
    used: set[int] = set()

    rows = []
    for s in sources:
        hit = -1
        if len(pos):
            dd = np.hypot(pos[:, 0] - s.x0, pos[:, 1] - s.y0)
            for j in np.argsort(dd):
                if dd[j] > 2.0:
                    break
                if j not in used:
                    hit = int(j)
                    break
        row = {"sim_id": s.inj_id, "field": args.field, "true_pm_arcsec_yr": round(s.pm_arcsec_yr, 3),
               "true_angle_deg": round(s.angle_deg, 1), "snr_target": round(s.snr_target, 1), "sed": s.sed,
               "var_amp": round(s.var_amp, 3), "true_mover": int(s.pm_arcsec_yr >= M.MOVER_THRESHOLD_ARCSEC_YR),
               "x0": round(s.x0, 2), "y0": round(s.y0, 2), "detected": int(hit >= 0)}
        if hit >= 0:
            used.add(hit)
            row.update({c: meas[hit].get(c, np.nan) for c in M.FEATURES})
        rows.append(row)
    df = pd.DataFrame(rows)
    for c in M.FEATURES:
        if c not in df:
            df[c] = np.nan

    if not args.no_model:
        path = Path(args.model) if args.model else (DEFAULT_MODEL if DEFAULT_MODEL.exists() else FALLBACK_MODEL)
        bundle, predict = load_model(path)
        det = df["detected"] == 1
        df["p_mover"] = np.nan
        df["flagged"] = False
        if det.any():
            Xd = df.loc[det, bundle["features"]].apply(pd.to_numeric, errors="coerce")
            p = predict(Xd)
            ok = df.loc[det, "n_vis_det"].fillna(0).to_numpy() >= bundle["min_visits"]
            df.loc[det, "p_mover"] = np.where(ok, p, 0.0)
            df.loc[det, "flagged"] = df.loc[det, "p_mover"] >= bundle["threshold"]
        model_name = path.name

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)

    n_mov = int(df["true_mover"].sum())
    print(f"Field {args.field}: {len(f.visits)} visits, detectors {''.join(map(str, f.detectors))}; "
          f"simulated {len(df)} sources ({n_mov} movers), {int(df['detected'].sum())} detected by the pipeline")
    show = ["sim_id", "true_pm_arcsec_yr", "snr_target", "sed", "detected", "pm_fit_arcsec_yr", "pm_sig", "n_vis_det"]
    if not args.no_model:
        show += ["p_mover", "flagged"]
        found = int((df["flagged"] & (df["true_mover"] == 1)).sum())
        false = int((df["flagged"] & (df["true_mover"] == 0)).sum())
        print(f"Model {model_name} (threshold {bundle['threshold']:.3f}): flagged {found}/{n_mov} movers, "
              f"{false}/{len(df) - n_mov} non-movers")
    with pd.option_context("display.max_rows", 40, "display.width", 160, "display.float_format", "{:.3f}".format):
        print(df[show].head(40).to_string(index=False))
    used_by_model = f"; the model uses {len(bundle['features'])} of them" if not args.no_model else ""
    print(f"Wrote {len(df)} rows ({len(M.FEATURES)} measured features each{used_by_model}) to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
