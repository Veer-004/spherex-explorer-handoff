# SPHEREx moving-object classifier

A machine-learning model that flags sources in real SPHEREx images whose position changes between
survey visits. It is trained on **synthetic stars injected into real SPHEREx visit stacks** and
tested on **real stars** from fields it never saw.

## Why injection

Real movers are extremely rare: the 15 fields in this dataset contain only two measurable ones
(Barnard's Star and Epsilon Indi B). That is far too few to train a model. A purely simulated
universe would not help either, because a model trained on it learns the simulator instead of SPHEREx.

So we keep everything real (the images, noise, PSF, artifacts, crowding and blends) and add point
sources whose motion we control. Because we placed them, every injected star has an exact label.
Survey teams use the same technique (injection-recovery) to measure what their pipelines can detect.

## How it works

1. **Data:** stacked SPHEREx images, one per visit and detector, from `dataset/build_dataset.py`.
   That covers 15 fields, 2–6 visits each, May 2025 to September 2026, all from IRSA.
2. **Empirical PSF:** the star shape is measured from bright, isolated stars in each detector. Each
   visit keeps its own PSF where it has enough stars, so injected stars leave the same visit-to-visit
   subtraction residuals that real stars do.
3. **Injection:** each of 12 realizations per field adds 25 point sources.

   | Property | How it is drawn |
   |---|---|
   | Motion | Half move at 1–15″/yr (log-uniform), half are near-static (0–0.5″/yr) |
   | Brightness | Signal-to-noise per visit 3–3000 (log-uniform), so faint ones probe the detection limit |
   | Colors | 75% copy a real star in the same field, 25% use templates, including cold brown dwarfs |
   | Variability | 30% vary by 10–60% between visits |
   | Realism | Per-visit position jitter (0.045 px) and 5% flux scatter, matched to real non-moving stars |

   Every property except motion is drawn **independently of the label**, so none of them can act as
   a shortcut for "mover".
4. **Pipeline:** the same detection and measurement code runs on clean and injected images:
   - detection on a combined image across all visits
   - a position in each visit
   - a weighted straight-line motion fit
   - about 23 features: motion and its significance, fit quality, visit-to-visit shifts, smearing in
     the combined image, red/cyan dipole strength in difference images, variability, crowding
5. **Labels:**
   - injected: from the truth (moving faster than 1″/yr = mover)
   - real: from Gaia DR3 (slower than 0.5″/yr = not a mover); used only for testing
   - benchmark targets: tagged and held out completely
6. **Training & Optimization:** 3 tree-based model families (XGBoost, Random Forest, LightGBM)
   optimized using Optuna hyperparameter tuning across 5-fold Leave-Fields-Out Cross-Validation (by astronomical field),
   compared against logistic regression and the baseline rule (proper motion ≥ 1″/yr, ranked by significance).
   The decision threshold is set on the other folds' real Gaia stars to target **~1% false alarms**.
   Motion is only claimed when the source is detected in at least 3 visits.

## Results (leave-fields-out, real false-alarm rate held at about 1%)

| Method | Optuna Tuned | Injected Movers Found (Recall) | Precision | ROC-AUC | PR-AUC (Avg. Prec.) | Real Gaia False Alarms |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| Rule (≥ 1″/yr, sig cut) | No | 45.9% (628/1367) | 94.4% | 0.8644 | 0.8625 | 8 / 758 (1.06%) |
| Logistic Regression | No | 51.4% (703/1367) | 94.0% | 0.8370 | 0.8697 | 9 / 758 (1.19%) |
| **Random Forest** | **Yes** | **68.0% (930/1367)** | **95.3%** | **0.8769** | **0.9108** | **10 / 758 (1.32%)** |
| **XGBoost** | **Yes** | **68.9% (942/1367)** | **95.0%** | **0.8786** | **0.9126** | **11 / 758 (1.45%)** |
| **LightGBM** | **Yes** | **66.7% (912/1367)** | **95.5%** | **0.8784** | **0.9130** | **8 / 758 (1.06%)** |

All three Optuna-optimized tree models significantly outperform the linear model and rule-based baseline.
LightGBM delivers the highest precision (95.5%) and best false-alarm control (1.06%), while XGBoost achieves the highest overall mover recall (68.9%).

Completeness (share of ALL injected movers both detected and flagged), by motion and brightness:

| Motion (″/yr) | S/N 20–50 | 50–300 | 300–3000 |
|---|---|---|---|
| 1–2 | 4% (rule 1%) | 23% (rule 2%) | 43% (rule 7%) |
| 2–4 | 15% (12%) | 48% (25%) | 80% (33%) |
| 4–8 | 23% (16%) | 57% (51%) | 79% (75%) |
| 8–15 | 36% (32%) | 65% (58%) | 79% (79%) |

The gain is largest for slower movers (1–4″/yr), where a single significance cut fails. Below a
signal-to-noise of about 20 per visit, both methods find very little: those sources are rarely
detected at all (27% at S/N 10–20).

### Real benchmark movers (never used in training)

| Target | Catalog motion | SPHEREx measured | Model score | Flagged |
|---|---|---|---|---|
| Barnard's Star | 10.39″/yr | 10.07″/yr (11.6σ) | 0.97 | yes |
| Epsilon Indi B | 4.68″/yr | 4.29″/yr (6.7σ) | 0.99 | yes |
| WISE 0855−0714 | 8.09″/yr | 0.51″/yr | 0.16 | no (correct: blended with a background star, see `dataset/README.md`) |

### Real unknown sources

177 detected sources have no Gaia match. Two are flagged. Both are faint (S/N 12–15, 3 visits,
1.3–2.0σ motion). At a 1% false-alarm rate, about 2 false alarms are expected among 177 sources,
so these are **not** claimed as discoveries. They are listed in `output/candidates_real.csv` for
visual checking.

## Honest limitations

- **Injected and real non-movers remain partly distinguishable.** A domain check (a classifier
  trained to tell them apart) reaches AUC 0.89, mainly through brightness and visit-level S/N,
  because injections span a wider brightness range than real detections. For that reason, the
  false-alarm rate is **measured directly on real Gaia stars**, not inferred from injections.
- Only two real movers can be checked. Recall on real movers is therefore shown per object, not
  as a percentage.
- Motion range: 1–15″/yr (nearby stars and brown dwarfs). Asteroids move far faster and appear in
  only one exposure, so they need a different (single-visit streak) method.
- Injections are added to the final stacks, after the builder's background filter. That's a minor
  difference for point sources (the filter is 15 px wide, the PSF about 1.6 px).
- 15 fields, mostly 3–5 visits. Results will improve as SPHEREx adds visits and fields are added.

## Run it

```bash
.venv/Scripts/python.exe ml/movers/build_training_set.py   # ~1 min: injections + measurements
.venv/Scripts/python.exe ml/movers/train.py                # ~1 min: CV, metrics, model, plots
```

Outputs in `ml/movers/output/`:

| File | Contents |
|---|---|
| `training_set.csv` | Every measured source: features, label, provenance |
| `injections.csv` | Every injected source: truth, and whether it was detected |
| `model_lightgbm.txt` | Trained LightGBM booster |
| `model_xgboost.json` | Trained XGBoost model |
| `model_random_forest.joblib` | Trained Random Forest pipeline |
| `best_hyperparameters.json` | Best hyperparameters discovered by Optuna |
| `model_meta.json` | Deployed model specifications, features, operating threshold |
| `metrics.json` | Comprehensive cross-validation metrics and confusion matrices |
| `confusion_matrix.png` | 3-panel side-by-side confusion matrices (XGBoost, Random Forest, LightGBM) |
| `model_comparison.png` | Bar chart comparing ROC-AUC, Average Precision, and Recall |
| `roc.png` | Movers found vs. real sky false alarms across models |
| `completeness.png` | Completeness by proper motion and brightness |
| `feature_importance.png` | Top predictive features |
| `candidates_real.csv` | Real sky sources ranked by mover probability |

Top features: fitted motion, first-to-last visit shift, motion significance, smearing in the combined
image, dipole separation, and fit quality.

## Data credits

SPHEREx Level-2 images (NASA/JPL-Caltech, via IRSA); Gaia DR3 (ESA/Gaia/DPAC, via IRSA).
Software: NumPy, SciPy, Astropy, scikit-learn, LightGBM, pandas, Matplotlib.
