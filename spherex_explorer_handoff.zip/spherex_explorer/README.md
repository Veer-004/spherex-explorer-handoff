# SPHEREx Explorer

> *Discover what moves beyond our eyes.*

A public web tool for the 2026 NASA Space Apps challenge: enter a position on the sky (RA/Dec) and
watch real NASA **SPHEREx** images of that patch change over time, like a short video, so anyone can
spot moving and variable objects.

All images, positions and fluxes come from **SPHEREx Level-2 spectral images** at the
NASA/IPAC Infrared Science Archive (IRSA). Nothing is simulated.

## What it does

| View | What you see |
|---|---|
| **Sky Explorer** | One stacked image per survey visit, for the chosen detector (D1–D6, 0.75–5 µm). Field of view 3′–12′, stretch and colormap controls, optional Gaia DR3 / CatWISE2020 overlays. |
| **Time Machine** | Blink between visits, side-by-side comparison, and difference images (later minus earlier). Moving objects leave a red/cyan pair. The target's measured position in each visit is drawn as a track. |
| **Spectrum** | SPHEREx's filters make every exposure see the target at a slightly different wavelength. Each exposure's flux becomes one spectrum point, averaged into 102 channels. Saturated targets are reported as such. |
| **Discoveries** | Automatic measurements for every field (e.g. proper motion fitted from SPHEREx positions), plus candidates users flag. Exportable as CSV. |
| **Any position** | Search a name or coordinates. If the field isn't downloaded yet, the app offers to fetch it from IRSA in the background (a few minutes). |

Deep links: `?target=barnards_star&tab=time-machine&detector=D1` or `?ra=133.786&dec=-7.244`.

### Example result

From SPHEREx data alone, the app measures **Barnard's Star moving 10.33 ± 0.29″/yr**
(Gaia DR3: 10.39″/yr), from 200 positions over 1.1 years. The difference image shows the classic
red/cyan pair while background stars cancel.

## Benchmark targets

Barnard's Star, WISE 0855-0714, Epsilon Indi B, RW Aurigae and R Draconis. They're defined in
[`dataset/targets.json`](dataset/targets.json); positions and proper motions are looked up in Gaia DR3 or CatWISE2020.

## Run it locally

Requirements: Python 3.10+, Node.js 18+.

```bash
python -m venv .venv
.venv/Scripts/python.exe -m pip install -r backend/requirements.txt -r dataset/requirements.txt
```

**1. Build the dataset** (downloads real SPHEREx cutouts from IRSA; about 15 minutes per target):

```bash
.venv/Scripts/python.exe dataset/build_dataset.py
```

See [`dataset/README.md`](dataset/README.md) for options, output layout and limitations.

**2. Start the backend** (from the repository root):

```bash
.venv/Scripts/python.exe -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

API docs: http://127.0.0.1:8000/docs

**3. Start the frontend:**

```bash
cd frontend
npm install
npm run dev -- --host 127.0.0.1 --port 3000
```

Open http://127.0.0.1:3000

> On Windows with Smart App Control, Rollup's native binary may be blocked. `frontend/package.json`
> overrides `rollup` with `@rollup/wasm-node`, which avoids it.

## Architecture

```
dataset/
  build_dataset.py      IRSA queries, cutouts, per-exposure measurements, per-visit stacks, catalogs
  targets.json          benchmark targets
  spherex/              generated data (git-ignored)
backend/
  main.py               FastAPI endpoints
  dataset_service.py    reads the dataset: images, differences, motion fits, spectra, catalogs, on-demand builds
  imaging.py            stretches and colormaps -> PNG
  astrometry.py         coordinate parsing (Astropy)
  catalog.py            detector/channel tables and target descriptions
frontend/               React + TypeScript + Vite + Tailwind
```

Main API endpoints: `/api/targets`, `/api/observations`, `/api/difference`, `/api/spectrum`,
`/api/motion`, `/api/catalog`, `/api/fields` (on-demand builds), `/api/discoveries`.

## Known limitations

- SPHEREx pixels are 6.15″, so slow movers (under ~2″/yr) need many visits before they stand out.
- Very bright stars saturate SPHEREx. Their motion is still measured from the recorded wings, but no flux is reported.
- Fluxes are aperture measurements without aperture correction: good for shape and change, not absolute calibration.
- Saved discoveries are stored in a local JSON file.

## Data and credits

- **SPHEREx**: NASA/JPL-Caltech, via the NASA/IPAC Infrared Science Archive (IRSA).
- **Gaia DR3**: ESA/Gaia/DPAC, via IRSA.
- **CatWISE2020**: Marocco et al. 2021, via IRSA.
- Data access follows the IRSA SPHEREx tutorial notebooks.
- Software: Astropy, Astroquery, NumPy, SciPy, Pillow, FastAPI, React, Vite, Tailwind CSS, lucide-react.
