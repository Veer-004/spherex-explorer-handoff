# SPHEREx Explorer: team handoff package

Everything needed to run the app on real SPHEREx data, use the trained mover models, and run the
simulator. Built 2026-11-14 from branch `feat/spherex-dataset` (not pushed to GitHub).

## What's inside

| Path | Contents |
|---|---|
| `backend/` | FastAPI API: real-data service, `/api/movers` (ML candidates), FITS upload, IRSA lookup |
| `frontend/` | React app (source only; run `npm install`) |
| `dataset/` | Dataset builder (`build_dataset.py`), target list, docs |
| `dataset/spherex/` | **The dataset**: 15 real SPHEREx fields with per-visit stacks, measurements (`exposures.csv`), Gaia DR3 + CatWISE2020 catalogs, previews |
| `ml/movers/` | Mover pipeline (`movers.py`), injection builder, trainers, **simulator (`simulate.py`)**, docs |
| `ml/movers/output/` | **Models and results** (see below), training set CSVs |
| `wiseview/` | Teammate's WiseView blink viewer (SPHEREx mode) |
| `README.md` | Project overview and run instructions |

### Models (`ml/movers/output/`)

| File | Model | Notes |
|---|---|---|
| `stack_model.pkl` | **Stacking: LightGBM + XGBoost → logistic regression, Optuna-tuned** | Self-contained bundle: model, 23 features, threshold 0.854, settings, nested-CV results, library versions |
| `mover_model.pkl` | Tuned single LightGBM | Same bundle format (threshold 0.811); the app's default model |
| `model_lightgbm.txt`, `model_meta.json` | Same LightGBM as native LightGBM text + metadata | Used by the backend by default |
| `model_xgboost.json`, `model_random_forest.joblib` | XGBoost and random forest from `train.py` | For comparison |
| `stack_metrics.json`, `metrics.json` | All evaluation numbers | |
| `*.png` | Completeness, false-alarm curves, confusion matrices, feature importance | |
| `training_set.csv`, `injections.csv` | The injection training set and its ground truth | |

### Results (fields never seen by the model or its tuning)

| Model | Movers found | Real non-moving Gaia stars flagged |
|---|---|---|
| Stack (LightGBM + XGBoost, Optuna) | 68.0% | 10 / 758 (1.32%) |
| Single LightGBM | 65.3% | 7 / 758 (0.92%) |
| Simple rule (≥1″/yr + significance) | 45.9% | 8 / 758 (1.06%) |

Real benchmark movers (never used for training): Barnard's Star flagged (0.95), Epsilon Indi B
flagged (0.96), WISE 0855 not flagged (0.17). That last one is correct: it is blended with a
background star in all SPHEREx images so far.

## Setup

```bash
python -m venv .venv
.venv/Scripts/python.exe -m pip install -r backend/requirements.txt -r dataset/requirements.txt
.venv/Scripts/python.exe -m pip install pandas scikit-learn==1.6.1 lightgbm==4.7.0 xgboost==3.2.0 optuna matplotlib
cd frontend && npm install
```

The pickles were saved with Python 3.11, scikit-learn 1.6.1, LightGBM 4.7.0 and XGBoost 3.2.0; use
matching versions to load them. Only load pickles from a trusted source.

## Run

```bash
.venv/Scripts/python.exe -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
cd frontend && npm run dev -- --host 127.0.0.1 --port 3000
```

Open http://127.0.0.1:3000. To make the app use the stack model instead of LightGBM, start the
backend with `SPHEREX_MOVER_MODEL=stack_model.pkl`.

Simulator examples and the model API are in `ml/movers/INTEGRATION.md`.

## Not included

- **Raw per-exposure cutouts** (`dataset/spherex/*/cutouts/`, ~900 MB). Not needed to run the app,
  model or simulator. To rebuild the dataset from scratch, run `dataset/build_dataset.py`; it
  re-downloads them from NASA IRSA.
- `.venv`, `node_modules`, `.git`, caches.
- `ml/results/` and `ml/data/`: outputs of an earlier experiment whose code no longer exists.

## Data credits

SPHEREx (NASA/JPL-Caltech) via NASA/IPAC IRSA; Gaia DR3 (ESA/Gaia/DPAC); CatWISE2020 (Marocco et al.
2021); WiseView (public domain, cite ascl:1806.004).
