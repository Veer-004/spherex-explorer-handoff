# SPHEREx benchmark dataset

Real NASA SPHEREx observations of the five challenge targets, downloaded from the
NASA/IPAC Infrared Science Archive (IRSA) and organized for the SPHEREx Explorer app.

| Target | Why it is in the challenge |
|---|---|
| Barnard's Star | Fastest-moving star in the sky (~10.4″/yr) |
| WISE 0855-0714 | Coldest known brown dwarf, ~8.1″/yr, bright only near 4–5 µm |
| Epsilon Indi B | Binary brown dwarf, ~4.7″/yr |
| RW Aurigae | Young variable star (dimming events) |
| R Draconis | Mira variable (large pulsation amplitude) |

## Build it

From the repository root (uses the backend's virtual environment):

```bash
.venv/Scripts/python.exe -m pip install -r dataset/requirements.txt
.venv/Scripts/python.exe dataset/build_dataset.py
```

Options:

| Flag | Default | Meaning |
|---|---|---|
| `--targets` | `all` | Comma-separated ids from `targets.json` |
| `--size-arcmin` | `12` | Width of the stacked images (cutouts are downloaded 1.5× wider) |
| `--max-per-group` | `10` | Max exposures per (visit, detector). `0` downloads every exposure |
| `--workers` | `4` | Parallel downloads |
| `--no-catalogs` | off | Skip the Gaia DR3 / CatWISE2020 overlay catalogs |

Re-running is safe: cutouts already on disk are reused, and stacks, previews and indexes are rebuilt.
To add a target, add an entry to `targets.json`. To pick up a new SPHEREx data release, add its
SIA collection name to `COLLECTIONS` in `build_dataset.py`.

## What the builder does

1. **Astrometry.** Looks the target up in Gaia DR3 or CatWISE2020 (both at IRSA) to get an
   accurate position and proper motion, then predicts where the target is at any date.
   Parallax is ignored (under 1″, far below a 6.15″ SPHEREx pixel).
2. **Find images.** Queries IRSA SIA collections `spherex_dr1` and `spherex_qr3` for every
   Level-2 spectral image covering the target.
3. **Visits.** Groups exposures into survey visits (a new visit starts after a gap of more
   than 20 days). SPHEREx revisits each field roughly every 6 months.
4. **Cutouts.** Downloads a small cutout of each selected exposure through IRSA's cutout
   service. The large `EPSF` table is dropped to save space.
5. **Per-exposure measurements.** For every exposure: the target's pixel position on that
   date, the wavelength SPHEREx measured at that pixel (each SPHEREx pixel sees a different
   wavelength), the quality flags there, and aperture photometry. Together these points form
   the target's real spectrum.
6. **Stacks.** For each (visit, detector), the zodi-subtracted exposures are background-filtered,
   resampled onto one shared sky grid (north up, east left, 6.15″/px) and combined with
   inverse-variance weights. Flagged pixels are excluded. Because every visit uses the same grid,
   flipping between visits shows real motion.
7. **Catalogs.** Saves Gaia DR3 and CatWISE2020 sources in the field for overlays.
8. **Previews.** A PNG per stack (red ticks mark where the target is predicted), an animated
   blink GIF per detector, and a contact sheet with every visit and detector.

## Output layout

```
dataset/spherex/
├── manifest.json                 list of targets and their build status
└── <target_id>/
    ├── index.json                astrometry used, field centre, visits, stacks, file list
    ├── exposures.csv             one row per downloaded exposure (see columns below)
    ├── cutouts/<obs_id>_D<n>.fits    IRSA cutouts: IMAGE, FLAGS, VARIANCE, ZODI, WCS-WAVE
    ├── stacks/<visit>_D<n>.fits      stacked image: IMAGE, VARIANCE, NEXP (exposures per pixel)
    ├── previews/
    │   ├── <visit>_D<n>.png
    │   ├── blink_D<n>.gif
    │   └── contact_sheet.png
    └── catalogs/
        ├── gaia_dr3.csv
        └── catwise2020.csv
```

### `exposures.csv` columns

| Column | Meaning |
|---|---|
| `obs_id`, `collection` | SPHEREx exposure id and IRSA collection (DR1 preferred over QR3) |
| `visit_id`, `detector` | Visit label (`V01_2025-05-05`) and detector 1–6 |
| `date_obs`, `mjd` | Mid-exposure time (UTC / MJD) |
| `em_min_um`, `em_max_um` | Wavelength range of the whole detector |
| `wavelength_um`, `bandwidth_um` | Wavelength measured **at the target pixel** |
| `target_ra`, `target_dec`, `pixel_x`, `pixel_y` | Predicted target position on that date and in the cutout (0-based) |
| `flux_uJy`, `flux_err_uJy` | Aperture flux (2 px radius, local background annulus), µJy |
| `photometry_ok` | False if the target is off the cutout or any aperture pixel is flagged bad |
| `flags_at_target` | SPHEREx flag names set inside the aperture (e.g. `SOURCE`, `NONLINEAR`) |
| `cutout` | Relative path of the cutout file |

### Stack FITS headers

`MJD-AVG` (mean time), `NEXP` (exposures used), `WAVEMIN`/`WAVEMAX` (range of wavelengths at the
target among the stacked exposures), and `TARG_X`/`TARG_Y` (predicted target pixel, 0-based).

## Known limitations

- Aperture fluxes are **not aperture-corrected**. They are good for relative comparisons (spectral
  shape, variability), not absolute calibration.
- Very bright targets (Barnard's Star, R Draconis, RW Aurigae) can saturate SPHEREx. Saturated or
  non-linear pixels are flagged and excluded, so their photometry may be missing in some bands.
- Stacking one detector combines exposures at different wavelengths within that detector's range.
  That is intended (it raises signal-to-noise), but it means a stack is a broad-band image, not one channel.
- WISE 0855 is extremely faint below about 4 µm, so it is only expected in the D5/D6 stacks.
- `--max-per-group` limits downloads. Use `0` for the full set (slower, and much larger near the
  ecliptic poles, where SPHEREx observes almost continuously).

## Data credits

- SPHEREx data: NASA/JPL-Caltech, distributed by the NASA/IPAC Infrared Science Archive (IRSA).
- Gaia DR3: ESA/Gaia/DPAC, via IRSA.
- CatWISE2020: Marocco et al. 2021, via IRSA.
- Access patterns follow the IRSA SPHEREx tutorial notebooks (BSD-3-Clause).
