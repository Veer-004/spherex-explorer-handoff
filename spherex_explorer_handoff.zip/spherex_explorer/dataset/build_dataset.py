"""
Build a local dataset of real NASA SPHEREx observations for the challenge targets.

For each target this script:
  1. Resolves the target's position and proper motion from Gaia DR3 or CatWISE2020 (IRSA).
  2. Finds every SPHEREx Level-2 spectral image covering it (IRSA SIA, collections spherex_dr1 / spherex_qr3).
  3. Groups exposures into survey visits (SPHEREx revisits each field about every 6 months).
  4. Downloads small cutouts (IMAGE, FLAGS, VARIANCE, ZODI, WCS-WAVE; the large EPSF table is dropped).
  5. Measures the target in every exposure (wavelength at the target pixel + aperture flux) -> real spectrum points.
  6. Stacks exposures per (visit, detector) onto one common sky grid -> images for blink / difference viewing.
  7. Saves Gaia DR3 and CatWISE2020 sources in the field for overlays.
  8. Writes PNG previews, an animated blink GIF per detector and a contact sheet.

Usage (from the repository root):
    .venv/Scripts/python.exe dataset/build_dataset.py                  # all targets
    .venv/Scripts/python.exe dataset/build_dataset.py --targets wise_0855 --max-per-group 4
Re-running is safe: cutouts already on disk are reused.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import sys
import time
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import requests
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.time import Time
from astropy.wcs import WCS, FITSFixedWarning
import astropy.units as u
from PIL import Image, ImageDraw
from scipy.ndimage import map_coordinates, median_filter
from astropy import log as astropy_log

astropy_log.setLevel("ERROR")       # silence repeated SIP / long-card notices from SPHEREx headers
warnings.filterwarnings("ignore", category=FITSFixedWarning)
warnings.filterwarnings("ignore", message=".*SIP.*")
warnings.filterwarnings("ignore", category=UserWarning, module="astroquery")

HERE = Path(__file__).resolve().parent
DEFAULT_OUT = HERE / "spherex"
COLLECTIONS = ["spherex_dr1", "spherex_qr3"]
PIXEL_SCALE_ARCSEC = 6.15          # SPHEREx native pixel scale
MJD_J2000 = 51544.5
VISIT_GAP_DAYS = 20.0              # a new visit starts after a gap longer than this
MAX_VISIT_SPAN_DAYS = 45.0         # long continuous coverage (near the ecliptic poles) is split into chunks
KEEP_EXTENSIONS = ["IMAGE", "FLAGS", "VARIANCE", "ZODI", "WCS-WAVE"]

# Detector defects: always excluded.
DEFECT_FLAG_NAMES = ["NONFUNC", "MISSING_DATA", "HOT", "COLD", "OVERFLOW", "PERSIST"]
# Cosmic-ray style flags: excluded only where the pixel is NOT part of a real source
# (bright stars carry TRANSIENT/SUR_ERROR in their wings; masking those would erase the star).
TRANSIENT_FLAG_NAMES = ["TRANSIENT", "OUTLIER"]
# Any of these inside the photometry aperture means the target is saturated / non-linear.
SATURATION_FLAG_NAMES = ["OVERFLOW", "BLOOM", "NONLINEAR", "SUR_ERROR"]
FALLBACK_FLAG_BITS = {"TRANSIENT": 0, "OVERFLOW": 1, "SUR_ERROR": 2, "NONFUNC": 6, "DICHROIC": 7,
                      "MISSING_DATA": 9, "HOT": 10, "COLD": 11, "FULLSAMPLE": 12, "PHANMISS": 14,
                      "NONLINEAR": 15, "PERSIST": 17, "OUTLIER": 19, "CROSSTALK": 20, "SOURCE": 21,
                      "GHOST": 22, "GHOST_FPA": 23, "GHOST_EXT": 24, "STREAK": 25, "BLOOM": 26,
                      "SNOWBALL": 27, "HALO": 28}

# Photometry: small aperture + local background annulus (pixels). Fluxes are not aperture-corrected.
APER_R, ANN_R1, ANN_R2 = 2.0, 4.0, 7.0
BLEND_RADIUS_ARCSEC = 15.0         # a catalog star this close to the target contaminates its aperture/centroid
BLEND_MAG_LIMIT = 19.0             # ignore catalog neighbours fainter than this (Gaia G / WISE W1)
BLEND_DELTA_MAG = 3.0              # ...and neighbours more than this much fainter than the target in the same band
BKG_FILTER_PX = 15                # background median-filter width for stacks (pixels)
CUTOUT_PAD = 1.5                   # download cutouts this much wider than the stack so rotation leaves no gaps

SESSION = requests.Session()
SESSION.headers["User-Agent"] = "spherex-explorer-dataset-builder/1.0"


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


# --------------------------------------------------------------------------- astrometry

def position_at(ast: dict, mjd: float) -> tuple[float, float]:
    """Linear proper-motion propagation from the reference epoch (parallax ignored, < 1 pixel)."""
    dt_yr = (mjd - ast["ref_mjd"]) / 365.25
    dec = ast["dec"] + ast["pmdec_mas_yr"] * dt_yr / 3.6e6
    ra = ast["ra"] + ast["pmra_mas_yr"] * dt_yr / 3.6e6 / math.cos(math.radians(ast["dec"]))
    return ra % 360.0, dec


def resolve_astrometry(t: dict) -> dict:
    """Refine the target's position/proper motion from a catalog hosted at IRSA. Falls back to targets.json."""
    from astroquery.ipac.irsa import Irsa

    ref_mjd0 = Time(t.get("position_epoch_yr", 2000.0), format="jyear").mjd
    approx = {"ra": t["ra_j2000"], "dec": t["dec_j2000"], "pmra_mas_yr": t["pmra_mas_yr"],
              "pmdec_mas_yr": t["pmdec_mas_yr"], "ref_mjd": ref_mjd0}
    resolver = t.get("resolver", "gaia_dr3")
    if resolver == "none":                     # custom sky field: no catalog object to follow
        return {**approx, "source": "user coordinates"}
    cat_mjd = 57388.5 if resolver == "gaia_dr3" else 57170.0   # Gaia DR3 = J2016.0, CatWISE2020 = MJD 57170
    ra_p, dec_p = position_at(approx, cat_mjd)
    radius_deg = 25.0 / 3600.0
    try:
        if resolver == "gaia_dr3":
            q = (f"SELECT source_id, ra, dec, pmra, pmdec, parallax, phot_g_mean_mag FROM gaia_dr3_source "
                 f"WHERE CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra_p}, {dec_p}, {radius_deg}))=1")
            tab = Irsa.query_tap(q).to_table()
            tab = tab[~np.ma.getmaskarray(tab["pmra"])]
            if len(tab) == 0:
                raise RuntimeError("no Gaia match")
            pm = np.hypot(np.asarray(tab["pmra"], float), np.asarray(tab["pmdec"], float))
            i = int(np.argmax(pm)) if t["kind"] == "moving" else int(np.argmin(np.asarray(tab["phot_g_mean_mag"], float)))
            row = tab[i]
            return {"ra": float(row["ra"]), "dec": float(row["dec"]), "pmra_mas_yr": float(row["pmra"]),
                    "pmdec_mas_yr": float(row["pmdec"]), "ref_mjd": cat_mjd,
                    "source": f"Gaia DR3 {int(row['source_id'])}", "g_mag": float(row["phot_g_mean_mag"])}
        else:
            q = (f"SELECT source_name, ra, dec, pmra, pmdec, w1mpro, w2mpro FROM catwise_2020 "
                 f"WHERE CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra_p}, {dec_p}, {radius_deg}))=1")
            tab = Irsa.query_tap(q).to_table()
            if len(tab) == 0:
                raise RuntimeError("no CatWISE match")
            pm = np.hypot(np.asarray(tab["pmra"], float), np.asarray(tab["pmdec"], float))
            i = int(np.argmax(pm)) if t["kind"] == "moving" else int(np.argmin(np.asarray(tab["w2mpro"], float)))
            row = tab[i]
            # CatWISE2020 proper motions are in arcsec/yr
            return {"ra": float(row["ra"]), "dec": float(row["dec"]), "pmra_mas_yr": float(row["pmra"]) * 1000.0,
                    "pmdec_mas_yr": float(row["pmdec"]) * 1000.0, "ref_mjd": cat_mjd,
                    "source": f"CatWISE2020 {str(row['source_name']).strip()}",
                    "w1_mag": float(row["w1mpro"]), "w2_mag": float(row["w2mpro"])}
    except Exception as exc:  # network or catalog problems should not stop the build
        log(f"  astrometry lookup failed ({exc}); using targets.json values")
        return {**approx, "source": "targets.json (approximate)"}


# --------------------------------------------------------------------------- SPHEREx query

def query_spherex(ra: float, dec: float) -> list[dict]:
    from astroquery.ipac.irsa import Irsa

    for attempt in range(4):
        try:
            res = Irsa.query_sia(pos=(SkyCoord(ra, dec, unit="deg"), 2 * u.arcsec), collection=COLLECTIONS)
            break
        except Exception as exc:
            if attempt == 3:
                raise
            log(f"  SIA query failed ({exc}); retrying")
            time.sleep(10 * (attempt + 1))
    rows = []
    for r in res:
        if str(r["dataproduct_subtype"]).strip() != "science":
            continue
        band = str(r["energy_bandpassname"]).strip()
        rows.append({
            "obs_id": str(r["obs_id"]).strip(),
            "collection": str(r["obs_collection"]).strip(),
            "detector": int(band.split("D")[-1]),
            "t_min": float(r["t_min"]),
            "t_max": float(r["t_max"]),
            "exptime_s": float(r["t_exptime"]),
            "em_min_um": float(r["em_min"]) * 1e6,
            "em_max_um": float(r["em_max"]) * 1e6,
            "access_url": str(r["access_url"]).strip(),
        })
    # The same exposure can appear in more than one release; keep the newest (DR1 over QR3).
    best: dict[tuple, dict] = {}
    for r in rows:
        key = (r["obs_id"], r["detector"])
        if key not in best or (r["collection"] == "spherex_dr1" and best[key]["collection"] != "spherex_dr1"):
            best[key] = r
    return sorted(best.values(), key=lambda r: (r["t_min"], r["detector"]))


def assign_visits(rows: list[dict]) -> list[dict]:
    """Cluster exposure times into visits, splitting long continuous coverage into chunks."""
    times = sorted({r["t_min"] for r in rows})
    clusters: list[list[float]] = []
    for tm in times:
        if clusters and tm - clusters[-1][-1] <= VISIT_GAP_DAYS and tm - clusters[-1][0] <= MAX_VISIT_SPAN_DAYS:
            clusters[-1].append(tm)
        else:
            clusters.append([tm])
    visits = []
    lookup = {}
    for i, c in enumerate(clusters, start=1):
        start, end = Time(c[0], format="mjd"), Time(c[-1], format="mjd")
        vid = f"V{i:02d}_{start.datetime.strftime('%Y-%m-%d')}"
        visits.append({"visit_id": vid, "mjd_start": c[0], "mjd_end": c[-1],
                       "date_start": start.isot[:19] + "Z", "date_end": end.isot[:19] + "Z"})
        for tm in c:
            lookup[tm] = vid
    for r in rows:
        r["visit_id"] = lookup[r["t_min"]]
    return visits


def select_exposures(rows: list[dict], max_per_group: int) -> list[dict]:
    if max_per_group <= 0:
        return rows
    groups: dict[tuple, list[dict]] = {}
    for r in rows:
        groups.setdefault((r["visit_id"], r["detector"]), []).append(r)
    keep = []
    for g in groups.values():
        if len(g) <= max_per_group:
            keep.extend(g)
        else:
            idx = np.unique(np.linspace(0, len(g) - 1, max_per_group).round().astype(int))
            keep.extend(g[i] for i in idx)
    return sorted(keep, key=lambda r: (r["t_min"], r["detector"]))


# --------------------------------------------------------------------------- downloads

def cutout_path(cut_dir: Path, r: dict) -> Path:
    return cut_dir / f"{r['obs_id']}_D{r['detector']}.fits"


def download_cutout(r: dict, ra: float, dec: float, size_deg: float, dest: Path) -> tuple[bool, str]:
    if dest.exists() and dest.stat().st_size > 2880:
        return True, "cached"
    url = f"{r['access_url']}?center={ra:.6f},{dec:.6f}d&size={size_deg:.4f}"
    last = ""
    for attempt in range(5):
        try:
            resp = SESSION.get(url, timeout=180)
            if resp.status_code == 200 and resp.content[:6] == b"SIMPLE":
                with fits.open(io.BytesIO(resp.content)) as hdul:
                    out = fits.HDUList([fits.PrimaryHDU(header=hdul[0].header)])
                    for name in KEEP_EXTENSIONS:
                        if name in hdul:
                            out.append(hdul[name].copy())
                    out[0].header["OBS_ID"] = r["obs_id"]
                    out[0].header["SRCFILE"] = r["access_url"].rsplit("/", 1)[-1][:68]
                    tmp = dest.with_suffix(".part")
                    out.writeto(tmp, overwrite=True)
                    tmp.replace(dest)
                return True, "downloaded"
            last = f"HTTP {resp.status_code}, {len(resp.content)} bytes"
        except Exception as exc:
            last = str(exc)
        time.sleep(5 * (attempt + 1))
    return False, last


# --------------------------------------------------------------------------- measurement

def flag_bits(header) -> dict[str, int]:
    bits = {}
    for key in header.keys():
        if key.startswith("MSKN"):
            try:
                bits[str(header[key]).strip()] = int(key[4:])
            except ValueError:
                pass
    return bits or dict(FALLBACK_FLAG_BITS)


def mask_value(bits: dict[str, int], names: list[str]) -> int:
    m = 0
    for name in names:
        if name in bits:
            m |= 1 << bits[name]
    return m


def bad_pixels(img: np.ndarray, flags: np.ndarray, bits: dict[str, int]) -> np.ndarray:
    """True where a pixel should not be used: NaN, detector defect, or a cosmic ray outside real sources."""
    defect = (flags & mask_value(bits, DEFECT_FLAG_NAMES)) != 0
    transient = (flags & mask_value(bits, TRANSIENT_FLAG_NAMES)) != 0
    source = (flags & mask_value(bits, ["SOURCE"])) != 0
    return ~np.isfinite(img) | defect | (transient & ~source)


def load_neighbours(tdir: Path, ast: dict) -> list[dict]:
    """Catalog stars that could blend with the target (the target's own catalog entries are excluded)."""
    out = []
    specs = [("gaia_dr3.csv", "phot_g_mean_mag", "g_mag", 57388.5, 1.0, "source_id"),
             ("catwise2020.csv", "w1mpro", "w1_mag", 57170.0, 1000.0, "source_name")]
    for fname, magcol, target_band, ref_mjd, pm_scale, idcol in specs:
        path = tdir / "catalogs" / fname
        if not path.exists():
            continue
        t_ra, t_dec = position_at(ast, ref_mjd)          # where the target was at this catalog's epoch
        # Same band if known, otherwise the other band as a rough proxy (keeps faint field stars from
        # being flagged around very bright targets such as Barnard's Star)
        target_mag = ast.get(target_band, ast.get("g_mag", ast.get("w1_mag")))
        with open(path, newline="") as fh:
            for row in csv.DictReader(fh):
                try:
                    ra, dec, mag = float(row["ra"]), float(row["dec"]), float(row[magcol])
                except (TypeError, ValueError, KeyError):
                    continue
                sep0 = math.hypot((ra - t_ra) * math.cos(math.radians(dec)), dec - t_dec) * 3600
                if sep0 < 3.0:                            # this is the target itself
                    continue
                if mag > BLEND_MAG_LIMIT or (target_mag is not None and mag > target_mag + BLEND_DELTA_MAG):
                    continue
                pmra = float(row["pmra"]) * pm_scale if row.get("pmra") not in ("", None) else 0.0
                pmdec = float(row["pmdec"]) * pm_scale if row.get("pmdec") not in ("", None) else 0.0
                # Duplicate catalog entries of a fast mover share its proper motion: that's the target too
                if (math.hypot(ast["pmra_mas_yr"], ast["pmdec_mas_yr"]) > 500 and sep0 < 20.0
                        and math.hypot(pmra - ast["pmra_mas_yr"], pmdec - ast["pmdec_mas_yr"]) < 1000):
                    continue
                out.append({"ra": ra, "dec": dec, "pmra_mas_yr": pmra, "pmdec_mas_yr": pmdec, "ref_mjd": ref_mjd,
                            "mag": mag, "id": f"{fname.split('.')[0]}:{str(row.get(idcol, '')).strip()}"})
    return out


def nearest_neighbour(neighbours: list[dict], ra: float, dec: float, mjd: float):
    best = None
    for n in neighbours:
        nra, ndec = position_at(n, mjd)
        sep = math.hypot((nra - ra) * math.cos(math.radians(dec)), ndec - dec) * 3600
        if best is None or sep < best[0]:
            best = (sep, n)
    return best


def measure_exposure(path: Path, r: dict, ast: dict, neighbours: list[dict] | None = None) -> dict:
    """Wavelength at the target pixel, flags there, blending, measured position and aperture photometry."""
    with fits.open(path) as h:
        img_h = h["IMAGE"].header
        img = h["IMAGE"].data.astype(np.float64)
        zodi = h["ZODI"].data.astype(np.float64) if "ZODI" in h else 0.0
        var = h["VARIANCE"].data.astype(np.float64)
        flags = h["FLAGS"].data.astype(np.int64)
        bits = flag_bits(h["FLAGS"].header)
        mjd = float(img_h.get("MJD-AVG", r["t_min"]))
        ra_t, dec_t = position_at(ast, mjd)
        w = WCS(img_h)
        x, y = (float(v) for v in w.all_world2pix([[ra_t, dec_t]], 0)[0])
        wl_um = bw_um = float("nan")
        try:
            sw = WCS(header=img_h, fobj=h, key="W")
            sw.sip = None
            wl, bw = sw.pixel_to_world(x, y)
            wl_um, bw_um = float(wl.to(u.um).value), float(bw.to(u.um).value)
        except Exception:
            pass

    ny, nx = img.shape
    out = {"mjd": round(mjd, 6), "target_ra": round(ra_t, 7), "target_dec": round(dec_t, 7),
           "pixel_x": round(x, 2), "pixel_y": round(y, 2), "wavelength_um": round(wl_um, 5),
           "bandwidth_um": round(bw_um, 5), "flux_uJy": "", "flux_err_uJy": "", "flags_at_target": "",
           "saturated": False, "photometry_ok": False, "centroid_ra": "", "centroid_dec": "",
           "centroid_offset_arcsec": "", "peak_snr": "", "centroid_ok": False,
           "blended": False, "neighbour_sep_arcsec": "", "neighbour_id": "", "neighbour_mag": ""}
    nb = nearest_neighbour(neighbours or [], ra_t, dec_t, mjd)
    if nb and nb[0] < BLEND_RADIUS_ARCSEC:
        out.update({"blended": True, "neighbour_sep_arcsec": round(nb[0], 2), "neighbour_id": nb[1]["id"],
                    "neighbour_mag": round(nb[1]["mag"], 2)})
    if not (ANN_R2 <= x < nx - ANN_R2 and ANN_R2 <= y < ny - ANN_R2):
        out["flags_at_target"] = "OFF_IMAGE"
        return out

    yy, xx = np.mgrid[0:ny, 0:nx]
    rr = np.hypot(xx - x, yy - y)
    aper = rr <= APER_R
    ann = (rr >= ANN_R1) & (rr <= ANN_R2)
    bad = bad_pixels(img, flags, bits)
    names = sorted({n for n, b in bits.items() if np.any(flags[aper] & (1 << b))})
    out["flags_at_target"] = "|".join(names)
    out["saturated"] = bool(np.any(flags[aper] & mask_value(bits, SATURATION_FLAG_NAMES)))

    sky = img - zodi
    good_ann = ann & ~bad & np.isfinite(sky)
    if good_ann.sum() < 8:
        return out
    bkg = float(np.median(sky[good_ann]))
    bkg_sig = float(1.4826 * np.median(np.abs(sky[good_ann] - bkg)))

    # Measured position: flux-weighted centroid of usable pixels within 3 px of the prediction.
    # Saturated cores are NaN but the wings are recorded, so bright stars still centroid well.
    box = (rr <= 3.0) & ~bad & np.isfinite(sky)
    vals = np.where(box, sky - bkg, 0.0)
    peak = float(vals.max()) if box.any() else 0.0
    snr = peak / bkg_sig if bkg_sig > 0 else 0.0
    out["peak_snr"] = round(snr, 1)
    if box.sum() >= 5 and snr >= 5.0:
        wts = np.clip(vals, 0, None)
        cx = float((wts * xx).sum() / wts.sum())
        cy = float((wts * yy).sum() / wts.sum())
        cra, cdec = (float(v) for v in w.all_pix2world([[cx, cy]], 0)[0])
        off = SkyCoord(cra, cdec, unit="deg").separation(SkyCoord(ra_t, dec_t, unit="deg")).arcsec
        out.update({"centroid_ra": round(cra, 7), "centroid_dec": round(cdec, 7),
                    "centroid_offset_arcsec": round(float(off), 2), "centroid_ok": True})

    if out["saturated"] or np.any(bad[aper]) or not np.all(np.isfinite(sky[aper])):
        return out
    n_ap = int(aper.sum())
    flux = float(np.sum(sky[aper] - bkg))
    err = float(np.sqrt(np.sum(var[aper]) + n_ap * bkg_sig ** 2 * (1 + n_ap / good_ann.sum())))
    pix_sr = float(np.abs(np.linalg.det(WCS(img_h).pixel_scale_matrix))) * (math.pi / 180.0) ** 2
    to_uJy = pix_sr * 1e12        # MJy/sr * sr -> MJy -> uJy
    out.update({"flux_uJy": round(flux * to_uJy, 3), "flux_err_uJy": round(err * to_uJy, 3), "photometry_ok": True})
    return out


# --------------------------------------------------------------------------- stacking

def common_grid(ra: float, dec: float, npix: int) -> WCS:
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [ra, dec]
    w.wcs.crpix = [(npix + 1) / 2.0, (npix + 1) / 2.0]
    s = PIXEL_SCALE_ARCSEC / 3600.0
    w.wcs.cdelt = [-s, s]
    w.wcs.cunit = ["deg", "deg"]
    return w


def resample_onto(path: Path, grid: WCS, npix: int):
    """Return (zodi-subtracted, background-levelled data, weight) on the common grid."""
    with fits.open(path) as h:
        hdr = h["IMAGE"].header
        img = h["IMAGE"].data.astype(np.float64)
        zodi = h["ZODI"].data.astype(np.float64) if "ZODI" in h else 0.0
        var = h["VARIANCE"].data.astype(np.float64)
        flags = h["FLAGS"].data.astype(np.int64)
        bad = bad_pixels(img, flags, flag_bits(h["FLAGS"].header))
    sky = img - zodi
    good = ~bad & np.isfinite(sky) & np.isfinite(var) & (var > 0)
    if good.sum() < 50:
        return None
    # Remove residual background (zodi model errors, stray light gradients) with a wide median filter;
    # point sources (~1-2 px) survive, so stacks and differences line up between visits.
    filled = np.where(good, sky, np.median(sky[good]))
    sky = sky - median_filter(filled, size=BKG_FILTER_PX, mode="nearest")
    wgt = np.where(good, 1.0 / np.where(good, var, 1.0), 0.0)
    data = np.where(good, sky, 0.0)
    yy, xx = np.mgrid[0:npix, 0:npix]
    ra, dec = grid.all_pix2world(xx.ravel(), yy.ravel(), 0)
    sx, sy = WCS(hdr).all_world2pix(ra, dec, 0)
    coords = np.vstack([sy, sx])
    wd = map_coordinates(data * wgt, coords, order=1, mode="constant", cval=0.0).reshape(npix, npix)
    ww = map_coordinates(wgt, coords, order=1, mode="constant", cval=0.0).reshape(npix, npix)
    return wd, ww


def build_stack(paths: list[Path], grid: WCS, npix: int):
    swd = np.zeros((npix, npix))
    sw = np.zeros((npix, npix))
    nexp = np.zeros((npix, npix), dtype=np.int16)
    used = 0
    for p in paths:
        res = resample_onto(p, grid, npix)
        if res is None:
            continue
        wd, ww = res
        swd += wd
        sw += ww
        nexp += (ww > 0).astype(np.int16)
        used += 1
    with np.errstate(invalid="ignore", divide="ignore"):
        img = np.where(sw > 0, swd / sw, np.nan)
        var = np.where(sw > 0, 1.0 / sw, np.nan)
    return img.astype(np.float32), var.astype(np.float32), nexp, used


# --------------------------------------------------------------------------- previews

def to_png_array(img: np.ndarray, lo: float, hi: float) -> np.ndarray:
    a = np.nan_to_num(img, nan=lo)
    n = np.clip((a - lo) / max(hi - lo, 1e-12), 0, 1)
    n = np.arcsinh(n / 0.1) / np.arcsinh(1 / 0.1)
    return (n * 255).astype(np.uint8)[::-1]        # flip so North is up


def write_previews(tdir: Path, stacks: dict, visits: list[dict], marks: dict) -> None:
    prev = tdir / "previews"
    prev.mkdir(exist_ok=True)
    dets = sorted({d for (_, d) in stacks})
    tiles = {}
    for det in dets:
        imgs = [stacks[(v["visit_id"], det)] for v in visits if (v["visit_id"], det) in stacks]
        vals = np.concatenate([i[np.isfinite(i)].ravel() for i in imgs]) if imgs else np.array([0.0])
        lo, hi = np.percentile(vals, 1.0), np.percentile(vals, 99.7)
        frames = []
        for v in visits:
            key = (v["visit_id"], det)
            if key not in stacks:
                continue
            arr = to_png_array(stacks[key], lo, hi)
            im = Image.fromarray(arr).convert("RGB").resize((arr.shape[1] * 3, arr.shape[0] * 3), Image.NEAREST)
            d = ImageDraw.Draw(im)
            mx, my = marks[key]
            px, py = mx * 3 + 1.5, (arr.shape[0] - 1 - my) * 3 + 1.5
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):   # tick marks around the predicted position
                d.line([(px + dx * 9, py + dy * 9), (px + dx * 16, py + dy * 16)], fill=(255, 80, 80), width=2)
            d.text((6, 6), f"D{det}  {v['date_start'][:10]}", fill=(255, 255, 120))
            im.save(prev / f"{v['visit_id']}_D{det}.png")
            frames.append(im)
            tiles[key] = im
        if len(frames) >= 2:
            frames[0].save(prev / f"blink_D{det}.gif", save_all=True, append_images=frames[1:], duration=700, loop=0)
    if tiles:
        tw, th = next(iter(tiles.values())).size
        sheet = Image.new("RGB", (tw * len(visits), th * len(dets)), (20, 20, 20))
        for r_i, det in enumerate(dets):
            for c_i, v in enumerate(visits):
                if (v["visit_id"], det) in tiles:
                    sheet.paste(tiles[(v["visit_id"], det)], (c_i * tw, r_i * th))
        sheet.save(prev / "contact_sheet.png")


# --------------------------------------------------------------------------- catalogs

def save_catalogs(tdir: Path, ra: float, dec: float, radius_deg: float) -> dict:
    from astroquery.ipac.irsa import Irsa

    out = {}
    cdir = tdir / "catalogs"
    cdir.mkdir(exist_ok=True)
    queries = {
        "gaia_dr3": ("SELECT source_id, ra, dec, pmra, pmdec, parallax, phot_g_mean_mag, phot_bp_mean_mag, "
                     "phot_rp_mean_mag FROM gaia_dr3_source"),
        "catwise2020": "SELECT source_name, ra, dec, pmra, pmdec, w1mpro, w2mpro FROM catwise_2020",
    }
    for name, base in queries.items():
        path = cdir / f"{name}.csv"
        if path.exists():
            out[name] = str(path.relative_to(tdir)).replace("\\", "/")
            continue
        q = f"{base} WHERE CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra}, {dec}, {radius_deg}))=1"
        try:
            tab = Irsa.query_tap(q).to_table()
            tab.write(path, format="ascii.csv", overwrite=True)
            out[name] = str(path.relative_to(tdir)).replace("\\", "/")
            log(f"  {name}: {len(tab)} sources")
        except Exception as exc:
            log(f"  {name} query failed: {exc}")
    return out


# --------------------------------------------------------------------------- main per target

def build_target(t: dict, out_root: Path, size_arcmin: float, max_per_group: int, workers: int,
                 catalogs: bool) -> dict:
    log(f"=== {t['name']} ({t['id']})")
    tdir = out_root / t["id"]
    cut_dir = tdir / "cutouts"
    (tdir / "stacks").mkdir(parents=True, exist_ok=True)
    cut_dir.mkdir(parents=True, exist_ok=True)

    ast = resolve_astrometry(t)
    log(f"  astrometry from {ast['source']}: pm = ({ast['pmra_mas_yr']:.1f}, {ast['pmdec_mas_yr']:.1f}) mas/yr")

    # Field centre: the target's position in the middle of the SPHEREx survey so far.
    ra_mid, dec_mid = position_at(ast, 61000.0)
    rows = query_spherex(ra_mid, dec_mid)
    if not rows:
        log("  no SPHEREx images found")
        return {"id": t["id"], "name": t["name"], "status": "no_data"}
    visits = assign_visits(rows)
    sel = select_exposures(rows, max_per_group)
    log(f"  {len(rows)} SPHEREx images in {len(visits)} visits; downloading {len(sel)} cutouts")

    size_deg = size_arcmin / 60.0 * CUTOUT_PAD
    done = 0
    failed = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futs = {pool.submit(download_cutout, r, ra_mid, dec_mid, size_deg, cutout_path(cut_dir, r)): r for r in sel}
        for f in as_completed(futs):
            ok, msg = f.result()
            done += 1
            if not ok:
                failed.append(futs[f]["obs_id"])
                log(f"  failed {futs[f]['obs_id']} D{futs[f]['detector']}: {msg}")
            if done % 25 == 0 or done == len(sel):
                log(f"  cutouts {done}/{len(sel)}")

    # Catalogs first: they are needed to flag exposures where a neighbouring star blends with the target
    cats = save_catalogs(tdir, ra_mid, dec_mid, size_arcmin / 60.0 / 2 * 1.45) if catalogs else {}
    neighbours = load_neighbours(tdir, ast) if t.get("kind") != "field" else []

    # Measure every exposure
    exposures = []
    for r in sel:
        p = cutout_path(cut_dir, r)
        if not p.exists():
            continue
        try:
            m = measure_exposure(p, r, ast, neighbours)
        except Exception as exc:
            log(f"  could not measure {p.name}: {exc}")
            continue
        exposures.append({**{k: r[k] for k in ("obs_id", "collection", "visit_id", "detector", "exptime_s",
                                                "em_min_um", "em_max_um")},
                          "date_obs": Time(m["mjd"], format="mjd").isot[:23] + "Z", **m,
                          "cutout": str(p.relative_to(tdir)).replace("\\", "/")})

    fields = ["obs_id", "collection", "visit_id", "detector", "date_obs", "mjd", "exptime_s", "em_min_um",
              "em_max_um", "wavelength_um", "bandwidth_um", "target_ra", "target_dec", "pixel_x", "pixel_y",
              "flux_uJy", "flux_err_uJy", "saturated", "photometry_ok", "centroid_ra", "centroid_dec",
              "centroid_offset_arcsec", "peak_snr", "centroid_ok", "blended", "neighbour_sep_arcsec",
              "neighbour_id", "neighbour_mag", "flags_at_target", "cutout"]
    with open(tdir / "exposures.csv", "w", newline="") as fh:
        wr = csv.DictWriter(fh, fieldnames=fields)
        wr.writeheader()
        for e in sorted(exposures, key=lambda e: e["mjd"]):
            wr.writerow({k: e[k] for k in fields})

    # Stack per (visit, detector) on one fixed grid so motion shows as a shift between visits
    npix = int(round(size_arcmin * 60 / PIXEL_SCALE_ARCSEC)) - 4
    npix += (npix + 1) % 2                      # odd size -> the field centre is a pixel centre
    grid = common_grid(ra_mid, dec_mid, npix)
    stacks, marks, stack_meta = {}, {}, []
    groups: dict[tuple, list[dict]] = {}
    for e in exposures:
        groups.setdefault((e["visit_id"], e["detector"]), []).append(e)
    for (vid, det), es in sorted(groups.items()):
        img, var, nexp, used = build_stack([tdir / e["cutout"] for e in es], grid, npix)
        if used == 0:
            continue
        mjd_avg = float(np.mean([e["mjd"] for e in es]))
        ra_t, dec_t = position_at(ast, mjd_avg)
        tx, ty = (float(v) for v in grid.all_world2pix([[ra_t, dec_t]], 0)[0])
        wls = [e["wavelength_um"] for e in es if not math.isnan(e["wavelength_um"])]
        hdr = grid.to_header()
        hdr["BUNIT"] = "MJy/sr"
        hdr["TELESCOP"] = "SPHEREx"
        hdr["DETECTOR"] = det
        hdr["VISIT"] = vid
        hdr["MJD-AVG"] = mjd_avg
        hdr["NEXP"] = used
        hdr["WAVEMIN"] = (min(wls) if wls else -1.0, "[um] min wavelength at target among stacked exposures")
        hdr["WAVEMAX"] = (max(wls) if wls else -1.0, "[um] max wavelength at target among stacked exposures")
        hdr["TARG_X"] = (tx, "0-based predicted target pixel x")
        hdr["TARG_Y"] = (ty, "0-based predicted target pixel y")
        hdr["COMMENT"] = "Inverse-variance stack of zodi-subtracted SPHEREx L2 cutouts (bad pixels masked)."
        name = f"{vid}_D{det}.fits"
        fits.HDUList([fits.PrimaryHDU(), fits.ImageHDU(img, hdr, name="IMAGE"),
                      fits.ImageHDU(var, hdr, name="VARIANCE"),
                      fits.ImageHDU(nexp, hdr, name="NEXP")]).writeto(tdir / "stacks" / name, overwrite=True)
        stacks[(vid, det)] = img
        marks[(vid, det)] = (tx, ty)
        stack_meta.append({"visit_id": vid, "detector": det, "file": f"stacks/{name}", "n_exposures": used,
                           "mjd_avg": round(mjd_avg, 5), "date_avg": Time(mjd_avg, format="mjd").isot[:19] + "Z",
                           "wavelength_min_um": round(min(wls), 4) if wls else None,
                           "wavelength_max_um": round(max(wls), 4) if wls else None,
                           "target_pixel": [round(tx, 2), round(ty, 2)],
                           "target_radec": [round(ra_t, 7), round(dec_t, 7)]})
    log(f"  built {len(stack_meta)} stacks ({npix}x{npix} px)")

    visits_used = [v for v in visits if any(s["visit_id"] == v["visit_id"] for s in stack_meta)]
    write_previews(tdir, stacks, visits_used, marks)

    n_phot = sum(1 for e in exposures if e["photometry_ok"])
    index = {
        "id": t["id"], "name": t["name"], "kind": t["kind"],
        "built_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "collections_queried": COLLECTIONS,
        "astrometry": ast,
        "field_center": {"ra": round(ra_mid, 7), "dec": round(dec_mid, 7), "epoch_mjd": 61000.0},
        "cutout_size_arcmin": round(size_arcmin * CUTOUT_PAD, 2),
        "stack_size_arcmin": size_arcmin,
        "stack_grid": {"npix": npix, "pixel_scale_arcsec": PIXEL_SCALE_ARCSEC, "wcs": "RA---TAN/DEC--TAN"},
        "images_available": len(rows), "images_downloaded": len(exposures), "failed_downloads": failed,
        "photometry_points": n_phot,
        "visits": [{**v, "n_images_available": sum(1 for r in rows if r["visit_id"] == v["visit_id"])} for v in visits],
        "stacks": stack_meta,
        "files": {"exposures": "exposures.csv", "previews": "previews/", "catalogs": cats},
    }
    (tdir / "index.json").write_text(json.dumps(index, indent=2))
    log(f"  done: {len(exposures)} exposures, {n_phot} photometry points, {len(stack_meta)} stacks")
    return {"id": t["id"], "name": t["name"], "status": "ok", "index": f"{t['id']}/index.json",
            "visits": len(visits_used), "stacks": len(stack_meta), "exposures": len(exposures)}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--targets", default="all", help="comma-separated target ids from targets.json, or 'all'")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    ap.add_argument("--size-arcmin", type=float, default=12.0, help="cutout width (default 12')")
    ap.add_argument("--max-per-group", type=int, default=10,
                    help="max exposures per (visit, detector); 0 = download everything")
    ap.add_argument("--workers", type=int, default=4, help="parallel downloads (be gentle with IRSA)")
    ap.add_argument("--no-catalogs", action="store_true", help="skip Gaia/CatWISE overlay catalogs")
    args = ap.parse_args()

    cfg = json.loads((HERE / "targets.json").read_text())["targets"]
    wanted = [t for t in cfg if args.targets == "all" or t["id"] in args.targets.split(",")]
    if not wanted:
        print("No matching targets", file=sys.stderr)
        return 1
    out_root = Path(args.out)
    out_root.mkdir(parents=True, exist_ok=True)

    manifest_path = out_root / "manifest.json"
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {"targets": {}}
    for t in wanted:
        try:
            manifest["targets"][t["id"]] = build_target(t, out_root, args.size_arcmin, args.max_per_group,
                                                        args.workers, not args.no_catalogs)
        except Exception as exc:
            log(f"  FAILED {t['id']}: {exc}")
            manifest["targets"][t["id"]] = {"id": t["id"], "name": t["name"], "status": f"error: {exc}"}
        manifest.update({"dataset": "SPHEREx Explorer benchmark dataset",
                         "source": "NASA/IPAC Infrared Science Archive (IRSA), SPHEREx Level-2 spectral images",
                         "collections": COLLECTIONS, "updated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")})
        manifest_path.write_text(json.dumps(manifest, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
