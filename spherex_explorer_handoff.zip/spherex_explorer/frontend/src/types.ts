export interface Coordinates {
  ra_deg: number;
  dec_deg: number;
  ra_sexagesimal: string;
  dec_sexagesimal: string;
  epoch?: string;
}

export interface EpochData {
  epoch_id: string;
  obs_date: string;
  mjd: number;
  delta_pos_arcsec: [number, number];
  /** Brightness change of this visit vs. the median (mag), null when not measurable (e.g. saturated). */
  flux_mjy: number | null;
  quality_flag: number;
  n_images?: number;
}

export interface Target {
  id: string;
  name: string;
  designations: string[];
  classification: string;
  description: string;
  coordinates: Coordinates;
  distance_ly?: number;
  proper_motion: {
    pm_ra_mas_yr: number;
    pm_dec_mas_yr: number;
    total_pm_arcsec_yr: number;
    motion_type: string;
  };
  category: 'moving' | 'variable' | 'field';
  fov_arcmin: number;
  max_fov_arcmin?: number;
  default_detector: string;
  default_channel: number;
  available_detectors?: string[];
  epochs: EpochData[];
  spectral_signature: string;
  astrometry_source?: string;
  images_available?: number;
  images_downloaded?: number;
  built_utc?: string;
  is_custom?: boolean;
}

export interface FitsCard {
  key: string;
  val: string;
  comment: string;
}

export interface MotionFit {
  pm_ra_arcsec_yr: number;
  pm_dec_arcsec_yr: number;
  pm_total_arcsec_yr: number;
  pm_error_arcsec_yr: number;
  significance_sigma: number | null;
  n_points: number;
  n_rejected: number;
  rms_arcsec: number;
  baseline_yr: number;
  catalog_pm_arcsec_yr: number;
  catalog_source: string;
}

export interface TrackPoint {
  x: number;
  y: number;
  epoch: string;
  visit_id?: string;
  ra?: number;
  dec?: number;
  n?: number;
}

export interface CatalogSource {
  ra: number;
  dec: number;
  x: number;
  y: number;
  pm_total_mas_yr: number;
  mag: number | null;
  id: string;
}

export interface CatalogResponse {
  source: string;
  available: boolean;
  epoch_mjd?: number;
  sources: CatalogSource[];
}

export interface MlCandidate {
  candidate_id: string;
  p_mover: number;
  flagged: boolean;
  scored: boolean;
  in_view: boolean;
  ra_deg: number;
  dec_deg: number;
  ra_sexagesimal: string;
  dec_sexagesimal: string;
  pixel_x: number;
  pixel_y: number;
  pm_fit_arcsec_yr: number | null;
  pm_err_arcsec_yr: number | null;
  pm_sig: number | null;
  snr_deep: number | null;
  n_visits_detected: number;
  gaia_pm_arcsec_yr: number | null;
  gaia_g: number | null;
  track: TrackPoint[];
}

export interface MoverModelInfo {
  available: boolean;
  message?: string;
  threshold?: number;
  min_visits?: number;
  target_false_alarm_rate?: number;
  recall_injected_movers?: number;
  rule_recall_injected_movers?: number;
  false_alarm_rate_real_stars?: number;
  n_real_stars_tested?: number;
  motion_range_arcsec_yr?: [number, number];
}

export interface MoversResponse {
  target_id: string;
  model: MoverModelInfo;
  n_sources: number;
  n_scored: number;
  n_flagged: number;
  expected_false_alarms: number;
  candidates: MlCandidate[];
}

export interface BuildStatus {
  field_id: string;
  state: 'queued' | 'running' | 'done' | 'error' | 'unknown';
  message?: string;
}

export interface ObservationMetadata {
  telescope: string;
  instrument: string;
  data_release: string;
  channel: number;
  detector: string;
  wavelength_um: number;
  fov_arcmin: number;
  pixel_scale_arcsec: number;
  dimensions: [number, number];
  center_coordinates: { ra: number; dec: number };
  background_flux_mjy_sr: number;
  peak_flux: number;
  mean_flux: number;
  rms_noise: number;
  wavelength_min_um?: number | null;
  wavelength_max_um?: number | null;
  n_exposures?: number;
  quality_flags: {
    zodiacal_subtracted: boolean;
    cosmic_ray_masked: boolean;
    saturation_detected: boolean;
    stray_light_fraction: number;
  };
  fits_header?: FitsCard[];
}

export interface ObservationEpoch {
  epoch_index: number;
  epoch_id: string;
  obs_date: string;
  mjd: number;
  image_url: string;
  flux_mjy: number | null;
  quality_flag: number;
  n_exposures?: number;
  metadata: ObservationMetadata;
}

export interface DetectedCandidate {
  candidate_id: string;
  type: 'moving_object' | 'variable_source' | 'stationary';
  classification: string;
  ra_deg: number;
  dec_deg: number;
  ra_sexagesimal: string;
  dec_sexagesimal: string;
  pixel_x: number;
  pixel_y: number;
  angular_displacement_arcsec: number;
  confidence_score: number;
  snr: number;
  epochs_detected: number;
  status: string;
  motion?: MotionFit | null;
  brightness_change_mag?: number;
  blend?: BlendInfo | null;
  track?: TrackPoint[];
}

export interface BlendInfo {
  fraction: number;
  n_blended: number;
  n_total: number;
  min_sep_arcsec: number | null;
  max_sep_arcsec: number | null;
  neighbour: string;
  neighbour_mag: number | null;
  band: string;
  message: string;
}

export interface ObservationsResponse {
  target_id?: string;
  target_name: string;
  ra_deg: number;
  dec_deg: number;
  fov_arcmin: number;
  channel: number;
  detector: string;
  wavelength_um: number;
  available_detectors?: string[];
  total_epochs: number;
  observations: ObservationEpoch[];
  detected_candidates: DetectedCandidate[];
  data_source?: string;
}

export interface SpectralChannel {
  channel: number;
  detector: string;
  wavelength_um: number;
  bandwidth_um: number;
  resolving_power: number;
  flux_mjy: number | null;
  flux_err_mjy: number | null;
  snr: number | null;
  is_valid: boolean;
  status_flag: string;
  n_measurements?: number;
}

export interface SpectrumPoint {
  wavelength_um: number;
  flux_mjy: number;
  flux_err_mjy: number;
  detector: string;
  visit_id: string;
  blended?: boolean;
}

export interface ReferenceFeature {
  name: string;
  wavelength_um: number;
  type: 'absorption' | 'emission';
  significance: string;
}

export interface SpectrumResponse {
  target_id?: string;
  target_name: string;
  spectral_signature: string;
  total_channels: number;
  valid_channels_count: number;
  peak_flux_mjy: number;
  min_flux_mjy: number;
  mean_flux_mjy: number;
  channels: SpectralChannel[];
  points?: SpectrumPoint[];
  n_saturated?: number;
  n_blended_channels?: number;
  blend_warning?: string | null;
  n_exposures?: number;
  note?: string;
  reference_features: ReferenceFeature[];
}

export interface DifferenceResponse {
  epoch1_index: number;
  epoch2_index: number;
  epoch1_id?: string;
  epoch2_id?: string;
  difference_image_url: string;
  stats: {
    rms_noise: number;
    max_positive_residual: number;
    min_negative_residual: number;
    snr_peak: number;
  };
}

export interface DiscoveryItem {
  id: string;
  name: string;
  target_field: string;
  ra_deg: number;
  dec_deg: number;
  ra_sexagesimal: string;
  dec_sexagesimal: string;
  category: 'moving_object' | 'variable_source' | 'unclassified';
  classification: string;
  angular_displacement_arcsec: number;
  proper_motion_arcsec_yr: number;
  brightness_mag_var: number;
  confidence_score: number;
  epochs_detected: number;
  status: string;
  date_flagged: string;
  notes: string;
}

export type ViewTab = 'overview' | 'explorer' | 'time-machine' | 'spectral' | 'discoveries' | 'about';

