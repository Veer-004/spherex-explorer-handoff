import React, { useState, useEffect, useRef } from 'react';
import { 
  Target, 
  ObservationsResponse, 
  DetectedCandidate,
  DifferenceResponse,
  MoversResponse,
  MlCandidate,
} from '../types';
import { ApiService } from '../services/api';
import { AstronomicalCanvas } from './AstronomicalCanvas';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  ChevronRight, 
  ChevronLeft, 
  Sliders, 
  Layers, 
  SplitSquareVertical, 
  MinusCircle, 
  Sparkles, 
  BookmarkPlus, 
  Info,
  Calendar,
  Zap,
  TrendingUp,
  AlertTriangle,
  Cpu,
} from 'lucide-react';

/** What Gaia DR3 says about an ML candidate's motion. */
function gaiaVerdict(c: MlCandidate): { text: string; tone: 'ok' | 'warn' | 'muted' } {
  if (c.gaia_pm_arcsec_yr === null || c.gaia_pm_arcsec_yr === undefined) {
    return { text: 'Not in Gaia DR3: unconfirmed', tone: 'muted' };
  }
  if (c.gaia_pm_arcsec_yr >= 1.0) return { text: `Confirmed by Gaia DR3: ${c.gaia_pm_arcsec_yr.toFixed(2)}″/yr`, tone: 'ok' };
  if (c.flagged) {
    return { text: `Gaia DR3 says ${c.gaia_pm_arcsec_yr.toFixed(3)}″/yr: likely false alarm`, tone: 'warn' };
  }
  return { text: 'Gaia: not moving', tone: 'muted' };
}

function mlToCandidate(c: MlCandidate): DetectedCandidate {
  return {
    candidate_id: c.candidate_id,
    type: 'moving_object',
    classification: `ML mover score ${(c.p_mover * 100).toFixed(0)}%`,
    ra_deg: c.ra_deg,
    dec_deg: c.dec_deg,
    ra_sexagesimal: c.ra_sexagesimal,
    dec_sexagesimal: c.dec_sexagesimal,
    pixel_x: c.pixel_x,
    pixel_y: c.pixel_y,
    angular_displacement_arcsec: 0,
    confidence_score: Math.round(c.p_mover * 100),
    snr: c.snr_deep ?? 0,
    epochs_detected: c.n_visits_detected,
    status: c.flagged ? 'ML candidate' : 'below threshold',
    track: c.track,
  };
}

interface TimeMachineProps {
  targets: Target[];
  currentTargetId?: string;
  onSelectTarget: (targetId: string) => void;
  onOpenCandidateModal: (candidate: DetectedCandidate, fieldName: string) => void;
  activeCoords: { ra: number; dec: number };
  detector: string;
  setDetector: (d: string) => void;
}

type ComparisonMode = 'blink' | 'side-by-side' | 'difference';

const FOV = 10.0;

export const TimeMachine: React.FC<TimeMachineProps> = ({
  targets,
  currentTargetId = '',
  onSelectTarget,
  onOpenCandidateModal,
  activeCoords,
  detector,
  setDetector,
}) => {
  const target = targets.find((t) => t.id === currentTargetId);
  const fieldRef = currentTargetId
    ? { target_id: currentTargetId }
    : { ra: activeCoords.ra, dec: activeCoords.dec };
  const [loadError, setLoadError] = useState<string>('');
  const [movers, setMovers] = useState<MoversResponse | null>(null);
  const [moversError, setMoversError] = useState<string>('');
  const [selectedMl, setSelectedMl] = useState<MlCandidate | null>(null);
  const [showMl, setShowMl] = useState<boolean>(true);
  const [mode, setMode] = useState<ComparisonMode>('blink');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0); // 0.5, 1, 2, 4
  const [currentEpochIdx, setCurrentEpochIdx] = useState<number>(0);
  const [blinkEpochA, setBlinkEpochA] = useState<number>(0);
  const [blinkEpochB, setBlinkEpochB] = useState<number>(3);
  const [sideEpochLeft, setSideEpochLeft] = useState<number>(0);
  const [sideEpochRight, setSideEpochRight] = useState<number>(3);
  const [loop, setLoop] = useState<boolean>(true);
  const [opacity, setOpacity] = useState<number>(100);

  // Observations data
  const [observationsData, setObservationsData] = useState<ObservationsResponse | null>(null);
  const [differenceData, setDifferenceData] = useState<DifferenceResponse | null>(null);
  const [selectedCandidate, setSelectedCandidate] = useState<DetectedCandidate | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingDiff, setLoadingDiff] = useState<boolean>(false);

  // Animation timer ref
  const timerRef = useRef<number | null>(null);

  // Fetch real visit stacks whenever the field or detector changes
  useEffect(() => {
    if (currentTargetId && !target) return;
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTargetId, activeCoords.ra, activeCoords.dec, detector, targets.length]);

  const loadData = async () => {
    setLoading(true);
    setLoadError('');
    setIsPlaying(false);
    try {
      const res = await ApiService.getObservations({ ...fieldRef, detector, fov_arcmin: FOV });
      const last = Math.max(0, res.observations.length - 1);
      setObservationsData(res);
      setCurrentEpochIdx(0);
      setBlinkEpochA(0);
      setBlinkEpochB(last);
      setSideEpochLeft(0);
      setSideEpochRight(last);
      setSelectedCandidate(res.detected_candidates[0] || null);
      if (res.observations.length >= 2) loadDifference(0, last);
      else setDifferenceData(null);
      setMovers(null);
      setSelectedMl(null);
      setMoversError('');
      ApiService.getMovers({ ...fieldRef, fov_arcmin: FOV })
        .then(setMovers)
        .catch((e: any) => setMoversError(e.message || 'ML search unavailable'));
    } catch (err: any) {
      setObservationsData(null);
      setDifferenceData(null);
      setLoadError(err.message || 'Could not load this field.');
    } finally {
      setLoading(false);
    }
  };

  const loadDifference = async (ep1: number, ep2: number) => {
    setLoadingDiff(true);
    try {
      const diff = await ApiService.getDifferenceImage({ ...fieldRef, detector, fov_arcmin: FOV, epoch1: ep1, epoch2: ep2 });
      setDifferenceData(diff);
    } catch (err) {
      console.error(err);
      setDifferenceData(null);
    } finally {
      setLoadingDiff(false);
    }
  };

  // Playback timer loop
  useEffect(() => {
    if (!isPlaying || !observationsData) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    const intervalMs = (1000 / playbackSpeed);

    timerRef.current = window.setInterval(() => {
      if (mode === 'blink') {
        // Toggle between Blink Epoch A and B
        setCurrentEpochIdx((prev) => (prev === blinkEpochA ? blinkEpochB : blinkEpochA));
      } else {
        // Step chronologically through epochs
        setCurrentEpochIdx((prev) => {
          const next = prev + 1;
          if (next >= observationsData.observations.length) {
            if (loop) return 0;
            setIsPlaying(false);
            return prev;
          }
          return next;
        });
      }
    }, intervalMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, playbackSpeed, mode, blinkEpochA, blinkEpochB, observationsData, loop]);

  const currentEpoch = observationsData?.observations[currentEpochIdx];
  const epochs = observationsData?.observations || [];

  // Measured per-visit positions of the target (median SPHEREx centroid in each visit)
  const activeTrack = selectedMl ? selectedMl.track : selectedCandidate?.track;
  const motionTracks = activeTrack && activeTrack.length > 1 ? activeTrack : undefined;
  const motion = selectedCandidate?.motion;
  const mlShown = showMl && movers ? movers.candidates.filter((c) => c.flagged || c.candidate_id === selectedMl?.candidate_id) : [];
  const canvasCandidates = [...(observationsData?.detected_candidates || []), ...mlShown.map(mlToCandidate)];
  const selectedId = selectedMl?.candidate_id ?? selectedCandidate?.candidate_id;
  const onCanvasSelect = (c: DetectedCandidate) => {
    const ml = movers?.candidates.find((m) => m.candidate_id === c.candidate_id);
    if (ml) {
      setSelectedMl(ml);
    } else {
      setSelectedMl(null);
      setSelectedCandidate(c);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-3.5rem)] overflow-hidden bg-background">
      {/* Top Controls Toolbar */}
      <div className="bg-surface border-b border-surface-border px-4 sm:px-6 h-12 flex items-center justify-between gap-3 text-xs flex-shrink-0 select-none">
        {/* Target Selector */}
        <div className="flex items-center space-x-2.5">
          <span className="text-text-muted font-mono uppercase text-[11px] tracking-wider">
            Target:
          </span>
          <select
            value={currentTargetId}
            onChange={(e) => onSelectTarget(e.target.value)}
            className="h-8 px-2.5 rounded bg-surface-elevated border border-surface-border text-xs text-text-main font-mono focus:border-primary focus:outline-none"
          >
            {!currentTargetId && <option value="">— custom position —</option>}
            {targets.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.category === 'moving' ? `${t.proper_motion.total_pm_arcsec_yr}″/yr` : t.category === 'variable' ? 'Variable' : 'Field'})
              </option>
            ))}
          </select>
          <div className="flex items-center space-x-0.5 bg-surface-elevated p-0.5 rounded border border-surface-border font-mono">
            {['D1', 'D2', 'D3', 'D4', 'D5', 'D6'].map((d) => {
              const ok = !target?.available_detectors || target.available_detectors.includes(d);
              return (
                <button
                  key={d}
                  disabled={!ok}
                  onClick={() => setDetector(d)}
                  className={`px-1.5 py-0.5 rounded text-[11px] disabled:opacity-30 ${
                    detector === d ? 'bg-primary text-[#0B1016] font-semibold' : 'text-text-muted hover:text-text-main'
                  }`}
                >
                  {d}
                </button>
              );
            })}
          </div>
          {loading && <span className="text-text-muted font-mono text-[11px]">Loading…</span>}
          {loadError && <span className="text-scientific-danger font-mono text-[11px]">{loadError}</span>}
        </div>

        {/* Comparison Modes Segmented Control */}
        <div className="flex items-center space-x-1 bg-surface-card p-1 rounded-md border border-surface-border font-mono text-xs">
          <button
            onClick={() => { setMode('blink'); setIsPlaying(true); }}
            className={`flex items-center space-x-1.5 px-3 h-7 rounded text-xs transition-colors ${
              mode === 'blink'
                ? 'bg-surface-elevated text-primary border border-surface-border font-semibold shadow-sm'
                : 'text-text-muted hover:text-text-main'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>A. Blink Mode</span>
          </button>
          <button
            onClick={() => { setMode('side-by-side'); setIsPlaying(false); }}
            className={`flex items-center space-x-1.5 px-3 h-7 rounded text-xs transition-colors ${
              mode === 'side-by-side'
                ? 'bg-surface-elevated text-primary border border-surface-border font-semibold shadow-sm'
                : 'text-text-muted hover:text-text-main'
            }`}
          >
            <SplitSquareVertical className="w-3.5 h-3.5" />
            <span>B. Side-by-Side</span>
          </button>
          <button
            onClick={() => { setMode('difference'); setIsPlaying(false); }}
            className={`flex items-center space-x-1.5 px-3 h-7 rounded text-xs transition-colors ${
              mode === 'difference'
                ? 'bg-surface-elevated text-primary border border-surface-border font-semibold shadow-sm'
                : 'text-text-muted hover:text-text-main'
            }`}
          >
            <MinusCircle className="w-3.5 h-3.5" />
            <span>C. Difference Image</span>
          </button>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center space-x-2">
          {mode !== 'difference' && (
            <>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`flex items-center space-x-1.5 h-8 px-3 rounded text-xs font-mono font-semibold transition-colors ${
                  isPlaying
                    ? 'bg-scientific-warning text-[#0B1016]'
                    : 'bg-primary text-[#0B1016] hover:bg-primary-hover shadow-sm'
                }`}
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isPlaying ? 'Pause' : 'Play Timeline'}</span>
              </button>

              <div className="flex items-center space-x-1 h-8 bg-surface-elevated border border-surface-border px-2 rounded text-[11px] font-mono text-secondary">
                <span className="text-text-muted">Speed:</span>
                {[0.5, 1, 2, 4].map((s) => (
                  <button
                    key={s}
                    onClick={() => setPlaybackSpeed(s)}
                    className={`px-1 rounded transition-colors ${playbackSpeed === s ? 'text-primary font-bold bg-surface' : 'hover:text-text-main'}`}
                  >
                    {s}x
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Main Workspace Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* CENTER VIEWPORT (Dynamic based on comparison mode) */}
        <div className="flex-1 flex flex-col bg-[#070B0E] relative overflow-hidden">
          {mode === 'blink' && (
            <div className="flex-1 relative">
              {currentEpoch && (
                <AstronomicalCanvas
                  imageUrl={currentEpoch.image_url}
                  centerRa={observationsData?.ra_deg || activeCoords.ra}
                  centerDec={observationsData?.dec_deg || activeCoords.dec}
                  fovArcmin={observationsData?.fov_arcmin || 10.0}
                  candidates={canvasCandidates}
                  selectedCandidateId={selectedId}
                  onSelectCandidate={onCanvasSelect}
                  motionTracks={motionTracks}
                  crosshairLabel={`Blinking: ${currentEpoch.epoch_id} (${new Date(currentEpoch.obs_date).toISOString().slice(0, 10)})`}
                  className="w-full h-full"
                />
              )}

              {/* Epoch Indicator Overlay */}
              <div className="absolute top-4 left-4 bg-surface/90 border border-surface-border backdrop-blur p-2.5 rounded font-mono text-xs space-y-1">
                <div className="flex items-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${currentEpochIdx === blinkEpochA ? 'bg-primary' : 'bg-scientific-cyan'} animate-ping`} />
                  <span className="text-text-main font-semibold">Active Epoch: {currentEpoch?.epoch_id}</span>
                </div>
                <div className="text-[11px] text-text-muted">
                  Blinking: <strong className="text-primary">{epochs[blinkEpochA]?.epoch_id}</strong> ↔ <strong className="text-scientific-cyan">{epochs[blinkEpochB]?.epoch_id}</strong>
                </div>
              </div>
            </div>
          )}

          {mode === 'side-by-side' && (
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-1 p-1 bg-surface-border">
              {/* Left Viewport */}
              <div className="flex flex-col relative h-full">
                <div className="absolute top-2 left-2 z-10 bg-surface/90 border border-surface-border px-2.5 py-1 rounded text-xs font-mono text-primary flex items-center space-x-2">
                  <span>Epoch Left:</span>
                  <select
                    value={sideEpochLeft}
                    onChange={(e) => setSideEpochLeft(Number(e.target.value))}
                    className="bg-surface-elevated px-1 py-0.5 rounded text-text-main"
                  >
                    {epochs.map((ep, i) => (
                      <option key={ep.epoch_id} value={i}>{ep.epoch_id} ({ep.obs_date.slice(0, 10)})</option>
                    ))}
                  </select>
                </div>
                {epochs[sideEpochLeft] && (
                  <AstronomicalCanvas
                    imageUrl={epochs[sideEpochLeft].image_url}
                    centerRa={observationsData?.ra_deg || activeCoords.ra}
                    centerDec={observationsData?.dec_deg || activeCoords.dec}
                    fovArcmin={observationsData?.fov_arcmin || 10.0}
                    candidates={canvasCandidates}
                    crosshairLabel={`${epochs[sideEpochLeft].epoch_id}`}
                    className="w-full h-full"
                  />
                )}
              </div>

              {/* Right Viewport */}
              <div className="flex flex-col relative h-full">
                <div className="absolute top-2 left-2 z-10 bg-surface/90 border border-surface-border px-2.5 py-1 rounded text-xs font-mono text-scientific-cyan flex items-center space-x-2">
                  <span>Epoch Right:</span>
                  <select
                    value={sideEpochRight}
                    onChange={(e) => setSideEpochRight(Number(e.target.value))}
                    className="bg-surface-elevated px-1 py-0.5 rounded text-text-main"
                  >
                    {epochs.map((ep, i) => (
                      <option key={ep.epoch_id} value={i}>{ep.epoch_id} ({ep.obs_date.slice(0, 10)})</option>
                    ))}
                  </select>
                </div>
                {epochs[sideEpochRight] && (
                  <AstronomicalCanvas
                    imageUrl={epochs[sideEpochRight].image_url}
                    centerRa={observationsData?.ra_deg || activeCoords.ra}
                    centerDec={observationsData?.dec_deg || activeCoords.dec}
                    fovArcmin={observationsData?.fov_arcmin || 10.0}
                    candidates={canvasCandidates}
                    motionTracks={motionTracks}
                    crosshairLabel={`${epochs[sideEpochRight].epoch_id}`}
                    className="w-full h-full"
                  />
                )}
              </div>
            </div>
          )}

          {mode === 'difference' && (
            <div className="flex-1 relative">
              {differenceData ? (
                <AstronomicalCanvas
                  imageUrl={differenceData.difference_image_url}
                  centerRa={observationsData?.ra_deg || activeCoords.ra}
                  centerDec={observationsData?.dec_deg || activeCoords.dec}
                  fovArcmin={observationsData?.fov_arcmin || 10.0}
                  candidates={canvasCandidates}
                  selectedCandidateId={selectedId}
                  onSelectCandidate={onCanvasSelect}
                  motionTracks={motionTracks}
                  crosshairLabel={`Difference: ${epochs[blinkEpochB]?.obs_date.slice(0, 10)} − ${epochs[blinkEpochA]?.obs_date.slice(0, 10)}`}
                  className="w-full h-full"
                />
              ) : (
                <div className="h-full flex items-center justify-center text-text-muted font-mono text-xs">
                  {loadingDiff ? 'Subtracting visit stacks…' : 'A difference image needs at least two visits in this detector.'}
                </div>
              )}

              {/* Difference Stats HUD */}
              {differenceData && (
                <div className="absolute top-4 left-4 bg-surface/90 border border-surface-border backdrop-blur p-3 rounded font-mono text-xs space-y-2 max-w-sm">
                  <div className="flex items-center space-x-2 text-scientific-cyan">
                    <MinusCircle className="w-4 h-4" />
                    <span className="font-semibold uppercase tracking-wider text-[11px]">
                      Astrometric Difference Profile
                    </span>
                  </div>
                  <p className="text-[11px] text-text-muted leading-relaxed font-sans">
                    Later visit minus earlier visit, both on the same sky grid. Static stars cancel. A moving object
                    leaves red where it was and cyan where it went. A variable star turns entirely red or cyan.
                  </p>
                  <div className="grid grid-cols-2 gap-1 text-[11px] pt-1 border-t border-surface-border">
                    <span className="text-text-muted">Peak Residual:</span>
                    <span className="text-scientific-cyan font-bold">{differenceData.stats.max_positive_residual} MJy/sr</span>
                    <span className="text-text-muted">Background Noise:</span>
                    <span className="text-secondary">{differenceData.stats.rms_noise} MJy/sr</span>
                    <span className="text-text-muted">Peak / noise:</span>
                    <span className="text-scientific-success font-semibold">{differenceData.stats.snr_peak}σ</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Bottom Timeline Scrubber */}
          <div className="bg-surface border-t border-surface-border px-4 sm:px-6 py-2.5 space-y-2 flex-shrink-0 select-none">
            <div className="flex items-center justify-between text-xs font-mono">
              <div className="flex items-center space-x-2">
                <Calendar className="w-3.5 h-3.5 text-text-muted" />
                <span className="text-text-muted">Survey Timeline:</span>
                <span className="text-text-main font-semibold">
                  Visit {currentEpochIdx + 1} of {epochs.length}
                </span>
                <span className="text-secondary">
                  · {currentEpoch?.obs_date.slice(0, 10)} · {currentEpoch?.n_exposures ?? '?'} exposures stacked
                </span>
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1.5">
                  <span className="text-text-muted text-[11px]">Blink Pair:</span>
                  <select
                    value={blinkEpochA}
                    onChange={(e) => {
                      setBlinkEpochA(Number(e.target.value));
                      loadDifference(Number(e.target.value), blinkEpochB);
                    }}
                    className="bg-surface-elevated border border-surface-border rounded px-1.5 py-0.5 text-xs text-text-main"
                  >
                    {epochs.map((ep, i) => (
                      <option key={ep.epoch_id} value={i}>{ep.obs_date.slice(0, 10)}</option>
                    ))}
                  </select>
                  <span className="text-text-muted">↔</span>
                  <select
                    value={blinkEpochB}
                    onChange={(e) => {
                      setBlinkEpochB(Number(e.target.value));
                      loadDifference(blinkEpochA, Number(e.target.value));
                    }}
                    className="bg-surface-elevated border border-surface-border rounded px-1.5 py-0.5 text-xs text-text-main"
                  >
                    {epochs.map((ep, i) => (
                      <option key={ep.epoch_id} value={i}>{ep.obs_date.slice(0, 10)}</option>
                    ))}
                  </select>
                </div>

                <label className="flex items-center space-x-1.5 text-xs text-text-muted cursor-pointer">
                  <input
                    type="checkbox"
                    checked={loop}
                    onChange={(e) => setLoop(e.target.checked)}
                    className="rounded bg-surface-elevated border-surface-border text-primary"
                  />
                  <span>Loop</span>
                </label>
              </div>
            </div>

            {/* Visual Timeline Bar with Epoch nodes */}
            <div className="relative flex items-center pt-2">
              <div className="w-full h-1.5 bg-surface-elevated rounded-full relative">
                <div 
                  className="h-full bg-primary rounded-full transition-all"
                  style={{ width: `${(currentEpochIdx / Math.max(1, epochs.length - 1)) * 100}%` }}
                />
              </div>

              {/* Epoch Ticks */}
              <div className="absolute inset-0 flex justify-between items-center px-1">
                {epochs.map((ep, idx) => {
                  const isCur = currentEpochIdx === idx;
                  return (
                    <button
                      key={ep.epoch_id}
                      onClick={() => {
                        setCurrentEpochIdx(idx);
                        setIsPlaying(false);
                      }}
                      className={`w-4 h-4 rounded-full border-2 transition-transform ${
                        isCur
                          ? 'border-primary bg-primary scale-125 shadow-lg'
                          : 'border-surface-border bg-surface-elevated hover:border-text-muted'
                      }`}
                      title={`${ep.epoch_id}: ${ep.obs_date}`}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT MOVING OBJECT DETECTION & ASTROMETRY PANEL (~320px) */}
        <div className="w-80 flex-shrink-0 bg-surface border-l border-surface-border flex flex-col overflow-y-auto">
          <div className="p-4 space-y-5">
            {/* ML mover search over every source in the field */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-text-muted uppercase tracking-wider flex items-center space-x-1">
                  <Cpu className="w-3.5 h-3.5 text-scientific-cyan" />
                  <span>ML Mover Search</span>
                </span>
                <label className="flex items-center space-x-1 text-[10px] font-mono text-text-muted cursor-pointer">
                  <input type="checkbox" checked={showMl} onChange={(e) => setShowMl(e.target.checked)} />
                  <span>on image</span>
                </label>
              </div>
              {!movers && !moversError && <p className="text-[11px] text-text-muted font-mono">Scoring every source in this field…</p>}
              {moversError && <p className="text-[11px] text-scientific-warning font-mono">{moversError}</p>}
              {movers && (
                <>
                  <p className="text-[11px] text-text-muted leading-relaxed">
                    {movers.n_scored} sources scored, <strong className="text-text-main">{movers.n_flagged} flagged</strong>{' '}
                    (about {movers.expected_false_alarms} false alarm{movers.expected_false_alarms === 1 ? '' : 's'} expected
                    by chance). Model trained on synthetic movers injected into real SPHEREx stacks: it finds{' '}
                    {Math.round((movers.model.recall_injected_movers || 0) * 100)}% of test movers vs.{' '}
                    {Math.round((movers.model.rule_recall_injected_movers || 0) * 100)}% for a simple rule, at{' '}
                    {((movers.model.false_alarm_rate_real_stars || 0) * 100).toFixed(1)}% false alarms on real Gaia stars.
                  </p>
                  <div className="space-y-1.5">
                    {movers.candidates.length === 0 && (
                      <p className="text-[11px] text-text-muted font-mono">No sources in view.</p>
                    )}
                    {movers.candidates.map((c) => {
                      const v = gaiaVerdict(c);
                      const sel = selectedMl?.candidate_id === c.candidate_id;
                      return (
                        <div
                          key={c.candidate_id}
                          onClick={() => setSelectedMl(sel ? null : c)}
                          className={`p-2 rounded border cursor-pointer text-[11px] font-mono transition-colors ${
                            sel
                              ? 'border-scientific-cyan bg-surface-elevated'
                              : c.flagged
                              ? 'border-scientific-cyan/40 bg-surface-card hover:bg-surface-elevated'
                              : 'border-surface-border bg-surface-card/50 hover:bg-surface-elevated opacity-75'
                          }`}
                        >
                          <div className="flex justify-between">
                            <span className="text-text-main">{c.ra_sexagesimal} {c.dec_sexagesimal}</span>
                            <span className={c.flagged ? 'text-scientific-cyan font-semibold' : 'text-text-muted'}>
                              {(c.p_mover * 100).toFixed(0)}%
                            </span>
                          </div>
                          <div className="flex justify-between text-text-muted">
                            <span>
                              {c.pm_fit_arcsec_yr !== null ? `${c.pm_fit_arcsec_yr} ± ${c.pm_err_arcsec_yr}″/yr` : 'no motion fit'}
                            </span>
                            <span>S/N {c.snr_deep} · {c.n_visits_detected} visits</span>
                          </div>
                          <div
                            className={
                              v.tone === 'ok'
                                ? 'text-scientific-success'
                                : v.tone === 'warn'
                                ? 'text-scientific-warning'
                                : 'text-text-muted'
                            }
                          >
                            {c.flagged ? '' : 'Below threshold · '}
                            {v.text}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>

            <div className="pt-3 border-t border-surface-border">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-text-muted uppercase tracking-wider flex items-center space-x-1">
                  <Sparkles className="w-3.5 h-3.5 text-primary" />
                  <span>Target Measurement</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono border border-primary/30 bg-primary/10 text-primary">
                  {observationsData?.detected_candidates.length || 0} Detected
                </span>
              </div>
              <p className="text-xs text-text-muted mt-1">
                Positions and brightness measured on every SPHEREx exposure of this target, fitted across visits.
              </p>
            </div>

            {/* Candidates List */}
            <div className="space-y-2">
              {observationsData?.detected_candidates.map((cand) => {
                const isSelected = selectedCandidate?.candidate_id === cand.candidate_id;
                const isMoving = cand.type === 'moving_object';
                return (
                  <div
                    key={cand.candidate_id}
                    onClick={() => { setSelectedMl(null); setSelectedCandidate(cand); }}
                    className={`p-3 rounded border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-primary bg-surface-elevated shadow-md'
                        : 'border-surface-border bg-surface-card hover:bg-surface-elevated'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-semibold text-xs text-text-main font-mono">
                          {cand.candidate_id}
                        </span>
                        <p className="text-[11px] text-scientific-cyan font-mono">
                          {cand.classification}
                        </p>
                      </div>
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-mono border border-surface-border bg-surface text-secondary">
                        {cand.confidence_score}% Conf
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-1 text-[11px] font-mono text-text-muted mt-2 pt-2 border-t border-surface-border/60">
                      <span>Displacement:</span>
                      <span className="text-text-main text-right">{cand.angular_displacement_arcsec}″</span>
                      <span>Median peak SNR:</span>
                      <span className="text-scientific-success text-right">{cand.snr}</span>
                      <span>Visits measured:</span>
                      <span className="text-secondary text-right">{cand.epochs_detected}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Detailed Selected Candidate Inspection */}
            {selectedCandidate && (
              <div className="space-y-3 pt-3 border-t border-surface-border text-xs font-mono">
                <span className="text-[11px] font-semibold text-text-muted uppercase tracking-wider block">
                  Astrometric Metrics
                </span>

                <div className="space-y-1 bg-surface-elevated p-3 rounded border border-surface-border text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-text-muted">RA (ICRS):</span>
                    <span className="text-secondary">{selectedCandidate.ra_sexagesimal}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-text-muted">DEC (ICRS):</span>
                    <span className="text-secondary">{selectedCandidate.dec_sexagesimal}</span>
                  </div>
                  {motion ? (
                    <>
                      <div className="flex justify-between">
                        <span className="text-text-muted">SPHEREx motion:</span>
                        <span className="text-primary font-bold">
                          {motion.pm_total_arcsec_yr} ± {motion.pm_error_arcsec_yr}″/yr
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-muted">μ RA·cosδ / μ Dec:</span>
                        <span className="text-secondary">
                          {motion.pm_ra_arcsec_yr} / {motion.pm_dec_arcsec_yr}″/yr
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-muted">Catalog motion:</span>
                        <span className="text-secondary">{motion.catalog_pm_arcsec_yr}″/yr</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-muted">Fit residual (RMS):</span>
                        <span className="text-secondary">{motion.rms_arcsec}″</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-muted">Positions / baseline:</span>
                        <span className="text-secondary">
                          {motion.n_points} / {motion.baseline_yr} yr
                        </span>
                      </div>
                    </>
                  ) : (
                    <div className="text-text-muted">Not enough detections for a motion fit.</div>
                  )}
                  {selectedCandidate.blend && (
                    <div className="text-scientific-warning font-sans leading-snug pt-1">{selectedCandidate.blend.message}</div>
                  )}
                  {selectedCandidate.brightness_change_mag ? (
                    <div className="flex justify-between">
                      <span className="text-text-muted">Brightness change:</span>
                      <span className="text-scientific-warning">{selectedCandidate.brightness_change_mag} mag</span>
                    </div>
                  ) : null}
                </div>

                <div className="p-2.5 rounded bg-surface-card border border-surface-border text-[11px] text-text-muted leading-relaxed flex items-start space-x-2">
                  <AlertTriangle className="w-4 h-4 text-scientific-warning flex-shrink-0 mt-0.5" />
                  <span>
                    SPHEREx pixels are 6.15″, so motion is fitted from many exposures rather than read from one image.
                    The catalog value is shown for comparison.
                  </span>
                </div>

                <button
                  onClick={() => onOpenCandidateModal(selectedCandidate, observationsData?.target_name || "Field Observation")}
                  className="w-full py-2 px-3 rounded bg-primary hover:bg-primary-hover text-[#0B1016] text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
                >
                  <BookmarkPlus className="w-4 h-4" />
                  <span>Flag as Candidate Discovery</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

