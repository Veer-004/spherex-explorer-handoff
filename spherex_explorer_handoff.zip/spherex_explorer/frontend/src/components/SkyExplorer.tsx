import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Target,
  ObservationsResponse,
  DetectedCandidate,
  ViewTab,
  CatalogSource,
  BuildStatus,
} from '../types';
import { ApiService, ApiError } from '../services/api';
import { AstronomicalCanvas } from './AstronomicalCanvas';
import {
  Search,
  FileCode,
  Clock,
  Layers,
  ChevronRight,
  ChevronLeft,
  AlertCircle,
  Sparkles,
  BookmarkPlus,
  RefreshCw,
  ExternalLink,
  Download,
} from 'lucide-react';

interface SkyExplorerProps {
  targets: Target[];
  currentTargetId?: string;
  onSelectTarget: (targetId: string) => void;
  onNavigateTab: (tab: ViewTab) => void;
  onOpenHeaderModal: (metadata: any) => void;
  onOpenCandidateModal: (candidate: DetectedCandidate, fieldName: string) => void;
  activeCoords: { ra: number; dec: number };
  setActiveCoords: (coords: { ra: number; dec: number }) => void;
  onTargetsChanged: () => Promise<Target[]>;
  detector: string;
  setDetector: (d: string) => void;
}

const DETECTOR_BANDS: Record<string, string> = {
  D1: '0.75–1.11 µm',
  D2: '1.11–1.64 µm',
  D3: '1.64–2.42 µm',
  D4: '2.42–3.82 µm',
  D5: '3.82–4.42 µm',
  D6: '4.42–5.00 µm',
};

export const SkyExplorer: React.FC<SkyExplorerProps> = ({
  targets,
  currentTargetId,
  onSelectTarget,
  onNavigateTab,
  onOpenHeaderModal,
  onOpenCandidateModal,
  activeCoords,
  setActiveCoords,
  onTargetsChanged,
  detector,
  setDetector,
}) => {
  const target = targets.find((t) => t.id === currentTargetId);

  // Inputs
  const [raInput, setRaInput] = useState<string>('');
  const [decInput, setDecInput] = useState<string>('');
  const [fovArcmin, setFovArcmin] = useState<number>(10.0);
  const [stretch, setStretch] = useState<string>('asinh');
  const [colormap, setColormap] = useState<string>('astronomical');

  // Viewer toggles
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showReticle, setShowReticle] = useState<boolean>(true);
  const [showCandidates, setShowCandidates] = useState<boolean>(true);
  const [overlay, setOverlay] = useState<'none' | 'gaia' | 'catwise'>('none');
  const [overlaySources, setOverlaySources] = useState<CatalogSource[]>([]);

  // Data
  const [observationsData, setObservationsData] = useState<ObservationsResponse | null>(null);
  const [currentEpochIdx, setCurrentEpochIdx] = useState<number>(0);
  const [selectedCandidate, setSelectedCandidate] = useState<DetectedCandidate | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Position that is not in the dataset yet (offer to build it from IRSA)
  const [buildPrompt, setBuildPrompt] = useState<{ ra: number; dec: number; fieldId: string } | null>(null);
  const [buildStatus, setBuildStatus] = useState<BuildStatus | null>(null);
  const pollRef = useRef<number | null>(null);

  const [isLeftCollapsed, setIsLeftCollapsed] = useState<boolean>(false);
  const [isRightCollapsed, setIsRightCollapsed] = useState<boolean>(false);

  const availableDetectors = target?.available_detectors || observationsData?.available_detectors || [];
  const maxFov = target?.max_fov_arcmin || 12;

  // Target changed: reset inputs to that target's defaults
  useEffect(() => {
    if (target) {
      setRaInput(target.coordinates.ra_sexagesimal);
      setDecInput(target.coordinates.dec_sexagesimal);
      setFovArcmin(target.fov_arcmin);
      if (!target.available_detectors || !target.available_detectors.includes(detector)) {
        setDetector(target.default_detector);
      }
      setActiveCoords({ ra: target.coordinates.ra_deg, dec: target.coordinates.dec_deg });
      setBuildPrompt(null);
    } else if (!currentTargetId) {
      setRaInput(activeCoords.ra.toFixed(5));
      setDecInput(activeCoords.dec.toFixed(5));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTargetId, targets.length]);

  const load = useCallback(async () => {
    if (!currentTargetId && !activeCoords) return;
    setLoading(true);
    setErrorMessage('');
    try {
      const res = await ApiService.getObservations({
        target_id: currentTargetId || undefined,
        ra: currentTargetId ? undefined : activeCoords.ra,
        dec: currentTargetId ? undefined : activeCoords.dec,
        detector,
        fov_arcmin: fovArcmin,
        stretch,
        colormap,
      });
      setObservationsData(res);
      setBuildPrompt(null);
      setCurrentEpochIdx((i) => Math.min(i, Math.max(0, res.observations.length - 1)));
      setSelectedCandidate(res.detected_candidates[0] || null);
    } catch (err: any) {
      setObservationsData(null);
      if (err instanceof ApiError && err.status === 404 && err.detail?.can_build) {
        setBuildPrompt({ ra: activeCoords.ra, dec: activeCoords.dec, fieldId: err.detail.field_id });
        setBuildStatus(err.detail.build?.state && err.detail.build.state !== 'unknown' ? err.detail.build : null);
      } else {
        setErrorMessage(err.message || 'Error loading observation data');
      }
    } finally {
      setLoading(false);
    }
  }, [currentTargetId, activeCoords.ra, activeCoords.dec, detector, fovArcmin, stretch, colormap]);

  useEffect(() => {
    if (currentTargetId && !target) return; // wait for the target list
    load();
  }, [load]);

  // Catalog overlay
  useEffect(() => {
    if (overlay === 'none' || !observationsData?.target_id) {
      setOverlaySources([]);
      return;
    }
    ApiService.getCatalog({ target_id: observationsData.target_id, source: overlay, fov_arcmin: fovArcmin })
      .then((c) => setOverlaySources(c.sources))
      .catch(() => setOverlaySources([]));
  }, [overlay, observationsData?.target_id, fovArcmin]);

  useEffect(() => () => {
    if (pollRef.current) window.clearInterval(pollRef.current);
  }, []);

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    try {
      const res = await ApiService.searchCoordinates({ ra: raInput, dec: decInput, fov_arcmin: fovArcmin });
      setRaInput(res.ra_sexagesimal);
      setDecInput(res.dec_sexagesimal);
      setActiveCoords({ ra: res.ra_deg, dec: res.dec_deg });
      if (res.matched_target) {
        onSelectTarget(res.matched_target.id);
      } else {
        onSelectTarget('');
        setObservationsData(null);
        setBuildPrompt({ ra: res.ra_deg, dec: res.dec_deg, fieldId: res.field_id });
        setBuildStatus(null);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid astronomical coordinates');
    }
  };

  const startBuild = async () => {
    if (!buildPrompt) return;
    try {
      const st = await ApiService.buildField(buildPrompt.ra, buildPrompt.dec);
      setBuildStatus(st);
      if (st.state === 'done') {
        await onTargetsChanged();
        onSelectTarget(st.field_id);
        return;
      }
      if (pollRef.current) window.clearInterval(pollRef.current);
      pollRef.current = window.setInterval(async () => {
        const s = await ApiService.getBuildStatus(st.field_id).catch(() => null);
        if (!s) return;
        setBuildStatus(s);
        if (s.state === 'done' || s.state === 'error') {
          if (pollRef.current) window.clearInterval(pollRef.current);
          if (s.state === 'done') {
            await onTargetsChanged();
            onSelectTarget(s.field_id);
          }
        }
      }, 4000);
    } catch (err: any) {
      setBuildStatus({ field_id: buildPrompt.fieldId, state: 'error', message: err.message });
    }
  };

  const currentEpoch = observationsData?.observations[currentEpochIdx];
  const metadata = currentEpoch?.metadata;
  const motion = selectedCandidate?.motion;
  const building = buildStatus && (buildStatus.state === 'queued' || buildStatus.state === 'running');

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-3.5rem)] overflow-hidden">
      {/* Top Workspace Bar */}
      <div className="bg-surface border-b border-surface-border px-4 sm:px-6 h-12 flex items-center justify-between text-xs font-mono flex-shrink-0">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-text-muted">Target:</span>
            <span className="text-text-main font-semibold">
              {observationsData?.target_name || (buildPrompt ? 'Position not in dataset' : '—')}
            </span>
          </div>
          {observationsData && (
            <div className="hidden sm:flex items-center space-x-2 text-secondary">
              <span>RA: <strong className="text-text-main">{observationsData.ra_deg.toFixed(4)}°</strong></span>
              <span>DEC: <strong className="text-text-main">{observationsData.dec_deg.toFixed(4)}°</strong></span>
            </div>
          )}
          {currentEpoch && (
            <div className="hidden md:flex items-center space-x-2 text-text-muted">
              <span>Visit:</span>
              <span className="px-1.5 py-0.5 rounded bg-surface-elevated text-primary font-medium">
                {currentEpoch.epoch_id} ({currentEpochIdx + 1}/{observationsData?.total_epochs})
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-2">
          {metadata && (
            <button
              onClick={() => onOpenHeaderModal(metadata)}
              className="flex items-center space-x-1 px-2.5 py-1 rounded bg-surface-elevated border border-surface-border hover:border-primary/50 text-secondary hover:text-text-main transition-colors"
            >
              <FileCode className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">FITS Header</span>
            </button>
          )}
          <button
            onClick={() => onNavigateTab('time-machine')}
            className="flex items-center space-x-1 px-2.5 py-1 rounded bg-surface-elevated border border-surface-border hover:border-scientific-cyan/50 text-scientific-cyan transition-colors"
          >
            <Clock className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Time Machine</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden relative">
        {/* LEFT CONTROL SIDEBAR */}
        <div
          className={`${
            isLeftCollapsed ? 'w-0 hidden' : 'w-72 sm:w-80'
          } flex-shrink-0 bg-surface border-r border-surface-border flex flex-col overflow-y-auto transition-all duration-200 z-10`}
        >
          <div className="p-4 space-y-5">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-text-muted uppercase tracking-wider block">
                Fields in Dataset
              </label>
              <select
                value={currentTargetId || ''}
                onChange={(e) => onSelectTarget(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded bg-surface-elevated border border-surface-border text-xs text-text-main focus:outline-none focus:border-primary font-mono"
              >
                {!currentTargetId && <option value="">— custom position —</option>}
                {targets.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} {t.is_custom ? '(custom field)' : `(${t.classification.split(' ')[0]})`}
                  </option>
                ))}
              </select>
            </div>

            <form onSubmit={handleSearchSubmit} className="space-y-3 pt-2 border-t border-surface-border">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-text-muted uppercase tracking-wider">Coordinates</span>
                <span className="text-[10px] text-text-muted font-mono">ICRS</span>
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-text-muted font-mono">Right Ascension (RA):</label>
                <input
                  type="text"
                  value={raInput}
                  onChange={(e) => setRaInput(e.target.value)}
                  placeholder="08h 55m 10.83s or 133.795"
                  className="w-full px-2.5 py-1.5 rounded bg-surface-elevated border border-surface-border text-xs text-text-main font-mono focus:outline-none focus:border-primary"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-text-muted font-mono">Declination (DEC):</label>
                <input
                  type="text"
                  value={decInput}
                  onChange={(e) => setDecInput(e.target.value)}
                  placeholder="-07° 14′ 42.5″ or -7.245"
                  className="w-full px-2.5 py-1.5 rounded bg-surface-elevated border border-surface-border text-xs text-text-main font-mono focus:outline-none focus:border-primary"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2 px-3 rounded bg-primary hover:bg-primary-hover text-[#0B1016] text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors disabled:opacity-50"
              >
                {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                <span>{loading ? 'Loading SPHEREx stacks…' : 'Go to Position'}</span>
              </button>
            </form>

            {errorMessage && (
              <div className="p-2.5 rounded bg-scientific-danger/10 border border-scientific-danger/30 text-scientific-danger text-xs flex items-start space-x-1.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span className="leading-tight">{errorMessage}</span>
              </div>
            )}

            {buildPrompt && (
              <div className="p-3 rounded bg-primary/5 border border-primary/30 text-xs space-y-2">
                <p className="text-text-main leading-snug">
                  RA {buildPrompt.ra.toFixed(4)}°, Dec {buildPrompt.dec.toFixed(4)}° is not in the local dataset yet.
                </p>
                <p className="text-text-muted leading-snug">
                  Fetch it from NASA IRSA now: about 3 exposures per visit per detector, usually 3–10 minutes.
                </p>
                {buildStatus ? (
                  <div className="font-mono text-[11px] flex items-center space-x-1.5">
                    {building && <RefreshCw className="w-3.5 h-3.5 animate-spin text-primary" />}
                    <span className={buildStatus.state === 'error' ? 'text-scientific-danger' : 'text-primary'}>
                      {buildStatus.state}: {buildStatus.message}
                    </span>
                  </div>
                ) : null}
                {!building && (
                  <button
                    type="button"
                    onClick={startBuild}
                    className="w-full py-1.5 rounded border border-primary/50 hover:border-primary text-primary flex items-center justify-center space-x-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{buildStatus?.state === 'error' ? 'Retry download' : 'Download from IRSA'}</span>
                  </button>
                )}
              </div>
            )}

            {/* Detector & field of view */}
            <div className="space-y-3 pt-3 border-t border-surface-border">
              <div className="space-y-1">
                <label className="text-[11px] text-text-muted">Detector (wavelength band):</label>
                <div className="grid grid-cols-6 gap-1">
                  {['D1', 'D2', 'D3', 'D4', 'D5', 'D6'].map((d) => {
                    const ok = availableDetectors.length === 0 || availableDetectors.includes(d);
                    return (
                      <button
                        key={d}
                        type="button"
                        disabled={!ok}
                        onClick={() => setDetector(d)}
                        title={DETECTOR_BANDS[d]}
                        className={`py-1 text-xs font-mono rounded border disabled:opacity-30 ${
                          detector === d
                            ? 'border-primary bg-primary/15 text-primary font-semibold'
                            : 'border-surface-border bg-surface-elevated text-text-muted hover:text-text-main'
                        }`}
                      >
                        {d}
                      </button>
                    );
                  })}
                </div>
                <p className="text-[10px] text-text-muted font-mono">
                  {detector}: {DETECTOR_BANDS[detector]} · every exposure in this band, stacked per visit
                </p>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-text-muted">
                  <span>Field of View:</span>
                  <span className="font-mono text-primary font-medium">{fovArcmin}′</span>
                </div>
                <div className="grid grid-cols-5 gap-1">
                  {[3, 5, 8, 10, 12].map((f) => (
                    <button
                      key={f}
                      type="button"
                      disabled={f > maxFov}
                      onClick={() => setFovArcmin(f)}
                      className={`py-1 text-xs font-mono rounded border disabled:opacity-30 ${
                        fovArcmin === f
                          ? 'border-primary bg-primary/10 text-primary'
                          : 'border-surface-border bg-surface-elevated text-text-muted hover:text-text-main'
                      }`}
                    >
                      {f}′
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-text-muted">Catalog overlay:</label>
                <div className="grid grid-cols-3 gap-1">
                  {([['none', 'Off'], ['gaia', 'Gaia DR3'], ['catwise', 'CatWISE']] as const).map(([v, label]) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setOverlay(v)}
                      className={`py-1 text-[11px] font-mono rounded border ${
                        overlay === v
                          ? 'border-primary bg-primary/10 text-primary'
                          : 'border-surface-border bg-surface-elevated text-text-muted hover:text-text-main'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                {overlay !== 'none' && (
                  <p className="text-[10px] text-text-muted font-mono">
                    {overlaySources.length} sources · large circles move faster than 0.5″/yr
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-3 pt-3 border-t border-surface-border">
              <span className="text-xs font-semibold text-text-muted uppercase tracking-wider block">
                Intensity Stretch & Palette
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-text-muted block mb-1">Stretch:</label>
                  <select
                    value={stretch}
                    onChange={(e) => setStretch(e.target.value)}
                    className="w-full px-2 py-1 rounded bg-surface-elevated border border-surface-border font-mono text-xs text-text-main"
                  >
                    <option value="asinh">Asinh</option>
                    <option value="log">Logarithmic</option>
                    <option value="linear">Linear</option>
                    <option value="sqrt">Square Root</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-text-muted block mb-1">Colormap:</label>
                  <select
                    value={colormap}
                    onChange={(e) => setColormap(e.target.value)}
                    className="w-full px-2 py-1 rounded bg-surface-elevated border border-surface-border font-mono text-xs text-text-main"
                  >
                    <option value="astronomical">Astronomical</option>
                    <option value="grayscale">Grayscale</option>
                    <option value="inverted">Inverted</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={() => setIsLeftCollapsed(!isLeftCollapsed)}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-20 bg-surface border border-surface-border text-text-muted hover:text-text-main p-1 rounded-r shadow"
          title={isLeftCollapsed ? 'Expand Controls' : 'Collapse Controls'}
        >
          {isLeftCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>

        {/* CENTER VIEWER */}
        <div className="flex-1 flex flex-col bg-[#070B0E] relative overflow-hidden">
          {currentEpoch ? (
            <AstronomicalCanvas
              imageUrl={currentEpoch.image_url}
              centerRa={observationsData!.ra_deg}
              centerDec={observationsData!.dec_deg}
              fovArcmin={observationsData!.fov_arcmin}
              candidates={observationsData?.detected_candidates || []}
              selectedCandidateId={selectedCandidate?.candidate_id}
              onSelectCandidate={(cand) => setSelectedCandidate(cand)}
              showGrid={showGrid}
              showReticle={showReticle}
              showCandidateMarkers={showCandidates}
              overlaySources={overlaySources}
              crosshairLabel={`${currentEpoch.epoch_id} · ${metadata?.detector} (${
                metadata?.wavelength_min_um && metadata?.wavelength_max_um
                  ? `${metadata.wavelength_min_um.toFixed(2)}–${metadata.wavelength_max_um.toFixed(2)}µm`
                  : DETECTOR_BANDS[metadata?.detector || 'D1']
              })`}
              onToggleGrid={() => setShowGrid(!showGrid)}
              onToggleReticle={() => setShowReticle(!showReticle)}
              onToggleCandidates={() => setShowCandidates(!showCandidates)}
              className="flex-1"
            />
          ) : (
            <div className="flex-1 flex items-center justify-center text-text-muted text-xs font-mono px-6 text-center">
              {loading
                ? 'Loading SPHEREx stacks…'
                : buildPrompt
                ? 'This position has not been downloaded yet. Use “Download from IRSA” on the left.'
                : 'No observation loaded.'}
            </div>
          )}

          {observationsData && observationsData.observations.length > 0 && (
            <div className="bg-surface/95 border-t border-surface-border px-4 sm:px-6 h-11 flex items-center justify-between text-xs flex-shrink-0">
              <div className="flex items-center space-x-2.5 overflow-x-auto">
                <span className="text-text-muted text-[11px] font-mono">Survey Visit:</span>
                <div className="flex space-x-1">
                  {observationsData.observations.map((obs, idx) => (
                    <button
                      key={obs.epoch_id}
                      onClick={() => setCurrentEpochIdx(idx)}
                      title={`${obs.n_exposures ?? ''} exposures stacked`}
                      className={`h-7 px-2.5 rounded text-xs font-mono whitespace-nowrap transition-colors flex items-center justify-center ${
                        currentEpochIdx === idx
                          ? 'bg-primary text-[#0B1016] font-semibold shadow-sm'
                          : 'bg-surface-elevated text-secondary hover:text-text-main border border-surface-border'
                      }`}
                    >
                      {obs.obs_date.slice(0, 10)}
                    </button>
                  ))}
                </div>
              </div>
              <div className="hidden sm:flex items-center space-x-4 text-xs font-mono text-secondary">
                {currentEpoch && <span>MJD: {currentEpoch.mjd.toFixed(2)}</span>}
                <button
                  onClick={() => onNavigateTab('time-machine')}
                  className="text-scientific-cyan hover:underline inline-flex items-center space-x-1"
                >
                  <span>Animate in Time Machine</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}
        </div>

        <button
          onClick={() => setIsRightCollapsed(!isRightCollapsed)}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-20 bg-surface border border-surface-border text-text-muted hover:text-text-main p-1 rounded-l shadow"
          title={isRightCollapsed ? 'Expand Inspector' : 'Collapse Inspector'}
        >
          {isRightCollapsed ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
        </button>

        {/* RIGHT INSPECTOR */}
        <div
          className={`${
            isRightCollapsed ? 'w-0 hidden' : 'w-72 sm:w-80'
          } flex-shrink-0 bg-surface border-l border-surface-border flex flex-col overflow-y-auto transition-all duration-200 z-10`}
        >
          <div className="p-4 space-y-5">
            <div className="space-y-1">
              <span className="text-xs font-semibold text-text-muted uppercase tracking-wider">Target</span>
              <h3 className="text-sm font-semibold text-text-main">{observationsData?.target_name || '—'}</h3>
              <p className="text-[11px] text-text-muted font-mono">{target?.classification || 'Sky field'}</p>
              {target?.astrometry_source && (
                <p className="text-[10px] text-text-muted font-mono">Position & motion from {target.astrometry_source}</p>
              )}
            </div>

            <div className="space-y-2 pt-2 border-t border-surface-border text-xs font-mono">
              <span className="text-[11px] font-semibold text-text-muted uppercase tracking-wider block">
                This Stack
              </span>
              <div className="grid grid-cols-2 gap-1 text-[11px] bg-surface-elevated p-2.5 rounded border border-surface-border">
                <span className="text-text-muted">Detector:</span>
                <span className="text-text-main font-semibold">{metadata?.detector || detector}</span>
                <span className="text-text-muted">Wavelengths:</span>
                <span className="text-scientific-cyan font-semibold">
                  {metadata?.wavelength_min_um && metadata?.wavelength_max_um
                    ? `${metadata.wavelength_min_um.toFixed(2)}–${metadata.wavelength_max_um.toFixed(2)} µm`
                    : DETECTOR_BANDS[detector]}
                </span>
                <span className="text-text-muted">Exposures:</span>
                <span className="text-primary font-semibold">{metadata?.n_exposures ?? '—'}</span>
                <span className="text-text-muted">Pixel scale:</span>
                <span className="text-secondary">{metadata?.pixel_scale_arcsec ?? 6.15}″ / pix</span>
                <span className="text-text-muted">Size:</span>
                <span className="text-secondary">
                  {metadata ? `${metadata.dimensions[0]} × ${metadata.dimensions[1]} px` : '—'}
                </span>
                <span className="text-text-muted">Release:</span>
                <span className="text-secondary break-all">{metadata?.data_release || '—'}</span>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-surface-border text-xs font-mono">
              <span className="text-[11px] font-semibold text-text-muted uppercase tracking-wider block">
                Pixel Statistics (MJy/sr)
              </span>
              <div className="space-y-1 bg-surface-elevated p-2.5 rounded border border-surface-border text-[11px]">
                <div className="flex justify-between">
                  <span className="text-text-muted">Peak:</span>
                  <span className="text-text-main font-medium">{metadata?.peak_flux ?? '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-muted">Median (after zodi + background):</span>
                  <span className="text-secondary">{metadata?.background_flux_mjy_sr ?? '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-muted">Robust RMS (1σ):</span>
                  <span className="text-scientific-cyan">{metadata?.rms_noise ?? '—'}</span>
                </div>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-surface-border text-xs">
              <span className="text-[11px] font-semibold text-text-muted uppercase tracking-wider block">
                Data Quality
              </span>
              <div className="space-y-1.5 font-mono text-[11px]">
                <div className="flex items-center justify-between p-1.5 rounded bg-surface-elevated border border-surface-border">
                  <span className="text-text-muted">Zodiacal light:</span>
                  <span className="text-scientific-success">Subtracted (IRSA model)</span>
                </div>
                <div className="flex items-center justify-between p-1.5 rounded bg-surface-elevated border border-surface-border">
                  <span className="text-text-muted">Bad / cosmic-ray pixels:</span>
                  <span className="text-scientific-success">Masked (SPHEREx flags)</span>
                </div>
                <div className="flex items-center justify-between p-1.5 rounded bg-surface-elevated border border-surface-border">
                  <span className="text-text-muted">Target saturated:</span>
                  <span className={metadata?.quality_flags.saturation_detected ? 'text-scientific-warning' : 'text-scientific-success'}>
                    {metadata ? (metadata.quality_flags.saturation_detected ? 'Yes' : 'No') : '—'}
                  </span>
                </div>
              </div>
            </div>

            {selectedCandidate && (
              <div className="space-y-2 pt-2 border-t border-surface-border">
                <span className="text-[11px] font-semibold text-primary uppercase tracking-wider flex items-center space-x-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>SPHEREx Measurement</span>
                </span>
                <div className="p-2.5 rounded bg-surface-elevated border border-surface-border font-mono text-xs space-y-1.5">
                  <p className="text-scientific-cyan text-[11px] leading-snug">{selectedCandidate.classification}</p>
                  {selectedCandidate.blend && (
                    <p className="text-scientific-warning text-[10px] leading-snug font-sans">{selectedCandidate.blend.message}</p>
                  )}
                  {motion && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-text-muted">Measured motion:</span>
                        <span className="text-text-main">
                          {motion.pm_total_arcsec_yr} ± {motion.pm_error_arcsec_yr}″/yr
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-muted">Catalog motion:</span>
                        <span className="text-secondary">{motion.catalog_pm_arcsec_yr}″/yr</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-muted">Positions used:</span>
                        <span className="text-secondary">
                          {motion.n_points} over {motion.baseline_yr} yr
                        </span>
                      </div>
                    </>
                  )}
                  <div className="flex justify-between">
                    <span className="text-text-muted">First→last visit shift:</span>
                    <span className="text-text-main">{selectedCandidate.angular_displacement_arcsec}″</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-text-muted">Median peak SNR:</span>
                    <span className="text-scientific-success">{selectedCandidate.snr}</span>
                  </div>
                  <button
                    onClick={() => onOpenCandidateModal(selectedCandidate, observationsData?.target_name || 'Custom Field')}
                    className="w-full mt-2 py-1 px-2 rounded bg-surface-card border border-primary/40 hover:border-primary text-primary text-xs flex items-center justify-center space-x-1 transition-colors"
                  >
                    <BookmarkPlus className="w-3.5 h-3.5" />
                    <span>Save to Discoveries</span>
                  </button>
                </div>
              </div>
            )}

            <div className="pt-2 border-t border-surface-border space-y-2">
              <button
                onClick={() => onNavigateTab('spectral')}
                className="w-full py-2 px-3 rounded bg-surface-elevated border border-surface-border hover:border-scientific-success/50 text-xs font-mono text-scientific-success flex items-center justify-center space-x-1.5 transition-colors"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Open Measured Spectrum</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
