import React, { useState, useEffect, useCallback } from 'react';
import { ViewTab, Target, DetectedCandidate, ObservationMetadata } from './types';
import { ApiService } from './services/api';
import { TopNav } from './components/TopNav';
import { Overview } from './components/Overview';
import { SkyExplorer } from './components/SkyExplorer';
import { TimeMachine } from './components/TimeMachine';
import { SpectralAnalysis } from './components/SpectralAnalysis';
import { Discoveries } from './components/Discoveries';
import { AboutSPHEREx } from './components/AboutSPHEREx';
import { HeaderModal } from './components/HeaderModal';
import { CandidateModal } from './components/CandidateModal';
import { PreferencesModal } from './components/PreferencesModal';
import { DocumentationModal } from './components/DocumentationModal';
import { ImportDataModal } from './components/ImportDataModal';

export const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<ViewTab>('overview');
  const [targets, setTargets] = useState<Target[]>([]);
  const [currentTargetId, setCurrentTargetId] = useState<string>('');
  const [activeCoords, setActiveCoords] = useState<{ ra: number; dec: number }>({ ra: 0, dec: 0 });
  const [detector, setDetector] = useState<string>('D1');
  const [ready, setReady] = useState<boolean>(false);
  const [loadError, setLoadError] = useState<string>('');

  // Modals state
  const [headerModalData, setHeaderModalData] = useState<ObservationMetadata | null>(null);
  const [candidateModalData, setCandidateModalData] = useState<{ candidate: DetectedCandidate; field: string } | null>(null);
  const [showPreferences, setShowPreferences] = useState<boolean>(false);
  const [showDocumentation, setShowDocumentation] = useState<boolean>(false);
  const [showImportModal, setShowImportModal] = useState<boolean>(false);

  // Preferences
  const [coordFormat, setCoordFormat] = useState<'sexagesimal' | 'decimal'>('sexagesimal');
  const [fluxUnits, setFluxUnits] = useState<'mjy_sr' | 'dn'>('mjy_sr');

  const refreshTargets = useCallback(async () => {
    const list = await ApiService.getTargets();
    setTargets(list);
    return list;
  }, []);

  const updateUrl = (patch: Record<string, string | null>) => {
    const url = new URL(window.location.href);
    Object.entries(patch).forEach(([k, v]) => (v === null ? url.searchParams.delete(k) : url.searchParams.set(k, v)));
    window.history.replaceState({}, '', url.toString());
  };

  // Load the dataset's target list and apply deep-link parameters (?target=, ?ra=&dec=, ?detector=, ?tab=)
  useEffect(() => {
    const init = async () => {
      try {
        const targetList = await refreshTargets();
        const params = new URLSearchParams(window.location.search);
        const urlTarget = params.get('target');
        const urlRa = parseFloat(params.get('ra') || '');
        const urlDec = parseFloat(params.get('dec') || '');
        const urlTab = params.get('tab') as ViewTab | null;
        const urlDet = (params.get('detector') || '').toUpperCase();

        if (urlTarget && targetList.some((t) => t.id === urlTarget)) {
          const t = targetList.find((x) => x.id === urlTarget)!;
          setCurrentTargetId(t.id);
          setActiveCoords({ ra: t.coordinates.ra_deg, dec: t.coordinates.dec_deg });
          setDetector(t.default_detector);
        } else if (!isNaN(urlRa) && !isNaN(urlDec)) {
          setCurrentTargetId('');
          setActiveCoords({ ra: urlRa, dec: urlDec });
        } else if (targetList.length > 0) {
          const t = targetList.find((x) => x.id === 'wise_0855') || targetList[0];
          setCurrentTargetId(t.id);
          setActiveCoords({ ra: t.coordinates.ra_deg, dec: t.coordinates.dec_deg });
          setDetector(t.default_detector);
        }
        if (/^D[1-6]$/.test(urlDet)) setDetector(urlDet);
        if (urlTab && ['overview', 'explorer', 'time-machine', 'spectral', 'discoveries', 'about'].includes(urlTab)) {
          setCurrentTab(urlTab);
        }
      } catch (err: any) {
        console.error('Failed to load the SPHEREx dataset:', err);
        setLoadError(err.message || 'Could not reach the backend.');
      } finally {
        setReady(true);
      }
    };
    init();
  }, [refreshTargets]);

  const handleSelectTarget = (targetId: string, openTab?: ViewTab) => {
    setCurrentTargetId(targetId);
    const t = targets.find((x) => x.id === targetId);
    if (t) {
      setActiveCoords({ ra: t.coordinates.ra_deg, dec: t.coordinates.dec_deg });
      setDetector(t.default_detector);
      updateUrl({ target: targetId, ra: null, dec: null });
    }
    if (openTab) {
      setCurrentTab(openTab);
      updateUrl({ tab: openTab });
    }
  };

  const handleSetCoords = (c: { ra: number; dec: number }) => {
    setActiveCoords(c);
    if (!currentTargetId) updateUrl({ target: null, ra: c.ra.toFixed(5), dec: c.dec.toFixed(5) });
  };

  const handleSetDetector = (d: string) => {
    setDetector(d);
    updateUrl({ detector: d });
  };

  const handleSearch = async (query: string) => {
    try {
      const res = await ApiService.searchCoordinates({ query });
      if (res.matched_target) {
        handleSelectTarget(res.matched_target.id, 'explorer');
      } else {
        setCurrentTargetId('');
        setActiveCoords({ ra: res.ra_deg, dec: res.dec_deg });
        updateUrl({ target: null, ra: res.ra_deg.toFixed(5), dec: res.dec_deg.toFixed(5) });
        setCurrentTab('explorer');
      }
    } catch (err: any) {
      alert(`Search error: ${err.message}`);
    }
  };

  const activeTargetName = targets.find((t) => t.id === currentTargetId)?.name;

  return (
    <div className="min-h-screen flex flex-col bg-[#0B1016] text-[#E6EDF3]">
      {/* Top Application Bar */}
      <TopNav
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          updateUrl({ tab });
        }}
        onOpenDoc={() => setShowDocumentation(true)}
        onOpenPreferences={() => setShowPreferences(true)}
        onOpenImport={() => setShowImportModal(true)}
        activeTargetName={activeTargetName}
        activeCoords={activeCoords}
      />

      {/* Main Tab Content */}
      <main className="flex-1 flex flex-col">
        {ready && (loadError || targets.length === 0) && currentTab !== 'about' && (
          <div className="m-4 p-3 rounded border border-scientific-warning/40 bg-scientific-warning/10 text-xs text-text-main font-mono">
            {loadError
              ? `Backend unavailable: ${loadError}`
              : 'No SPHEREx fields found. Build the dataset first: .venv\\Scripts\\python.exe dataset\\build_dataset.py'}
          </div>
        )}
        {currentTab === 'overview' && (
          <Overview
            targets={targets}
            onSelectTarget={handleSelectTarget}
            onSearch={handleSearch}
            onNavigateTab={setCurrentTab}
          />
        )}

        {currentTab === 'explorer' && (
          <SkyExplorer
            targets={targets}
            currentTargetId={currentTargetId}
            onSelectTarget={(id) => handleSelectTarget(id, 'explorer')}
            onNavigateTab={setCurrentTab}
            onOpenHeaderModal={(meta) => setHeaderModalData(meta)}
            onOpenCandidateModal={(cand, field) => setCandidateModalData({ candidate: cand, field })}
            activeCoords={activeCoords}
            setActiveCoords={handleSetCoords}
            onTargetsChanged={refreshTargets}
            detector={detector}
            setDetector={handleSetDetector}
          />
        )}

        {currentTab === 'time-machine' && (
          <TimeMachine
            targets={targets}
            currentTargetId={currentTargetId}
            onSelectTarget={(id) => handleSelectTarget(id)}
            onOpenCandidateModal={(cand, field) => setCandidateModalData({ candidate: cand, field })}
            activeCoords={activeCoords}
            detector={detector}
            setDetector={handleSetDetector}
          />
        )}

        {currentTab === 'spectral' && (
          <SpectralAnalysis
            targets={targets}
            currentTargetId={currentTargetId}
            onSelectTarget={(id) => handleSelectTarget(id)}
            activeCoords={activeCoords}
          />
        )}

        {currentTab === 'discoveries' && (
          <Discoveries
            onNavigateTarget={handleSelectTarget}
            onOpenCandidateModal={(cand, field) => setCandidateModalData({ candidate: cand, field })}
          />
        )}

        {currentTab === 'about' && <AboutSPHEREx />}
      </main>

      {/* Modals */}
      {headerModalData && (
        <HeaderModal
          metadata={headerModalData}
          onClose={() => setHeaderModalData(null)}
        />
      )}

      {candidateModalData && (
        <CandidateModal
          candidate={candidateModalData.candidate}
          targetField={candidateModalData.field}
          onClose={() => setCandidateModalData(null)}
          onSaved={() => {
            // refresh
          }}
        />
      )}

      {showPreferences && (
        <PreferencesModal
          onClose={() => setShowPreferences(false)}
          coordFormat={coordFormat}
          setCoordFormat={setCoordFormat}
          units={fluxUnits}
          setUnits={setFluxUnits}
        />
      )}

      {showDocumentation && (
        <DocumentationModal
          onClose={() => setShowDocumentation(false)}
        />
      )}

      {showImportModal && (
        <ImportDataModal
          onClose={() => setShowImportModal(false)}
          activeCoords={activeCoords}
          onLoadCustomFits={(custom) => {
            setActiveCoords({ ra: custom.ra, dec: custom.dec });
            setCurrentTargetId('');
            setCurrentTab('explorer');
          }}
        />
      )}
    </div>
  );
};

export default App;

