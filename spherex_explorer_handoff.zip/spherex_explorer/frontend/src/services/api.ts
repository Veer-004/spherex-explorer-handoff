import {
  Target,
  ObservationsResponse,
  SpectrumResponse,
  DifferenceResponse,
  DiscoveryItem,
  CatalogResponse,
  BuildStatus,
  MoversResponse,
} from '../types';

const API_BASE = '/api';

/** Error carrying the backend's `detail` payload (e.g. `{ can_build, field_id }` for unknown sky positions). */
export class ApiError extends Error {
  status: number;
  detail: any;
  constructor(status: number, detail: any) {
    super(typeof detail === 'string' ? detail : detail?.message || `Request failed (${status})`);
    this.status = status;
    this.detail = detail;
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  if (!res.ok) {
    let detail: any = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      detail = body.detail ?? detail;
      if (Array.isArray(detail)) detail = detail.map((d: any) => d.msg).join('; ');
    } catch {
      /* non-JSON error body */
    }
    throw new ApiError(res.status, detail);
  }
  return res.json();
}

function qs(params: Record<string, string | number | undefined | null>): string {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
  });
  return q.toString();
}

/** Either a dataset field id, or a raw sky position. */
export interface FieldRef {
  target_id?: string;
  ra?: number;
  dec?: number;
}

export const ApiService = {
  health(): Promise<{ status: string; service: string; astropy_version: string; fields: number }> {
    return request(`${API_BASE}/health`);
  },

  getTargets(): Promise<Target[]> {
    return request(`${API_BASE}/targets`);
  },

  getTargetDetails(targetId: string): Promise<Target> {
    return request(`${API_BASE}/targets/${encodeURIComponent(targetId)}`);
  },

  searchCoordinates(params: { query?: string; ra?: string; dec?: string; fov_arcmin?: number }): Promise<{
    matched_target: Target | null;
    is_preconfigured: boolean;
    ra_deg: number;
    dec_deg: number;
    ra_sexagesimal: string;
    dec_sexagesimal: string;
    fov_arcmin: number;
    default_channel: number;
    in_dataset: boolean;
    field_id: string;
  }> {
    return request(`${API_BASE}/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },

  getObservations(params: FieldRef & {
    detector?: string;
    fov_arcmin?: number;
    stretch?: string;
    colormap?: string;
  }): Promise<ObservationsResponse> {
    return request(`${API_BASE}/observations?${qs({ ...params })}`);
  },

  getDifferenceImage(params: FieldRef & {
    detector?: string;
    fov_arcmin?: number;
    epoch1: number;
    epoch2: number;
  }): Promise<DifferenceResponse> {
    return request(`${API_BASE}/difference?${qs({ ...params })}`);
  },

  getSpectrum(params: FieldRef): Promise<SpectrumResponse> {
    return request(`${API_BASE}/spectrum?${qs({ ...params })}`);
  },

  getCatalog(params: FieldRef & { source: 'gaia' | 'catwise'; fov_arcmin?: number }): Promise<CatalogResponse> {
    return request(`${API_BASE}/catalog?${qs({ ...params })}`);
  },

  getMovers(params: FieldRef & { fov_arcmin?: number; limit?: number }): Promise<MoversResponse> {
    return request(`${API_BASE}/movers?${qs({ ...params })}`);
  },

  buildField(ra: number, dec: number, name?: string): Promise<BuildStatus> {
    return request(`${API_BASE}/fields`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ra, dec, name }),
    });
  },

  getBuildStatus(fieldId: string): Promise<BuildStatus> {
    return request(`${API_BASE}/fields/${encodeURIComponent(fieldId)}`);
  },

  getDiscoveries(category?: string, sortBy: string = 'confidence_score'): Promise<DiscoveryItem[]> {
    return request(`${API_BASE}/discoveries?${qs({ category: category === 'all' ? undefined : category, sort_by: sortBy })}`);
  },

  saveDiscovery(candidate: Partial<DiscoveryItem>): Promise<{ message: string; candidate: DiscoveryItem }> {
    return request(`${API_BASE}/discoveries`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(candidate),
    });
  },

  getExportUrl(): string {
    return `${API_BASE}/discoveries/export`;
  },
};
